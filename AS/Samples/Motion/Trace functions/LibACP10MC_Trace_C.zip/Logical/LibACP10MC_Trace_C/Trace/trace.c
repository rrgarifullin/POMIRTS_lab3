/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************
 * Program: Trace
 * File: trace.c
 * Author: Bernecker + Rainer
 * Created: December 01, 2009
 ********************************************************************
 * Implementation of program Trace
 ********************************************************************/

#include <bur/plctypes.h>
#include <string.h>
#ifdef _DEFAULT_INCLUDES
 #include <AsDefault.h>
#endif

#define STATE_READY                 00

#define STATE_START_PAR_TRACE       11
#define STATE_STOP_PAR_TRACE        12
#define STATE_SAVE_PAR_TRACE        13
#define STATE_READ_PAR_TRACE_STATUS 14

#define STATE_SWITCH_ON_NET_TRACE   21
#define STATE_SWITCH_OFF_NET_TRACE  22
#define STATE_RESET_NET_TRACE       23
#define STATE_SAVE_NET_TRACE        24
#define STATE_READ_NET_TRACE_STATUS 25

#define STATE_ERROR                 255

void _INIT TraceINIT( void )
{
    Axis1Obj = (UDINT)&(gAxis01); /* Axis */
    
    Step = STATE_READY; /* start step */
    
    /* Configuration of Partrace */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Type = mcMULTI_AXIS_TRACE;    /* trace type */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.TracingTime = 0.5;    /* maximum trace recording length */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.SamplingTime = 0.0002;    /* sampling interval of the ParIDs*/
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Delay = 0;    /* Trigger delay */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.NetTriggerDelay = 0;  /* delay time of the trigger via the network */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Trigger.Axis = Axis1Obj;  /* axis reference */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Trigger.ParID = ACP10PAR_PCTRL_S_SET; /* ParID to use as trigger source */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Trigger.Event = mcOUT_WINDOW; /* trigger event */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Trigger.Threshold = 0;    /* threshold value */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Trigger.Window = 0;   /* window around the treshold value */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Parameter[0].Axis = Axis1Obj; /* axis reference */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Parameter[0].ParID = ACP10PAR_PCTRL_LAG_ERROR;    /* ParID to record */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Parameter[1].Axis = Axis1Obj; /* axis reference */
    TraceControl.Parameter.ParTraceConfiguration.ParTrace.Parameter[1].ParID = ACP10PAR_PCTRL_S_SET;    /* ParId to record */
    strcpy((void*)&TraceControl.Parameter.ParTraceConfiguration.DatObj.Name, "ParTrace");   /* name of the data object or file */
    TraceControl.Parameter.ParTraceConfiguration.DatObj.Type = mcFILE + mcADD_DATE_TIME;    /* type (data object or file) */
    strcpy((void*)&TraceControl.Parameter.ParTraceConfiguration.DatObj.Device,"PARTRACE");  /* name of the file device if type is "mcFILE" */
    
    strcpy((void*)&TraceControl.Parameter.NetTraceConfiguration.DatObj.Name,"NetTrace"); /* name of the data object or file */
    TraceControl.Parameter.NetTraceConfiguration.DatObj.Type = mcFILE + mcADD_DATE_TIME;    /*type (data object or file) */
    strcpy((void*)&TraceControl.Parameter.NetTraceConfiguration.DatObj.Device,"NETTRACE");  /* name of the file device if type is "mcFILE" */
}

void _CYCLIC TraceCYCLIC( void )
{
    switch (Step)
    {
        
/***************************STATE_READY******************************/        
        case STATE_READY: /* waiting for commands */
            if (TraceControl.Command.StartParTrace == 1)
            {
                TraceControl.Command.StartParTrace = 0;
                Step = STATE_START_PAR_TRACE;   
            }
            else if (TraceControl.Command.StopParTrace == 1)
            {
                TraceControl.Command.StopParTrace = 0;
                Step = STATE_STOP_PAR_TRACE;   
            }
            else if (TraceControl.Command.SaveParTrace == 1)
            {
                TraceControl.Command.SaveParTrace = 0;
                Step = STATE_SAVE_PAR_TRACE;   
            }
            else if (TraceControl.Command.ReadParTraceStatus == 1)
            {
                TraceControl.Command.ReadParTraceStatus = 0;
                Step = STATE_READ_PAR_TRACE_STATUS;   
            }
            else if (TraceControl.Command.SwitchOnNetTrace == 1)
            {
                TraceControl.Command.SwitchOnNetTrace = 0;
                Step = STATE_SWITCH_ON_NET_TRACE;   
            }
            else if (TraceControl.Command.SwitchOffNetTrace == 1)
            {
                TraceControl.Command.SwitchOffNetTrace = 0;
                Step = STATE_SWITCH_OFF_NET_TRACE;   
            }
            else if (TraceControl.Command.ResetNetTrace == 1)
            {
                TraceControl.Command.ResetNetTrace = 0;
                Step = STATE_RESET_NET_TRACE;
            }
            else if (TraceControl.Command.SaveNetTrace == 1)
            {
                TraceControl.Command.SaveNetTrace = 0;
                Step = STATE_SAVE_NET_TRACE;   
            }
            else if (TraceControl.Command.ReadNetTraceStatus == 1)
            {
                TraceControl.Command.ReadNetTraceStatus = 0;
                Step = STATE_READ_NET_TRACE_STATUS;
            }
            else if ((TraceControl.Status.ParTraceStatus == mcTRACE_FINISHED) && (TraceControl.Status.ParTraceSaved == 0))
            {
                Step = STATE_SAVE_PAR_TRACE;   
            }
        break;  
         
/***************************STATE_START_PAR_TRACE***************************/        
        case STATE_START_PAR_TRACE: /* start the parmeter trace */
            TraceControl.Status.ParTraceSaved = 0;
            MC_BR_ParTrace_0.Command = mcSTART;
            MC_BR_ParTrace_0.Configuration = TraceControl.Parameter.ParTraceConfiguration;
            MC_BR_ParTrace_0.Execute = 1;
            
            if (MC_BR_ParTrace_0.Done == 1)
            {
                MC_BR_ParTrace_0.Execute = 0;
                Step = STATE_READY;  
            }
            else if (MC_BR_ParTrace_0.Error == 1)
            {
                TraceControl.Status.ErrorID = MC_BR_ParTrace_0.ErrorID;
                TraceControl.Status.ErrorRecord = MC_BR_ParTrace_0.ErrorRecord;
                MC_BR_ParTrace_0.Execute = 0;
                Step = STATE_ERROR;
            }
        break;
        
/***************************STATE_STOP_PAR_TRACE***************************/        
        case STATE_STOP_PAR_TRACE: /* stop the parameter trace */
            MC_BR_ParTrace_0.Command = mcSTOP;
            MC_BR_ParTrace_0.Execute = 1;
            
            if (MC_BR_ParTrace_0.Done == 1)
            {
                MC_BR_ParTrace_0.Execute = 0;
                Step = STATE_SAVE_PAR_TRACE;  
            }
            else if (MC_BR_ParTrace_0.Error == 1)
            {
                TraceControl.Status.ErrorID = MC_BR_ParTrace_0.ErrorID;
                TraceControl.Status.ErrorRecord = MC_BR_ParTrace_0.ErrorRecord;
                MC_BR_ParTrace_0.Execute = 0;
                Step = STATE_ERROR;
            }
        break;

/***************************STATE_SAVE_PAR_TRACE***************************/        
        case STATE_SAVE_PAR_TRACE: /* save the parameter trace data in a file */
            MC_BR_ParTrace_0.Command = mcSAVE;
            MC_BR_ParTrace_0.Configuration = TraceControl.Parameter.ParTraceConfiguration;
            MC_BR_ParTrace_0.Execute = 1;
            
            if (MC_BR_ParTrace_0.Done == 1)
            {
                TraceControl.Status.ParTraceSaved = 1;
                MC_BR_ParTrace_0.Execute = 0;
                Step = STATE_READY;  
            }
            else if (MC_BR_ParTrace_0.Error == 1)
            {
                TraceControl.Status.ErrorID = MC_BR_ParTrace_0.ErrorID;
                TraceControl.Status.ErrorRecord = MC_BR_ParTrace_0.ErrorRecord;
                MC_BR_ParTrace_0.Execute = 0;
                Step = STATE_ERROR;
            }
        break;
        
/***************************STATE_READ_PAR_TRACE_STATUS***************************/
        case STATE_READ_PAR_TRACE_STATUS: /* read the parameter trace status */
            MC_BR_ReadParTraceStatus_0.Enable = 1;
            MC_BR_ReadParTraceStatus_0.Configuration.ParTrace.Type = mcMULTI_AXIS_TRACE;
        
            if (MC_BR_ReadParTraceStatus_0.Valid == 1)
            {
                Step = STATE_READY;
            }
            else if (MC_BR_ReadParTraceStatus_0.Error == 1)
            {
                TraceControl.Status.ErrorID = MC_BR_ReadParTraceStatus_0.ErrorID;
                MC_BR_ReadParTraceStatus_0.Enable = 0;
                Step = STATE_ERROR;    
            }
    
        break; 
        
/***************************STATE_SWITCH_OFF_NET_TRACE***************************/
        case STATE_SWITCH_OFF_NET_TRACE: /* swicth off network commando trace */
            MC_BR_NetTrace_0.Command = mcSWITCH_OFF;
            MC_BR_NetTrace_0.Configuration.NetTrace.Type = mcNET_TRACE_GLOBAL;
            MC_BR_NetTrace_0.Execute = 1;
        
            if (MC_BR_NetTrace_0.Done == 1)
            {
                MC_BR_NetTrace_0.Execute = 0;
                Step = STATE_READY;   
            }
            else if (MC_BR_NetTrace_0.Error == 1)
            {
                TraceControl.Status.ErrorID = MC_BR_NetTrace_0.ErrorID;
                TraceControl.Status.ErrorRecord = MC_BR_NetTrace_0.ErrorRecord;
                MC_BR_NetTrace_0.Execute = 0;
                Step = STATE_ERROR;   
            }
        
        break;    
         
/***************************STATE_SWITCH_ON_NET_TRACE***************************/
        case STATE_SWITCH_ON_NET_TRACE: /* switch on network commando trace */
            MC_BR_NetTrace_0.Command = mcSWITCH_ON;
            MC_BR_NetTrace_0.Configuration.NetTrace.Type = mcNET_TRACE_GLOBAL;
            MC_BR_NetTrace_0.Execute = 1;
        
            if (MC_BR_NetTrace_0.Done == 1)
            {
                MC_BR_NetTrace_0.Execute = 0;
                Step = STATE_READY;   
            }
            else if(MC_BR_NetTrace_0.Error == 1)
            {
                TraceControl.Status.ErrorID = MC_BR_NetTrace_0.ErrorID;
                TraceControl.Status.ErrorRecord = MC_BR_NetTrace_0.ErrorRecord;
                MC_BR_NetTrace_0.Execute = 0;
                Step = STATE_ERROR;   
            }
        break;     
    
/***************************STATE_RESET_NET_TRACE***************************/
        case STATE_RESET_NET_TRACE: /* reset network commando trace */
            MC_BR_NetTrace_0.Command = mcRESET;
            MC_BR_NetTrace_0.Configuration.NetTrace.Type = mcNET_TRACE_GLOBAL;
            MC_BR_NetTrace_0.Execute = 1;
        
            if (MC_BR_NetTrace_0.Done == 1)
            {
                MC_BR_NetTrace_0.Execute = 0;
                Step = STATE_READY;   
            }
            else if(MC_BR_NetTrace_0.Error == 1)
            {
                TraceControl.Status.ErrorID = MC_BR_NetTrace_0.ErrorID;
                TraceControl.Status.ErrorRecord = MC_BR_NetTrace_0.ErrorRecord;
                MC_BR_NetTrace_0.Execute = 0;
                Step = STATE_ERROR;   
            }        
        break;   
    
/***************************STATE_SAVE_NET_TRACE***************************/
        case STATE_SAVE_NET_TRACE: /* save data from network commando trace */
            MC_BR_NetTrace_0.Command = mcSAVE;
            MC_BR_NetTrace_0.Configuration.NetTrace.Type = mcNET_TRACE_GLOBAL;
            MC_BR_NetTrace_0.Configuration.DatObj = TraceControl.Parameter.NetTraceConfiguration.DatObj;
            MC_BR_NetTrace_0.Execute = 1;
        
            if (MC_BR_NetTrace_0.Done == 1)
            {
                MC_BR_NetTrace_0.Execute = 0;
                Step = STATE_READY;   
            }
            else if(MC_BR_NetTrace_0.Error == 1)
            {
                TraceControl.Status.ErrorID = MC_BR_NetTrace_0.ErrorID;
                TraceControl.Status.ErrorRecord = MC_BR_NetTrace_0.ErrorRecord;
                MC_BR_NetTrace_0.Execute = 0;
                Step = STATE_ERROR;   
            }        
        break;    
    
/***************************STATE_READ_NET_TRACE_STATUS***************************/
        case STATE_READ_NET_TRACE_STATUS: /* read status of network commando trace */
            MC_BR_ReadNetTraceStatus_0.Enable = 1;
            MC_BR_ReadNetTraceStatus_0.Configuration.NetTrace.Type = mcNET_TRACE_GLOBAL;
        
            if (MC_BR_ReadNetTraceStatus_0.Valid == 1)
            {
                TraceControl.Status.NetTraceStatus = MC_BR_ReadNetTraceStatus_0.TraceState;    
                Step = STATE_READY;
            }
            else if (MC_BR_ReadNetTraceStatus_0.Error == 1)
            {   
                TraceControl.Status.ErrorID = MC_BR_ReadNetTraceStatus_0.ErrorID;
                MC_BR_ReadNetTraceStatus_0.Enable = 0;
                Step = STATE_ERROR;
            }
        break;
        
/**************************STATE_ERROR*****************************************/
        case STATE_ERROR:
            MC_BR_GetErrorText_0.ErrorRecord = TraceControl.Status.ErrorRecord;
            MC_BR_GetErrorText_0.Configuration.DataAddress = (UDINT)&(TraceControl.Status.ErrorText);
            MC_BR_GetErrorText_0.Configuration.DataLength = sizeof(TraceControl.Status.ErrorText);
            MC_BR_GetErrorText_0.Configuration.Format = mcNULL;
            MC_BR_GetErrorText_0.Configuration.LineLength = sizeof(TraceControl.Status.ErrorText[0]);
            strcpy(&MC_BR_GetErrorText_0.Configuration.DataObjectName[0], "acp10etxen");
            MC_BR_GetErrorText_0.Execute = 1;
            
            if (TraceControl.Command.ErrorAcknowledge == 1)
            {
                if (MC_BR_GetErrorText_0.Done == 1)
                {
                    Step = STATE_READY;
                    MC_BR_GetErrorText_0.Execute = 0;   
                }
                else if (MC_BR_GetErrorText_0.Error == 1)
                {
                    MC_BR_GetErrorText_0.Execute = 0;
                    TraceControl.Status.ErrorID = MC_BR_GetErrorText_0.ErrorID;
                    Step = STATE_READY;
                }
            }           
        break;        
    }
    
    /* Function Block */
    
    /******************************MC_BR_ParTrace*******************************/
    MC_BR_ParTrace(&MC_BR_ParTrace_0);
    
    /*************************MC_BR_ReadNetTraceStatus**************************/
    MC_BR_ReadParTraceStatus(&MC_BR_ReadParTraceStatus_0);
    TraceControl.Status.ParTraceStatus = MC_BR_ReadParTraceStatus_0.TraceState;
    
    /******************************MC_BR_NetTrace*******************************/
    MC_BR_NetTrace(&MC_BR_NetTrace_0);
    
    /*************************MC_BR_ReadNetTraceStatus**************************/
    MC_BR_ReadNetTraceStatus(&MC_BR_ReadNetTraceStatus_0);
    TraceControl.Status.NetTraceStatus = MC_BR_ReadNetTraceStatus_0.TraceState; 
    
    /***************************MC_BR_GetErrorText******************************/
    MC_BR_GetErrorText(&MC_BR_GetErrorText_0); 
}
