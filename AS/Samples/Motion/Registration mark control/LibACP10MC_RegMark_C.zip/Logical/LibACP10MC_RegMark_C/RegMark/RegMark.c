/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************
 * Program: RegMarkControl
 * File: RegMark.c
 * Author: Bernecker + Rainer
 * Created: December 01, 2009
 ********************************************************************
 * Implementation of program RegMarkControl
 ********************************************************************/

#include <bur/plctypes.h>
#ifdef _DEFAULT_INCLUDES
 #include <AsDefault.h>
#endif

/* defines of the state constants */
#define STATE_WAIT				0
#define STATE_READY				1
#define STATE_START_CAPTURE		2
#define STATE_SHIFT				3
#define STATE_SEARCH_TRIGGER	4
#define STATE_RESET_CALC        5
#define STATE_STOP_CORRECTION   6

#define STATE_ERROR				255

void _INIT RegMarkINIT( void )
{
    Axis1Obj = (UDINT)&gAxis01;		/* master axis */
    Axis2Obj = (UDINT)&gAxis02;		/*slave axis */
    
    Step = STATE_WAIT;  /* start step */

    /* mode for searching the printmarks */
    RegMarkControl.Parameter.Capture.Mode = mcFIRST_TRIGGER;    /* used mode for searching the print marks */
    
    /* product parameters */
    RegMarkControl.Parameter.Capture.Product.Length = 1000; /* length of the product */
    RegMarkControl.Parameter.Capture.Product.LengthChange = 200;    /* length change if function block looses print mark */
    RegMarkControl.Parameter.Capture.Product.LengthTolerance = 30;  /* length tolerance for distance between the print marks */
    RegMarkControl.Parameter.Capture.Product.StartOffset = 0;   /* distance between photo eye and first print mark */
    RegMarkControl.Parameter.Capture.Product.RegMarkPosition = 0;   /* set position of the print mark in relation to the product interval */
    RegMarkControl.Parameter.Capture.Product.DistanceToSensor = 700; /* distance between photo eye and tool */
    RegMarkControl.Parameter.Capture.Product.SearchMode = mcON; /* start search of print mark automatically if it is lost */
    RegMarkControl.Parameter.Capture.Product.MissedTriggerCount = 1;    /* number of missed triggers before search starts automatically */

    /* trigger event parameters */
    RegMarkControl.Parameter.Capture.Trigger.EventSourceParID = ACP10PAR_STAT_TRIGGER1; /* par id of the trigger signal */
    RegMarkControl.Parameter.Capture.Trigger.PosSource = ncS_SET;   /* source of the read position (ncS_SET or ncS_ACT) */
    RegMarkControl.Parameter.Capture.Trigger.Edge = ncP_EDGE;   /* edge of the trigger signal */
    RegMarkControl.Parameter.Capture.Trigger.MinWidth = 10; /* minimal width of the trigger signal to be considered (Units of the slave) */
    RegMarkControl.Parameter.Capture.Trigger.MaxWidth = 200;    /* maximal width of the trigger signal to be considered (Units of the slave)*/    
    RegMarkControl.Parameter.Capture.Trigger.WindowNegative = 200;  /* Units before expected position where the trigger signal is valid */
    RegMarkControl.Parameter.Capture.Trigger.WindowPositive = 200;  /* Units after expected position where the trigger signal is valid */
    RegMarkControl.Parameter.Capture.Trigger.MasterInterval = 1100; /* Interval of the master axis (Units of the master) */

    /* parameters for calculation of the compensation shift */
    RegMarkControl.Parameter.Calculation.Mode = mcIMMEDIATE;    /* used mode for the calculation */
    RegMarkControl.Parameter.Calculation.MaxDistanceCorrection = 200;   /* maximal distance correction value */
    RegMarkControl.Parameter.Calculation.MaxShiftCorrection = 500;  /* maximal shift correction value */
    RegMarkControl.Parameter.Calculation.DistanceCorrectionClamp = mcOFF; /* if "mcOFF" distance is limited to maximal distance; if "mcON" distance is set to zero if >maximal distance */
    RegMarkControl.Parameter.Calculation.AutoParamIntegrator = mcON;    /* if "mcOFF" integrator times are used from parameter; if "mcON" integrator times are evaluated automatically */
    RegMarkControl.Parameter.Calculation.ShiftGain = 1; /* factor for position control */
    RegMarkControl.Parameter.Calculation.ShiftIntegralTime = 0.0;   /* integrator times for position control */
    
    /* parameters for adding the calculated shift to the slave axis */
    RegMarkControl.Parameter.Shift.Velocity = 3000; /* maximal velocity which could be reached while adding the shift value */
    RegMarkControl.Parameter.Shift.Acceleration = 30000;    /* maximal acceleration which could be reached while adding the shift value */
    RegMarkControl.Parameter.Shift.ApplicationMode = mcTIME_BASED;  /* used application mode */
    RegMarkControl.Parameter.Shift.ApplicationDistance = 0; /* application distance */
    RegMarkControl.Parameter.Shift.ShiftMode = mcABSOLUTE;  /* shift mode */
}

void _CYCLIC RegMarkCYCLIC( void )
{
/* status information is read before the step sequencer to attain a shorter reaction time */    
/***********************************MC_ReadStatus_0*********************************/
    /* read the axis state of the master axis */
    MC_ReadStatus_0.Axis = Axis1Obj; 
    MC_ReadStatus_0.Enable = (!MC_ReadStatus_0.Error);
    MC_ReadStatus(&MC_ReadStatus_0);
    RegMarkControl.AxisState.Master.Errorstop = MC_ReadStatus_0.Errorstop;
    RegMarkControl.AxisState.Master.Disabled = MC_ReadStatus_0.Disabled;
    RegMarkControl.AxisState.Master.Stopping = MC_ReadStatus_0.Stopping;
    RegMarkControl.AxisState.Master.StandStill = MC_ReadStatus_0.StandStill;
    RegMarkControl.AxisState.Master.DiscreteMotion = MC_ReadStatus_0.DiscreteMotion;
    RegMarkControl.AxisState.Master.ContinouosMotion = MC_ReadStatus_0.ContinuousMotion;
    RegMarkControl.AxisState.Master.SynchronizedMotion = MC_ReadStatus_0.SynchronizedMotion;
    RegMarkControl.AxisState.Master.Homing = MC_ReadStatus_0.Homing;

    if (MC_ReadStatus_0.Error == 1) 
    {
        RegMarkControl.Status.ErrorID = MC_ReadStatus_0.ErrorID;
    }

/***********************************MC_ReadStatus_1*********************************/
    /* read the axis state of the slave axis */
    MC_ReadStatus_1.Axis = Axis2Obj;
    MC_ReadStatus_1.Enable = (!MC_ReadStatus_1.Error);
    MC_ReadStatus(&MC_ReadStatus_1);
    RegMarkControl.AxisState.Slave.Errorstop = MC_ReadStatus_1.Errorstop;
    RegMarkControl.AxisState.Slave.Disabled = MC_ReadStatus_1.Disabled;
    RegMarkControl.AxisState.Slave.Stopping = MC_ReadStatus_1.Stopping;
    RegMarkControl.AxisState.Slave.StandStill = MC_ReadStatus_1.StandStill;
    RegMarkControl.AxisState.Slave.DiscreteMotion = MC_ReadStatus_1.DiscreteMotion;
    RegMarkControl.AxisState.Slave.ContinouosMotion = MC_ReadStatus_1.ContinuousMotion;
    RegMarkControl.AxisState.Slave.SynchronizedMotion = MC_ReadStatus_1.SynchronizedMotion;
    RegMarkControl.AxisState.Slave.Homing = MC_ReadStatus_1.Homing;

    if (MC_ReadStatus_1.Error == 1) 
    {
        RegMarkControl.Status.ErrorID = MC_ReadStatus_1.ErrorID;
    }

    if ((Step != STATE_WAIT) &&
        ((RegMarkControl.AxisState.Master.Disabled) || (RegMarkControl.AxisState.Master.Errorstop) ||
        (RegMarkControl.AxisState.Slave.Disabled) || (RegMarkControl.AxisState.Slave.Errorstop)))
    {   /* if an axis is switched off or reports an error while correction is running, go to STATE_ERROR */
        Step = STATE_ERROR; 
    }    
    
    
    switch (Step)
    {
/************************************STATE_WAIT****************************************/       
        case STATE_WAIT: /* STATE: waiting for axis are switched on */
            if ((!RegMarkControl.AxisState.Master.Disabled) && (!RegMarkControl.AxisState.Master.Errorstop)&&
                (!RegMarkControl.AxisState.Slave.Disabled) && (!RegMarkControl.AxisState.Slave.Errorstop))
            {
                Step = STATE_READY;
            }
        break;
        
/************************************STATE_READY****************************************/
        case STATE_READY: /* STATE: waiting for commands */
            if (RegMarkControl.Command.StartCorrection == 1)
            {
                RegMarkControl.Command.StartCorrection = 0;
                Step = STATE_START_CAPTURE;
            }
            else if (RegMarkControl.Command.StopCorrection == 1)
            {
                RegMarkControl.Command.StopCorrection = 0;
                Step = STATE_STOP_CORRECTION;
            }   
            else if (RegMarkControl.Command.ResetCalc == 1) 
            {
                RegMarkControl.Command.ResetCalc = 0;
                Step = STATE_RESET_CALC;
            }
            else if (RegMarkControl.Command.SearchTrigger == 1)
            {
                RegMarkControl.Command.SearchTrigger = 0;
                Step = STATE_SEARCH_TRIGGER;
            }
        break;
        
/*********************************STATE_START_CAPTURE***********************************/
        case STATE_START_CAPTURE: /* STATE: Start capture of the printmark */
            MC_BR_RegMarkCapture001_0.Enable = 1;
            MC_BR_RegMarkCapture001_0.TriggerInput = RegMarkControl.Parameter.Capture.Trigger;
            MC_BR_RegMarkCapture001_0.ProductParameters = RegMarkControl.Parameter.Capture.Product;
            MC_BR_RegMarkCapture001_0.Mode = RegMarkControl.Parameter.Capture.Mode;

            if (MC_BR_RegMarkCapture001_0.Valid == 1)
            {   /* a valid printmark was found */
                Step = STATE_SHIFT;
            }
            else if (MC_BR_RegMarkCapture001_0.Error == 1)
            {   /* an error occurred */
                Step = STATE_ERROR;
                RegMarkControl.Status.ErrorID = MC_BR_RegMarkCapture001_0.ErrorID;
                MC_BR_RegMarkCapture001_0.Enable = 0;
            }
        break;
                
/**********************************STATE_SHIFT******************************************/
        case STATE_SHIFT: /* STATE: add the calculated offset to the slave axis*/
            if ((MC_BR_Offset_0.ShiftAttained == 1) && (MC_BR_Offset_0.DataInitialized == 1))
            {   /* shift was sucessfully added to the slave */
                MC_BR_Offset_0.InitData = 0;
                Step = STATE_READY;
            }
            else if (MC_BR_Offset_0.Error == 1)
            {   /* an error occurred */
                Step = STATE_ERROR;
                RegMarkControl.Status.ErrorID = MC_BR_Offset_0.ErrorID;
                MC_BR_Offset_0.Enable = 0;
                MC_BR_Offset_0.InitData = 0;
            }
        break;
        
/**************************STATE_SEARCH_TRIGGER******************************************/
        case STATE_SEARCH_TRIGGER: /* STATE: search trigger manual */
            if (MC_BR_RegMarkCapture001_0.Enable == 1)
            {   /* set "SearchTrigger" input only if the function block is enabled */
                MC_BR_RegMarkCapture001_0.SearchTrigger = 1;
            }
            else
            {
                Step = STATE_READY;   
            }
        
            if (MC_BR_RegMarkCapture001_0.SearchActive == 1) 
            {			
                ; /* wait */         
            }
            else if (MC_BR_RegMarkCapture001_0.SearchDone == 1) 
            {   /* search was successful */
                MC_BR_RegMarkCapture001_0.SearchTrigger = 0;
                Step = STATE_READY;
            }
            else if (MC_BR_RegMarkCapture001_0.Error == 1) 
            {   /* an error occurred */
                Step = STATE_ERROR;
                RegMarkControl.Status.ErrorID = MC_BR_RegMarkCapture001_0.ErrorID;
                MC_BR_RegMarkCapture001_0.Enable = 0;
            }
    
        break;
        
/************************************STATE_RESET_CALC***********************************/        
        case STATE_RESET_CALC: /* STATE: reset all calculated data (queue, integrator) */
            if (MC_BR_RegMarkCalc001_0.Enable == 1)
            {   /* set "Reset" input only if the function block is enabled */
                MC_BR_RegMarkCalc001_0.Reset = 1;
            }
            else 
            {
                Step = STATE_READY;   
            }
            
            if (MC_BR_RegMarkCalc001_0.ResetDone == 1)
            {   /* reset was successful */
                Step = STATE_READY;
                MC_BR_RegMarkCalc001_0.Reset = 0;   
            }
            else if (MC_BR_RegMarkCalc001_0.Error == 1)
            {   /* an error occured */
                Step = STATE_ERROR;
                MC_BR_RegMarkCalc001_0.Reset = 0;
                MC_BR_RegMarkCalc001_0.Enable = 0;   
            }
            
        break;
        
/*********************************STATE_STOP_CALCULATION********************************/
        case STATE_STOP_CORRECTION:  /* STATE: stop the correction of the printmark position */
            MC_BR_RegMarkCapture001_0.Enable = 0;
            MC_BR_RegMarkCalc001_0.Enable = 0;
            MC_BR_Offset_0.Enable = 0;
            MC_BR_RegMarkCalc001_0.Calculate = 0;
            MC_BR_RegMarkCalc001_0.PositionError = 0;
            MC_BR_Offset_0.InitData = 0;
            
            Step = STATE_READY;
       break;
        
/********************************STATE_ERROR********************************************/        
        case STATE_ERROR:  /* STATE: in case of an occurred error all function blocks are reset */
            MC_BR_RegMarkCapture001_0.Enable = 0;
            MC_BR_RegMarkCapture001_0.SearchTrigger = 0;
            MC_BR_RegMarkCalc001_0.Enable = 0;
            MC_BR_RegMarkCalc001_0.Calculate = 0;
            MC_BR_RegMarkCalc001_0.Reset = 0;
            MC_BR_RegMarkCalc001_0.PositionError = 0;
            MC_BR_Offset_0.Enable = 0;
            MC_BR_Offset_0.InitData = 0;
            
            Step = STATE_WAIT;
        break;
        
/*******************************SEQUENCE END********************************************/        
    }
    
/* The function blocks MC_BR_RegMarkCapture001_0, MC_BR_RegMarkCalc001_0 and MC_BR_Offset are handled outside the 
   step sequence. This is because otherwise we will lose a few task cycles for the calculation of the compensation shift */    

/********************************MC_BR_RegMarkCapture001_0**************************/
    /* call the function block MC_BR_RegMarkCapture001_0 and copy the outputs into the status structure */
    MC_BR_RegMarkCapture001_0.Master = Axis1Obj;
    MC_BR_RegMarkCapture001_0.Axis = Axis2Obj;
    MC_BR_RegMarkCapture001_0.InitData = RegMarkControl.Command.InitCaptureData;
    MC_BR_RegMarkCapture001(&MC_BR_RegMarkCapture001_0);

    RegMarkControl.Status.Capture.ActLength = MC_BR_RegMarkCapture001_0.ActLength;
    RegMarkControl.Status.Capture.ActLengthIV = MC_BR_RegMarkCapture001_0.ActIntervalLength;
    RegMarkControl.Status.Capture.ActPosition = MC_BR_RegMarkCapture001_0.ActPosition;
    RegMarkControl.Status.Capture.LengthError = MC_BR_RegMarkCapture001_0.LengthError;
    RegMarkControl.Status.Capture.PositionError = MC_BR_RegMarkCapture001_0.PositionError;
    RegMarkControl.Status.Capture.MissedTriggers = MC_BR_RegMarkCapture001_0.MissedTriggers;
    RegMarkControl.Status.Capture.ValidTriggers = MC_BR_RegMarkCapture001_0.ValidTriggers;

    if (MC_BR_RegMarkCapture001_0.DataInitialized == 1)
    {   /* reset command if initialization of data is done */
        RegMarkControl.Command.InitCaptureData = 0;   
    }

    if (MC_BR_RegMarkCapture001_0.Error == 1) 
    {
        Step = STATE_ERROR;
        RegMarkControl.Status.ErrorID = MC_BR_RegMarkCapture001_0.ErrorID;
    }
    
/*****************************MC_BR_RegMarkCalc001_0********************************/
    /* if MC_BR_RegMarkCapture001_0 found a new valid printmark and evaluated a value for "PositionError" then a new
       shift distance has to be calculated by MC_BR_RegMarkCalc001_0 */
    if ((MC_BR_RegMarkCapture001_0.PositionError != RegMarkControl.Status.Capture.SavePositionError) &&
        (MC_BR_RegMarkCapture001_0.Valid == 1)) 
    {
        MC_BR_RegMarkCalc001_0.Enable = 1;
        MC_BR_RegMarkCalc001_0.Calculate = 1;
        MC_BR_RegMarkCalc001_0.PositionError = MC_BR_RegMarkCapture001_0.PositionError;
        MC_BR_RegMarkCalc001_0.LengthError = 0;
        MC_BR_RegMarkCalc001_0.ControllerParameters = RegMarkControl.Parameter.Calculation;
        RegMarkControl.Status.Capture.SavePositionError = MC_BR_RegMarkCapture001_0.PositionError;
        MC_BR_RegMarkCalc001_0.InitData = 1;
        Step = STATE_SHIFT;
    }
    MC_BR_RegMarkCalc001_0.Axis = Axis2Obj;
    MC_BR_RegMarkCalc001_0.InitData = RegMarkControl.Command.InitCalcData;
    MC_BR_RegMarkCalc001(&MC_BR_RegMarkCalc001_0);
    
    if (MC_BR_RegMarkCalc001_0.DataInitialized == 1)
    {   /* reset command if initialization of data is done */
        RegMarkControl.Command.InitCalcData = 0;   
    }
    if (MC_BR_RegMarkCalc001_0.Error == 1) 
    {
        Step = STATE_ERROR;
        RegMarkControl.Status.ErrorID = MC_BR_RegMarkCalc001_0.ErrorID;
    }

/*********************************MC_BR_Offset_0************************************/
    /* If a new shift value was calculated by MC_BR_RegMarkCalc001_0 then 
       this shift has to be added to the slave position  */
    if (MC_BR_RegMarkCalc001_0.Valid == 1)
    {
        MC_BR_RegMarkCalc001_0.Calculate = 0;
        MC_BR_Offset_0.Enable = 1;
        MC_BR_Offset_0.InitData = 1;
        MC_BR_Offset_0.Shift = (MC_BR_RegMarkCalc001_0.Shift + MC_BR_Offset_0.ActualShiftValue);   
    }
    MC_BR_Offset_0.Slave = Axis2Obj;
    MC_BR_Offset_0.Velocity = RegMarkControl.Parameter.Shift.Velocity;
    MC_BR_Offset_0.Acceleration = RegMarkControl.Parameter.Shift.Acceleration;
    MC_BR_Offset_0.ApplicationMode = RegMarkControl.Parameter.Shift.ApplicationMode;
    MC_BR_Offset_0.ShiftMode = RegMarkControl.Parameter.Shift.ShiftMode;
    MC_BR_Offset_0.ApplicationDistance = RegMarkControl.Parameter.Shift.ApplicationDistance;
    MC_BR_Offset(&MC_BR_Offset_0);

    if (MC_BR_Offset_0.Error == 1)
    {
        Step = STATE_ERROR;
        RegMarkControl.Status.ErrorID = MC_BR_Offset_0.ErrorID;
    }
    
}
