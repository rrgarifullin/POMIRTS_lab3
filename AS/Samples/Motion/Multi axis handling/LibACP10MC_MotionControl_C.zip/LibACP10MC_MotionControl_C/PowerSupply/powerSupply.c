/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************
 * Program: PowerSupply
 * File: powerSupply.c
 * Author: Bernecker + Rainer
 * Created: March 01, 2011
 ********************************************************************
 * Implementation of program PowerSupply
 ********************************************************************/

#ifdef _DEFAULT_INCLUDES
 #include <AsDefault.h>
#endif

/* defines of the state-constants */
#define STATE_READY             0
#define STATE_POWER_ON          1
#define STATE_POWER_OFF         2
#define STATE_START_POWERMETER  3
#define STATE_STOP_POWERMETER   4
#define STATE_RESTART_INTERVAL  5

_INIT void PowerSupply_init(void)
{
PsmStep = STATE_READY;

PowerSupply[PSM_INDEX].Parameter.IntervalTime = 10000; /* IntervalTime of 10sec */
}

_CYCLIC void PowerSupplyCyclic( void )
{
/*********************************************************************
                        Control Sequence
*********************************************************************/

/*************************** MC_READSTATUS **************************/
MC_ReadStatus_0.Enable = !MC_ReadStatus_0.Error;
MC_ReadStatus_0.Axis = PsmRef[PSM_INDEX];
MC_ReadStatus(&MC_ReadStatus_0);
PowerSupply[PSM_INDEX].AxisState.Disabled = MC_ReadStatus_0.Disabled;
PowerSupply[PSM_INDEX].AxisState.StandStill = MC_ReadStatus_0.StandStill;
PowerSupply[PSM_INDEX].AxisState.Stopping = MC_ReadStatus_0.Stopping;
PowerSupply[PSM_INDEX].AxisState.Homing = MC_ReadStatus_0.Homing;
PowerSupply[PSM_INDEX].AxisState.DiscreteMotion = MC_ReadStatus_0.DiscreteMotion;
PowerSupply[PSM_INDEX].AxisState.ContinuousMotion = MC_ReadStatus_0.ContinuousMotion;
PowerSupply[PSM_INDEX].AxisState.SynchronizedMotion = MC_ReadStatus_0.SynchronizedMotion;
PowerSupply[PSM_INDEX].AxisState.ErrorStop = MC_ReadStatus_0.Errorstop;

/************************ MC_BR_READDRIVESTATUS *********************/
MC_BR_ReadDriveStatus_0.Enable = !MC_BR_ReadDriveStatus_0.Error;
MC_BR_ReadDriveStatus_0.Axis = PsmRef[PSM_INDEX];
MC_BR_ReadDriveStatus_0.AdrDriveStatus = (UDINT)&(PowerSupply[PSM_INDEX].Status.DriveStatus);
MC_BR_ReadDriveStatus(&MC_BR_ReadDriveStatus_0);

switch (PsmStep)
{
/********************************* READY ****************************/
    case STATE_READY: /*STATE: Waiting for Commands */
        if (((GlobalCommand.Power == 1) || (PowerSupply[PSM_INDEX].Command.Power == 1)) &&
             (MC_Power_0.Status == 0))
        {
            PsmStep = STATE_POWER_ON;
        }
        else if ((GlobalCommand.Power == 0) && (PowerSupply[PSM_INDEX].Command.Power == 0) &&
                 (MC_Power_0.Status == 1))
        {
            PsmStep = STATE_POWER_OFF;
        }
        else if (PowerSupply[PSM_INDEX].Command.StartPowerMeter == 1)
        {
            PowerSupply[PSM_INDEX].Command.StartPowerMeter = 0;
            PsmStep = STATE_START_POWERMETER;
        }
        else if (PowerSupply[PSM_INDEX].Command.StopPowerMeter == 1)
        {
            PowerSupply[PSM_INDEX].Command.StopPowerMeter = 0;
            PsmStep = STATE_STOP_POWERMETER;
        }
        else if (PowerSupply[PSM_INDEX].Command.RestartInterval == 1)
        {
            PowerSupply[PSM_INDEX].Command.RestartInterval = 0;
            MC_BR_PowerMeter_0.RestartInterval = 0;
            PsmStep = STATE_RESTART_INTERVAL;
        }
    break;

/*************************** POWER ON ********************************/
    case STATE_POWER_ON:
        MC_Power_0.Enable = 1;
        if (MC_Power_0.Status == 1)
        {
            PsmStep = STATE_READY;
        }

        /* if a power error occured switch off controller */
        if (MC_Power_0.Error == 1)
        {
            MC_Power_0.Enable = 0;
        }
    break;

/************************** POWER OFF *******************************/
    case STATE_POWER_OFF:
        MC_Power_0.Enable = 0;
        if (MC_Power_0.Status == 0)
        {
            PsmStep = STATE_READY;
        }
    break;

/************************ START POWERMETER **************************/    
    case STATE_START_POWERMETER:
        MC_BR_PowerMeter_0.Enable = 1;
        MC_BR_PowerMeter_0.Mode = mcONLY_PSM;
        MC_BR_PowerMeter_0.IntervalTime = PowerSupply[PSM_INDEX].Parameter.IntervalTime;

        if (MC_BR_PowerMeter_0.Valid == 1)
        {
            PsmStep = STATE_READY;
        }

        /* check if error occured */
        if (MC_BR_PowerMeter_0.Error == 1)
        {
            MC_BR_PowerMeter_0.Enable = 0;
            PsmStep = STATE_READY;
        }
    break;

/************************ STOP POWERMETER ***************************/
    case STATE_STOP_POWERMETER:
        MC_BR_PowerMeter_0.Enable = 0;

        if (MC_BR_PowerMeter_0.Valid == 0)
        {
            PsmStep = STATE_READY;
        }
    break;

/********************** STATE RESTART INTERVAL **********************/    
    case STATE_RESTART_INTERVAL:
        MC_BR_PowerMeter_0.RestartInterval = 1;
        PsmStep = STATE_READY;
    break;

/************************* SEQUENCE_END *****************************/
}

/*********************************************************************
                    Function Block Calls
*********************************************************************/

/************************* MC_POWER *********************************/
MC_Power_0.Axis = PsmRef[PSM_INDEX];
MC_Power(&MC_Power_0);
PowerSupplyOn = MC_Power_0.Status;

/**********************MC_BR_POWERMETER *****************************/
MC_BR_PowerMeter_0.Axis = PsmRef[PSM_INDEX];
MC_BR_PowerMeter(&MC_BR_PowerMeter_0);
PowerSupply[PSM_INDEX].Status.PowerData.IntervalNumber        = MC_BR_PowerMeter_0.PowerData.IntervalNumber;
PowerSupply[PSM_INDEX].Status.PowerData.IntervalDuration      = MC_BR_PowerMeter_0.PowerData.IntervalDuration;
PowerSupply[PSM_INDEX].Status.PowerData.AverageActivePower    = MC_BR_PowerMeter_0.PowerData.AverageActivePower;
PowerSupply[PSM_INDEX].Status.PowerData.AverageReactivePower  = MC_BR_PowerMeter_0.PowerData.AverageReactivePower;
PowerSupply[PSM_INDEX].Status.PowerData.MaximumActivePower    = MC_BR_PowerMeter_0.PowerData.MaximumActivePower;
PowerSupply[PSM_INDEX].Status.PowerData.MinimalActivePower    = MC_BR_PowerMeter_0.PowerData.MinimalActivePower;
PowerSupply[PSM_INDEX].Status.PowerData.ConsumedEnergy        = MC_BR_PowerMeter_0.PowerData.ConsumedEnergy;
PowerSupply[PSM_INDEX].Status.PowerData.RegeneratedEnergy     = MC_BR_PowerMeter_0.PowerData.RegeneratedEnergy;
PowerSupply[PSM_INDEX].Status.PowerData.EnergyBalance         = MC_BR_PowerMeter_0.PowerData.EnergyBalance;

}
