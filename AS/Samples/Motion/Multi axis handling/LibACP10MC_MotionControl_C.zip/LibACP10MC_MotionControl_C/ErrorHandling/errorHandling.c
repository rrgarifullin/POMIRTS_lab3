/*******************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************
 * PROGRAM: ErrorHandling
 * File: errorHandling.c
 * Author: Bernecker + Rainer
 * Created: March 01, 2011
 ********************************************************************
 * Implementation of Program ErrorHandling
 ********************************************************************/

#ifdef _DEFAULT_INCLUDES
 #include <AsDefault.h>
#endif
#include <string.h>

/* ErrorSteps */
#define STATE_CONFIG_FBS        00
#define STATE_WAIT              01
#define STATE_ERROR_HANDLING    02
#define STATE_INTERNAL_ERROR    03

/* AcknowledgeSteps */
#define STATE_ERROR_SCAN        10
#define STATE_ERROR_ACKNOWLEDGE 11
#define STATE_RESET             12

_INIT void ErrorHandling_init(void)
{
    AcknowledgeStep = STATE_ERROR_SCAN;
}

_CYCLIC void ErrorHandling_cyclic(void)
{
/************************** ERROR_CHECK *****************************/
/* check if at least one of the used FBs reports an error */
if ((MC_BR_AxisErrorCollector_0.Error == 1) || (MC_Reset_0.Error == 1))
{
    ErrorStep = STATE_INTERNAL_ERROR;
}
for (configAxisIndex=0;configAxisIndex<TOTAL_AXES;configAxisIndex++)
{
    if ((MC_BR_ReadAxisError_0[configAxisIndex].Error == 1) || (MC_ReadStatus_0[configAxisIndex].Error == 1))
    {
        ErrorStep = STATE_INTERNAL_ERROR;
        break;
    }
}

switch (ErrorStep)
{
/*********************** CONFIGURATE_FBS ****************************/
    case STATE_CONFIG_FBS: /* configurate the used FBs for the error handling */
        MC_BR_AxisErrorCollector_0.Axis = mcALL_AXES;
        MC_BR_AxisErrorCollector_0.Enable = 1;

        /* configurate the MC_BR_ReadAxisError_0-FBs for all single axes */
        for (axisIndex=0;axisIndex<=AXIS_MAX_INDEX;axisIndex++)
        {
            MC_BR_ReadAxisError_0[axisIndex].Axis = AxisRef[axisIndex];
            MC_BR_ReadAxisError_0[axisIndex].Enable = 1;
            MC_BR_ReadAxisError_0[axisIndex].Configuration.Format = mcWRAP;
            MC_BR_ReadAxisError_0[axisIndex].Configuration.LineLength = sizeof(Axis[axisIndex].Error.ErrorText[0]);
            MC_BR_ReadAxisError_0[axisIndex].Configuration.DataLength = sizeof(Axis[axisIndex].Error.ErrorText);
            MC_BR_ReadAxisError_0[axisIndex].Configuration.DataAddress = (UDINT)&(Axis[axisIndex].Error.ErrorText[0]);
            strcpy((void*)&MC_BR_ReadAxisError_0[axisIndex].Configuration.DataObjectName, "acp10etxen");
            MC_BR_ReadAxisError_0[axisIndex].Mode = mcTEXT;

            MC_ReadStatus_0[axisIndex].Axis = AxisRef[axisIndex];
            MC_ReadStatus_0[axisIndex].Enable = 1;
        }

        /* configurate the MC_BR_ReadAxisError_0-FBs for all master axes */
        for (masterIndex=0;masterIndex<=MASTER_MAX_INDEX;masterIndex++)
        {
            MC_BR_ReadAxisError_0[masterIndex+AXIS_NUMBER].Axis = MasterRef[masterIndex];
            MC_BR_ReadAxisError_0[masterIndex+AXIS_NUMBER].Enable = 1;
            MC_BR_ReadAxisError_0[masterIndex+AXIS_NUMBER].Configuration.Format = mcWRAP;
            MC_BR_ReadAxisError_0[masterIndex+AXIS_NUMBER].Configuration.LineLength = sizeof(Master[masterIndex].Error.ErrorText[0]);
            MC_BR_ReadAxisError_0[masterIndex+AXIS_NUMBER].Configuration.DataLength = sizeof(Master[masterIndex].Error.ErrorText);
            MC_BR_ReadAxisError_0[masterIndex+AXIS_NUMBER].Configuration.DataAddress = (UDINT)&(Master[masterIndex].Error.ErrorText[0]);
            strcpy((void*)&MC_BR_ReadAxisError_0[masterIndex+AXIS_NUMBER].Configuration.DataObjectName, "acp10etxen");
            MC_BR_ReadAxisError_0[masterIndex+AXIS_NUMBER].Mode = mcTEXT;

            MC_ReadStatus_0[masterIndex+AXIS_NUMBER].Axis = MasterRef[masterIndex];
            MC_ReadStatus_0[masterIndex+AXIS_NUMBER].Enable = 1;
        }

        /* configurate the MC_BR_ReadAxisError_0-FBs for all slave axes */
        for (slaveIndex=0;slaveIndex<=SLAVE_MAX_INDEX;slaveIndex++)
        {
            MC_BR_ReadAxisError_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Axis = SlaveRef[slaveIndex];
            MC_BR_ReadAxisError_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Enable = 1;
            MC_BR_ReadAxisError_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Configuration.Format = mcWRAP;
            MC_BR_ReadAxisError_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Configuration.LineLength = sizeof(Slave[slaveIndex].Error.ErrorText[0]);
            MC_BR_ReadAxisError_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Configuration.DataLength = sizeof(Slave[slaveIndex].Error.ErrorText);
            MC_BR_ReadAxisError_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Configuration.DataAddress = (UDINT)&(Slave[slaveIndex].Error.ErrorText[0]);
            strcpy((void*)&MC_BR_ReadAxisError_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Configuration.DataObjectName, "acp10etxen");
            MC_BR_ReadAxisError_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Mode = mcTEXT;

            MC_ReadStatus_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Axis = SlaveRef[slaveIndex];
            MC_ReadStatus_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Enable = 1;
        }

         /* configurate the MC_BR_ReadAxisError_0-FBs for all power supply modules */
        for (psmIndex=0;psmIndex<=PSM_MAX_INDEX;psmIndex++)
        {
            MC_BR_ReadAxisError_0[psmIndex+AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER].Axis = PsmRef[psmIndex];
            MC_BR_ReadAxisError_0[psmIndex+AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER].Enable = 1;
            MC_BR_ReadAxisError_0[psmIndex+AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER].Configuration.Format = mcWRAP;
            MC_BR_ReadAxisError_0[psmIndex+AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER].Configuration.LineLength = sizeof(PowerSupply[psmIndex].Error.ErrorText[0]);
            MC_BR_ReadAxisError_0[psmIndex+AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER].Configuration.DataLength = sizeof(PowerSupply[psmIndex].Error.ErrorText);
            MC_BR_ReadAxisError_0[psmIndex+AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER].Configuration.DataAddress = (UDINT)&(PowerSupply[psmIndex].Error.ErrorText[0]);
            strcpy((void*)&MC_BR_ReadAxisError_0[psmIndex+AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER].Configuration.DataObjectName, "acp10etxen");
            MC_BR_ReadAxisError_0[psmIndex+AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER].Mode = mcTEXT;

            MC_ReadStatus_0[psmIndex+AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER].Axis = PsmRef[psmIndex];
            MC_ReadStatus_0[psmIndex+AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER].Enable = 1;
        }

        ErrorStep = STATE_WAIT;
    break;
/********************* CHECK_AXES_FOR_ERRORS ************************/
    case STATE_WAIT: /* check if at least on one of the axes an error occured */
        if ((MC_BR_AxisErrorCollector_0.AxisError == 1) ||
            (MC_BR_AxisErrorCollector_0.AxisWarning == 1) ||
            (MC_BR_AxisErrorCollector_0.FunctionBlockError == 1) ||
            (MC_BR_AxisErrorCollector_0.Errorstop == 1))
        {
            ErrorStep = STATE_ERROR_HANDLING;   
        }
        else
        {
            strcpy((void*)&GlobalError.AxisTyp,"");
            GlobalError.AxisIndex = 0;
            GlobalError.ErrorRecord.Info = 0;
            GlobalError.ErrorRecord.Number = 0;
            GlobalError.ErrorRecord.ParID = 0;
            strcpy((void*)&GlobalError.ErrorText,"");
            memset(&GlobalError,0x00,sizeof(GlobalError));
        }
    break;

/********************* HANDLE_ACTIVE_ERRORS *************************/
    case STATE_ERROR_HANDLING: /* check witch axis is in Errorstop and witch axes has to be stopped */
        /* the power supply module is not checked for axis state Errorstop */
        /* check if a single axis has to be stopped */
        for (axisIndex=0;axisIndex<=AXIS_MAX_INDEX;axisIndex++)
        {
            if (MC_ReadStatus_0[axisIndex].Errorstop == 1)
            {
                Axis[axisIndex].Command.Stop = 1;
            }
        }
        /* check if the master slave combination has to be stopped */
        for (masterIndex=0;masterIndex<=MASTER_MAX_INDEX;masterIndex++)
        {
            if (MC_ReadStatus_0[masterIndex+AXIS_NUMBER].Errorstop == 1)
            {
                for (masterIndex=0;masterIndex<MASTER_NUMBER;masterIndex++)
                {
                    Master[masterIndex].Command.Stop = 1;
                }

                for (slaveIndex=0;slaveIndex<SLAVE_NUMBER;slaveIndex++)
                {
                    Slave[slaveIndex].Command.Stop = 1;
                }
            }
        }
        /* check if the master slave combination has to be stopped */
        for (slaveIndex=0;slaveIndex<=SLAVE_MAX_INDEX;slaveIndex++)
        {
            if (MC_ReadStatus_0[slaveIndex+AXIS_NUMBER+MASTER_NUMBER].Errorstop == 1)
            {
                for (masterIndex=0;masterIndex<MASTER_NUMBER;masterIndex++)
                {
                    Master[masterIndex].Command.Stop = 1;
                }

                for (slaveIndex=0;slaveIndex<SLAVE_NUMBER;slaveIndex++)
                {
                    Slave[slaveIndex].Command.Stop = 1;
                }
                break;
            }
        }
        /******************************* STEP SEQUENCE OF ERROR ACKNOWLEDGE *******************************/
        switch (AcknowledgeStep)
        {
            /************************ SEARCH FOR_ERRORS *************************/
            case STATE_ERROR_SCAN: /* check if an error is active on one of the axis */
                ErrorStep = STATE_WAIT;
                for (totalAxisIndex=0;totalAxisIndex<TOTAL_AXES;totalAxisIndex++)
                {
                    if ((MC_BR_ReadAxisError_0[totalAxisIndex].AxisErrorCount > 0) ||
                        (MC_BR_ReadAxisError_0[totalAxisIndex].AxisWarningCount > 0) ||
                        (MC_BR_ReadAxisError_0[totalAxisIndex].FunctionBlockErrorCount > 0))
                    {
                        AcknowledgeStep = STATE_ERROR_ACKNOWLEDGE;
                        ErrorStep = STATE_ERROR_HANDLING;
                        break;
                    }
                    else if (MC_ReadStatus_0[totalAxisIndex].Errorstop == 1)
                    {
                        AcknowledgeStep = STATE_RESET;
                        ErrorStep = STATE_ERROR_HANDLING;
                        break;
                    }
                }
            break;

            /************************ WAIT FOR ACKNOWLEDGE **********************/
            case STATE_ERROR_ACKNOWLEDGE: /*Acknowledge the occured errors after user command*/
                /* copy the actual error information to the global error structure*/
                if (totalAxisIndex < AXIS_NUMBER)
                {
                    strcpy((void*)&GlobalError.AxisTyp,"Axis");
                    strcpy((void*)&GlobalError.ErrorText, (void*)&Axis[totalAxisIndex].Error.ErrorText);
                    GlobalError.ErrorRecord = Axis[totalAxisIndex].Error.ErrorRecord;
                }
                else if (totalAxisIndex < (AXIS_NUMBER+MASTER_NUMBER))
                {
                    strcpy((void*)&GlobalError.AxisTyp,"Master");
                    strcpy((void*)&GlobalError.ErrorText, (void*)&Master[totalAxisIndex-AXIS_NUMBER].Error.ErrorText);
                    GlobalError.ErrorRecord = Master[totalAxisIndex-AXIS_NUMBER].Error.ErrorRecord;
                }
                else if (totalAxisIndex < (AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER))
                {
                    strcpy((void*)&GlobalError.AxisTyp,"Slave");
                    strcpy((void*)&GlobalError.ErrorText, (void*)&Slave[totalAxisIndex-(AXIS_NUMBER+MASTER_NUMBER)].Error.ErrorText);
                    GlobalError.ErrorRecord = Slave[totalAxisIndex-(AXIS_NUMBER+MASTER_NUMBER)].Error.ErrorRecord;
                }
                else if (totalAxisIndex < (AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER+PSM_NUMBER))
                {
                    strcpy((void*)&GlobalError.AxisTyp,"PSM");
                    strcpy((void*)&GlobalError.ErrorText, (void*)&PowerSupply[totalAxisIndex-(AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER)].Error.ErrorText);
                    GlobalError.ErrorRecord = PowerSupply[totalAxisIndex-(AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER)].Error.ErrorRecord;
                }
                GlobalError.AxisIndex = totalAxisIndex;

                if (GlobalCommand.ErrorAcknowledge == 1)
                {
                    GlobalCommand.ErrorAcknowledge = 0;
                    MC_BR_ReadAxisError_0[totalAxisIndex].Acknowledge = 1;
                }
                else if (MC_BR_ReadAxisError_0[totalAxisIndex].Acknowledge == 1)
                {
                    MC_BR_ReadAxisError_0[totalAxisIndex].Acknowledge = 0;
                    AcknowledgeStep = STATE_ERROR_SCAN;
                }
            break;

            /********************* RESET AXES IN ERRORSTOP **********************/
            case STATE_RESET: /* check if one of the axes is in Errorstop and reset it */
                if (totalAxisIndex < AXIS_NUMBER)
                {
                    MC_Reset_0.Axis = AxisRef[totalAxisIndex];  
                }
                else if (totalAxisIndex < (AXIS_NUMBER+MASTER_NUMBER))
                {
                    MC_Reset_0.Axis = MasterRef[totalAxisIndex-AXIS_NUMBER];
                }
                else if (totalAxisIndex < (AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER))
                {
                    MC_Reset_0.Axis= SlaveRef[totalAxisIndex-(AXIS_NUMBER+MASTER_NUMBER)];
                }
                else
                {
                    MC_Reset_0.Axis= PsmRef[totalAxisIndex-(AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER)];
                }
                MC_Reset_0.Execute = 1;

                if (MC_Reset_0.Done == 1) 
                {
                    MC_Reset_0.Execute = 0; 
                    AcknowledgeStep = STATE_ERROR_SCAN;  
                }
            break;
        }
        /*************************** END OF STEP SEQUENCE OF ERROR ACKNOWLEDGE *******************************/
    break;

/**************** DEACTIVATE USED FBS IN CASE OF ERROR **************/
    case STATE_INTERNAL_ERROR: /* if at least one of the FBs in this task reports an error, all FBs are restarted*/
        MC_BR_AxisErrorCollector_0.Enable = 0;
        MC_Reset_0.Execute = 0;
        for (configAxisIndex=0;configAxisIndex<TOTAL_AXES;configAxisIndex++)
        {
            MC_BR_ReadAxisError_0[configAxisIndex].Enable = 0;
            MC_ReadStatus_0[configAxisIndex].Enable = 0;
        }
        ErrorStep = STATE_CONFIG_FBS;
    break;
}

/************************* CALL FBS *********************************/
MC_BR_AxisErrorCollector(&MC_BR_AxisErrorCollector_0);

for (configAxisIndex=0;configAxisIndex<TOTAL_AXES;configAxisIndex++)
{
    MC_BR_ReadAxisError(&MC_BR_ReadAxisError_0[configAxisIndex]);
    if (configAxisIndex < AXIS_NUMBER)
    {
        Axis[configAxisIndex].Error.AxisErrorCount = MC_BR_ReadAxisError_0[configAxisIndex].AxisErrorCount;
        Axis[configAxisIndex].Error.AxisWarningCount = MC_BR_ReadAxisError_0[configAxisIndex].AxisWarningCount;
        Axis[configAxisIndex].Error.FunctionBlockErrorCount = MC_BR_ReadAxisError_0[configAxisIndex].FunctionBlockErrorCount;
        Axis[configAxisIndex].Error.ErrorRecord = MC_BR_ReadAxisError_0[configAxisIndex].ErrorRecord;
    }
    else if (configAxisIndex < (AXIS_NUMBER+MASTER_NUMBER))
    {
        Master[configAxisIndex-AXIS_NUMBER].Error.AxisErrorCount = MC_BR_ReadAxisError_0[configAxisIndex].AxisErrorCount;
        Master[configAxisIndex-AXIS_NUMBER].Error.AxisWarningCount = MC_BR_ReadAxisError_0[configAxisIndex].AxisWarningCount;
        Master[configAxisIndex-AXIS_NUMBER].Error.FunctionBlockErrorCount = MC_BR_ReadAxisError_0[configAxisIndex].FunctionBlockErrorCount;
        Master[configAxisIndex-AXIS_NUMBER].Error.ErrorRecord = MC_BR_ReadAxisError_0[configAxisIndex].ErrorRecord;
    }
    else if (configAxisIndex < (AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER))
    {
        Slave[configAxisIndex-(AXIS_NUMBER+MASTER_NUMBER)].Error.AxisErrorCount = MC_BR_ReadAxisError_0[configAxisIndex].AxisErrorCount;
        Slave[configAxisIndex-(AXIS_NUMBER+MASTER_NUMBER)].Error.AxisWarningCount = MC_BR_ReadAxisError_0[configAxisIndex].AxisWarningCount;
        Slave[configAxisIndex-(AXIS_NUMBER+MASTER_NUMBER)].Error.FunctionBlockErrorCount = MC_BR_ReadAxisError_0[configAxisIndex].FunctionBlockErrorCount;
        Slave[configAxisIndex-(AXIS_NUMBER+MASTER_NUMBER)].Error.ErrorRecord = MC_BR_ReadAxisError_0[configAxisIndex].ErrorRecord;
    }
    else if (configAxisIndex < (AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER+PSM_NUMBER))
    {
        PowerSupply[configAxisIndex-(AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER)].Error.AxisErrorCount = MC_BR_ReadAxisError_0[configAxisIndex].AxisErrorCount;
        PowerSupply[configAxisIndex-(AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER)].Error.AxisWarningCount = MC_BR_ReadAxisError_0[configAxisIndex].AxisWarningCount;
        PowerSupply[configAxisIndex-(AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER)].Error.FunctionBlockErrorCount = MC_BR_ReadAxisError_0[configAxisIndex].FunctionBlockErrorCount;
        PowerSupply[configAxisIndex-(AXIS_NUMBER+MASTER_NUMBER+SLAVE_NUMBER)].Error.ErrorRecord = MC_BR_ReadAxisError_0[configAxisIndex].ErrorRecord;
    }
    MC_ReadStatus(&MC_ReadStatus_0[configAxisIndex]); 
}

MC_Reset(&MC_Reset_0);
}
