/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************
 * Program: Automat
 * File: CrossCutter.c
 * Author: Bernecker + Rainer
 * Created: December 01, 2009
 *******************************************************************/

#include <bur/plctypes.h>
#ifdef _DEFAULT_INCLUDES
 #include <AsDefault.h>
#endif

void CrossCutter()
{
    /*general automat parameter*/
        AutData.Master             = MasterRef[0];
        AutData.MaxMasterVelocity  = 1000;

    /*Automat STATE 0 Basis State*/
        AutData.State[0].Event[0].Type       = ncST_END;
        AutData.State[0].Event[0].Attribute  = ncAT_ONCE;
        AutData.State[0].Event[0].NextState  = 1;

    /*Automat STATE 1 Standstill*/
        AutData.State[1].CamProfileIndex     = 0xFFFE;
        AutData.State[1].MasterFactor        = 200;
        AutData.State[1].SlaveFactor         = 0;
        AutData.State[1].CompMode            = ncWITH_CAM;
        AutData.State[1].MasterCompDistance  = 1000;
        AutData.State[1].SlaveCompDistance   = 0;

        AutData.State[1].Event[0].Type       = ncSIGNAL1;
        AutData.State[1].Event[0].Attribute  = ncST_END;
        AutData.State[1].Event[0].NextState  = 2;

    /*Automat STATE 2 Move Slave to Cutting position*/
        AutData.State[2].CamProfileIndex     = 0xFFFF;
        AutData.State[2].MasterFactor        = 200;
        AutData.State[2].SlaveFactor         = 200;
        AutData.State[2].CompMode            = ncWITH_CAM;
        AutData.State[2].MasterCompDistance  = 500;
        AutData.State[2].SlaveCompDistance   = 1800;

        AutData.State[2].Event[0].Type       = ncST_END;
        AutData.State[2].Event[0].Attribute  = ncST_END;
        AutData.State[2].Event[0].NextState  = 3;

    /*Automat STATE 3 Execute one cut every master period */
        AutData.State[3].CamProfileIndex     = 0xFFFF;
        AutData.State[3].MasterFactor        = 200;
        AutData.State[3].SlaveFactor         = 200;
        AutData.State[3].CompMode            = ncWITH_CAM;
        AutData.State[3].MasterCompDistance  = 1000;
        AutData.State[3].SlaveCompDistance   = 3600;

        AutData.State[3].Event[0].Type       = ncSIGNAL2;
        AutData.State[3].Event[0].Attribute  = ncST_END;
        AutData.State[3].Event[0].NextState  = 4;

        AutData.State[3].Event[1].Type       = ncST_END;
        AutData.State[3].Event[1].Attribute  = ncST_END;
        AutData.State[3].Event[1].NextState  = 3;

    /*Automat STATE 4 Stop Motion at Starting Point*/
        AutData.State[4].CamProfileIndex     = 0xFFFF;
        AutData.State[4].MasterFactor        = 200;
        AutData.State[4].SlaveFactor         = 0;
        AutData.State[4].CompMode            = ncWITH_CAM;
        AutData.State[4].MasterCompDistance  = 500;
        AutData.State[4].SlaveCompDistance   = 1800;

        AutData.State[4].Event[0].Type       = ncST_END;
        AutData.State[4].Event[0].Attribute  = ncST_END;
        AutData.State[4].Event[0].NextState  = 1;

}


