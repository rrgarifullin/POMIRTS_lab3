/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************
 * Program: Automat
 * File: FlyingSaw.c
 * Author: Bernecker + Rainer
 * Created: December 01, 2009
 *******************************************************************/
 
#include <bur/plctypes.h>
#ifdef _DEFAULT_INCLUDES
 #include <AsDefault.h>
#endif

void FlyingSaw()
{
    /*general automat parameter*/
        AutData.Master             = MasterRef[0];
        AutData.StartPosition      = 0;
        AutData.StartInterval      = 1000;
        AutData.MaxMasterVelocity  = 1000;

    /*Automat STATE 0 BasicControl State*/
        AutData.State[0].Event[0].Type         = ncST_END;
        AutData.State[0].Event[0].Attribute    = ncAT_ONCE;
        AutData.State[0].Event[0].NextState    = 1;

    /*Automat STATE 1 Standstill*/
        AutData.State[1].CamProfileIndex       = 0xFFFF;
        AutData.State[1].MasterFactor          = 200;
        AutData.State[1].SlaveFactor           = 0;
        AutData.State[1].CompMode              = ncONLYCOMP;
        AutData.State[1].MasterCompDistance    = 800;
        AutData.State[1].SlaveCompDistance     = 0;

        AutData.State[1].Event[0].Type         = ncS_START;
        AutData.State[1].Event[0].Attribute    = ncAT_ONCE;
        AutData.State[1].Event[0].NextState    = 2;

    /*Automat STATE 2 Synchronous movement*/
        AutData.State[2].CamProfileIndex       = 0xFFFF;
        AutData.State[2].MasterFactor          = 500;
        AutData.State[2].SlaveFactor           = 500;
        AutData.State[2].CompMode              = ncONLYCOMP;
        AutData.State[2].MasterCompDistance    = 100;
        AutData.State[2].SlaveCompDistance     = 100;

        AutData.State[2].Event[0].Type         = ncST_END;
        AutData.State[2].Event[0].Attribute    = ncST_END;
        AutData.State[2].Event[0].NextState    = 3;

    /*Automat STATE 3 Return to starting position*/
        AutData.State[3].CamProfileIndex       = 0xFFFF;
        AutData.State[3].MasterFactor          = 100;
        AutData.State[3].SlaveFactor           = 0;
        AutData.State[3].CompMode              = ncONLYCOMP;
        AutData.State[3].MasterCompDistance    = 800;
        AutData.State[3].SlaveCompDistance     = -600;

        AutData.State[3].Event[0].Type         = ncST_END;
        AutData.State[3].Event[0].Attribute    = ncST_END;
        AutData.State[3].Event[0].NextState    = 1;

}


