/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************
 * Program: AxisConfiguration
 * File: AxisConfiguration.c
 * Author: Bernecker + Rainer
 * Created: March 01, 2011
 ********************************************************************
 * Implementation of program AxisConfiguration
 ********************************************************************/

#ifdef _DEFAULT_INCLUDES
 #include <AsDefault.h>
#endif

_INIT void AxisConfiguration_init(void)
{
    PsmRef[0]    = (UDINT)&gAxis01; /* axis reference of the power supply module */
    AxisRef[0]   = (UDINT)&gAxis02; /* axis reference of first single axis */
    AxisRef[1]   = (UDINT)&gAxis03; /* axis reference of second singel axis */
    MasterRef[0] = (UDINT)&gAxis04; /* axis reference of first master axis */
    SlaveRef[0]  = (UDINT)&gAxis05; /* axis reference of first slave axis */

    PowerSupplyOn = 1; /* if a power supply is used, this variable is reset in the according task */
}


