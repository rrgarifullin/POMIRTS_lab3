/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************
 * Program: DMLib1_C
 * File: DMLib_CInit.c
 * Author: Bernecker + Rainer
 * Created: March 01, 2010
 ********************************************************************
 * Implementation of program DMLib_C
 ********************************************************************/

#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
 #include <AsDefault.h>
#endif

#define WAIT_FOR_COMMAND 0

void _INIT DMLib_CInit( void )
{
	/* Initialize the state machine to be in the wait state */
	State = WAIT_FOR_COMMAND;

	/* Initialize the DMLib_0 variables */
	DMLib_0.BlockNumber = 1;
	DMLib_0.Commands.Clear = 0;
	DMLib_0.Commands.Free = 0;
	DMLib_0.Commands.Store = 0;

	DMLib_0.StoreParameters.Data = (UDINT)&Data[0];
	DMxstore_0.ident = DMLib_0.StoreParameters.Ident = 0;
	DMxstore_0.name = DMLib_0.StoreParameters.Name = (UDINT)&Name;
	DMxstore_0.size = DMLib_0.StoreParameters.Size = sizeof(Data[0]) * 64;
}
