/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer 
 ********************************************************************
 * Program: DMLib1_C
 * File: DMLib_CCyclic.c
 * Author: Bernecker + Rainer
 * Created: March 01, 2010
 ********************************************************************
 * Implementation of program DMLib_C
 ********************************************************************/

#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
 #include <AsDefault.h>
#endif


#define WAIT_FOR_COMMAND	0
#define FREE_MEMORY			10	
#define STORE_DATA			20	
#define CLEAR_MEMORY		30	


void _CYCLIC DMLib_CCyclic( void )
{
	switch (State) {
	
		case WAIT_FOR_COMMAND:
			if (DMLib_0.Commands.Free == 1) {
	  			/* Reset the free command { go to the FREE_MEMORY state */
				DMLib_0.Commands.Free = 0;
				State = FREE_MEMORY;	
			}
			else if (DMLib_0.Commands.Store == 1) {
				/* Reset the store command { go to the STORE_DATA state */
				DMLib_0.Commands.Store = 0;
				State = STORE_DATA;
			}
			else if (DMLib_0.Commands.Clear == 1) {	
				/* Reset the clear command { go to the CLEAR_MEMORY state */
				DMLib_0.Commands.Clear = 0;
				State = CLEAR_MEMORY;
			
			}
			
		break;	
		
		/*************************************************************************
			Free memory up using the DMxfree function block
		 *************************************************************************/	
		case FREE_MEMORY:	
			DMxfree_0.block_no = DMLib_0.BlockNumber;
			DMxfree_0.enable = 1;
		
			/* Call Function block instance */
			DMxfree(&DMxfree_0);
		
			/* Memory was successfully freed */
			if (DMxfree_0.status == 0) {
	  			DMxfree_0.enable = 0;
				DMLib_0.Status = 0;
				State = WAIT_FOR_COMMAND;
			}
			/* An error occured */	
			else {	
				DMxfree_0.enable = 0;
				DMLib_0.Status = DMxfree_0.status;
				State = WAIT_FOR_COMMAND;	
			}	
		
		break;
		
		/*************************************************************************
			Store the data using the DMxstore function block
		 *************************************************************************/	
		case STORE_DATA:
			DMxstore_0.data = DMLib_0.StoreParameters.Data;
			DMxstore_0.ident = DMLib_0.StoreParameters.Ident;
			DMxstore_0.name = DMLib_0.StoreParameters.Name;
			DMxstore_0.size = DMLib_0.StoreParameters.Size;
			DMxstore_0.block_no = DMLib_0.BlockNumber;
			DMxstore_0.enable = 1;
		
			/* Call Function block instance */
			DMxstore(&DMxstore_0);
		
			/* Data was successfully stored */
			if (DMxstore_0.status == 0) {
	  			DMxstore_0.enable = 0;
				DMLib_0.Status = 0;
				State = WAIT_FOR_COMMAND;
			}
			/* An error occured */	
			else {	 
				DMxstore_0.enable = 0;
				DMLib_0.Status = DMxstore_0.status;
				State = WAIT_FOR_COMMAND;	
			}
			
		break;	
		
		/*************************************************************************
			Clear memory up using the DMxclear function block
		 *************************************************************************/	
		case CLEAR_MEMORY:	
			DMxclear_0.block_no = DMLib_0.BlockNumber;
			DMxclear_0.enable = 1;
		
			/* Call Function block instance */
			DMxclear(&DMxclear_0);
		
			/* Memory was successfully cleared */
			if (DMxclear_0.status == 0) {
	  			DMxclear_0.enable = 0;
				DMLib_0.Status = 0;
				State = WAIT_FOR_COMMAND;
			}
			/* An error occured */	
			else {	
				DMxclear_0.enable = 0;
				DMLib_0.Status = DMxclear_0.status;
				State = WAIT_FOR_COMMAND;	
			}			
		break;	
	
	} /* end switch */	

} /* end cyclic */
