/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer Industrie-Elektronik Ges.m.b.H.
 ********************************************************************
 * Program: SimDACyl4
 * File: main.c
 * Author: zehetleitnek
 * Created: Wed Feb 11 16:26:58 2009
 ********************************************************************
 * Implementation of program SimDACyl4
 ********************************************************************
 * Generated with B&R Automation Studio Target for Simulink V2.1
 ********************************************************************/

#define _ASMATH_
#define ASSTRING_H_
#include <bur/plctypes.h>
#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "SimDACyl4.h"
#include "rtwtypes.h"

/*  Defines */

/*  Data Types */

/**************************** GLOBAL DATA *************************************/
/*  Definitions */

/*  Declarations  */

/***************************** FILE SCOPE DATA ********************************/

/*************************** FUNCTIONS ****************************************/
void _INIT plant_mainINIT( void )
{
  /* initialize model */
  SimDACyl4_initialize(1);
}

void _CYCLIC plant_mainCYCLIC( void )
{
  /* call model step function */
  SimDACyl4_step();
}

void _EXIT plant_mainEXIT( void )
{
  /* terminate model */
  SimDACyl4_terminate();
}

/*****************************************************************************
   B&R Automation Studio Target for Simulink Version: V2.1.139 (03-Feb-2009)
 *****************************************************************************/

/*======================== TOOL VERSION INFORMATION ==========================*
 * MATLAB 7.6 (R2008a)23-Jan-2008                                             *
 * Simulink 7.1 (R2008a)23-Jan-2008                                           *
 * Real-Time Workshop 7.1 (R2008a)23-Jan-2008                                 *
 * Real-Time Workshop Embedded Coder 5.1 (R2008a)23-Jan-2008                  *
 * Stateflow 7.1 (R2008a)23-Jan-2008                                          *
 * Stateflow Coder 7.1 (R2008a)23-Jan-2008                                    *
 * Simulink Fixed Point 5.6 (R2008a)23-Jan-2008                               *
 *============================================================================*/

/*======================= LICENSE IN USE INFORMATION =========================*
 * control_toolbox                                                            *
 * matlab                                                                     *
 * real-time_workshop                                                         *
 * rtw_embedded_coder                                                         *
 * simulink                                                                   *
 *============================================================================*/
