/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer Industrie-Elektronik Ges.m.b.H.
 ********************************************************************
 * Program: SimDACyl4
 * File: SimDACyl4_data.c
 * Author: zehetleitnek
 * Created: Wed Feb 11 16:26:58 2009
 ********************************************************************
 * Data for program SimDACyl4
 ********************************************************************
 * Generated with B&R Automation Studio Target for Simulink V2.1
 ********************************************************************/

#include "SimDACyl4.h"
#include "SimDACyl4_private.h"

/*  GLOBAL DATA DEFINITIONS */

/* Constant parameters (auto storage) */
const ConstParam_SimDACyl4 SimDACyl4_ConstP = {
  /* Expression: xnodes
   * '<S4>/Valve Characteristic1'
   */
  { -10.0, -4.0, 0.0, 4.0, 10.0 },

  /* Expression: ynodes
   * '<S4>/Valve Characteristic1'
   */
  { -1.0, -0.1, 0.0, 0.1, 1.0 }
};
