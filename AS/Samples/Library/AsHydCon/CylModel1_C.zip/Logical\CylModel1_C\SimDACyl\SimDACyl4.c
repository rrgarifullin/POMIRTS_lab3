/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer Industrie-Elektronik Ges.m.b.H.
 ********************************************************************
 * Program: SimDACyl4
 * File: SimDACyl4.c
 * Author: zehetleitnek
 * Created: Wed Feb 11 16:26:58 2009
 ********************************************************************
 * Implementation of program SimDACyl4
 ********************************************************************
 * Generated with B&R Automation Studio Target for Simulink V2.1
 ********************************************************************/

#include "SimDACyl4.h"
#include "SimDACyl4_private.h"

/*  Defines */

/*  Data Types */

/**************************** GLOBAL DATA *************************************/
/*  Definitions */

/* Block signals (auto storage) */
BlockIO_SimDACyl4 SimDACyl4_B;

/* Block states (auto storage) */
D_Work_SimDACyl4 SimDACyl4_DWork;

/* Previous zero-crossings (trigger) states */
PrevZCSigStates_SimDACyl4 SimDACyl4_PrevZCSigState;

/*  Declarations  */

/***************************** FILE SCOPE DATA ********************************/

/*************************** FUNCTIONS ****************************************/

/*********************************************************************
 * Lookup Binary Search Utility BINARYSEARCH_real_T
 */
void BINARYSEARCH_real_T( uint32_T *piLeft, uint32_T *piRght, real_T u, const
  real_T *pData, uint32_T iHi)
{
  /* Find the location of current input value in the data table. */
  *piLeft = 0;
  *piRght = iHi;
  if (u <= pData[0] ) {
    /* Less than or equal to the smallest point in the table. */
    *piRght = 0;
  } else if (u >= pData[iHi] ) {
    /* Greater than or equal to the largest point in the table. */
    *piLeft = iHi;
  } else {
    uint32_T i;

    /* Do a binary search. */
    while (( *piRght - *piLeft ) > 1 ) {
      /* Get the average of the left and right indices using to Floor rounding. */
      i = (*piLeft + *piRght) >> 1;

      /* Move either the right index or the left index so that */
      /*  LeftDataPoint <= CurrentValue < RightDataPoint */
      if (u < pData[i] ) {
        *piRght = i;
      } else {
        *piLeft = i;
      }
    }
  }
}

/* end macro BINARYSEARCH_real_T
 *********************************************************************/

/*********************************************************************
 * Lookup Utility LookUp_real_T_real_T
 */
void LookUp_real_T_real_T( real_T *pY, const real_T *pYData, real_T u, const
  real_T *pUData, uint32_T iHi)
{
  uint32_T iLeft;
  uint32_T iRght;
  BINARYSEARCH_real_T( &(iLeft), &(iRght), u, pUData, iHi);

  {
    real_T lambda;
    if (pUData[iRght] > pUData[iLeft] ) {
      real_T num;
      real_T den;
      den = pUData[iRght];
      den = den - pUData[iLeft];
      num = u;
      num = num - pUData[iLeft];
      lambda = num / den;
    } else {
      lambda = 0;
    }

    {
      real_T yLeftCast;
      real_T yRghtCast;
      yLeftCast = pYData[iLeft];
      yRghtCast = pYData[iRght];
      if (lambda != 0) {
        yLeftCast += lambda * ( yRghtCast - yLeftCast );
      }

      (*pY) = yLeftCast;
    }
  }
}

/* end function LookUp_real_T_real_T
 *********************************************************************/

/* Model step function */
void SimDACyl4_step(void)
{
  /* local block i/o variables */
  real_T rtb_Ta1;
  real_T rtb_Ta;
  real_T rtb_Ta2;
  real_T rtb_ValveCharacteristic1;
  real_T rtb_barPa;
  real_T rtb_barPa1;
  real_T rtb_y;
  real_T rtb_y_k;
  real_T rtb_y_n[2];
  real_T rtb_dx[5];
  real_T rtb_TmpHiddenBufferAtSFunctionI[4];
  real_T rtb_Fhyd;
  real_T rtb_barPa4;
  real_T rtb_mmm1_h;
  real_T rtb_ResolutionSSI;
  real32_T rtb_Fsum;
  boolean_T rtb_LogicalOperator;

  {
    ZCEventType zcEvent;
    SimDACyl4_B.gUV_DAC = UV_DAC;

    /* DataTypeConversion: '<Root>/Data Type Conversion' */
    rtb_barPa4 = (real_T)SimDACyl4_B.gUV_DAC;

    /* Gain: '<Root>/bar-Pa4' */
    rtb_barPa4 *= 3.0517578125000000E-004;

    /* DataTypeConversion: '<Root>/LREAL  -> REAL' */
    SimDACyl4_B.LREALREAL = (real32_T)rtb_barPa4;
    UValve = SimDACyl4_B.LREALREAL;
    SimDACyl4_B.pNegInit_bar = pNegInit_bar;

    /* DiscreteIntegrator: '<Root>/Integrator1' incorporates:
     *  Gain: '<Root>/bar-Pa3'
     */
    if (SimDACyl4_DWork.Integrator1_IC_LOADING) {
      SimDACyl4_DWork.Integrator1_DSTATE = 1.0E+005 * SimDACyl4_B.pNegInit_bar;
      SimDACyl4_DWork.Integrator1_IC_LOADING = 0U;
      rtb_ResolutionSSI = SimDACyl4_DWork.Integrator1_DSTATE;
    } else {
      rtb_ResolutionSSI = SimDACyl4_DWork.Integrator1_DSTATE;
    }

    if (rtb_ResolutionSSI >= 4.5E+007) {
      rtb_ResolutionSSI = 4.5E+007;
    } else {
      if (rtb_ResolutionSSI <= 1.0) {
        rtb_ResolutionSSI = 1.0;
      }
    }

    /* Gain: '<Root>/Ta1' incorporates:
     *  Gain: '<Root>/Tcycle1'
     */
    rtb_Ta1 = Tcycle * rtb_ResolutionSSI * 2500.0;

    /* DataTypeConversion: '<Root>/LREAL  -> REAL5' incorporates:
     *  Gain: '<Root>/Pa-bar1'
     */
    SimDACyl4_B.LREALREAL5 = (real32_T)(0.00001 * rtb_Ta1);
    pNegCyl = SimDACyl4_B.LREALREAL5;
    SimDACyl4_B.PressureMaxADC = PressureMaxADC;

    /* Embedded MATLAB: '<Root>/pB_ADC_Val' */

    /* Embedded MATLAB Function 'pB_ADC_Val': '<S6>:1' */
    /*  This block supports the Embedded MATLAB subset. */
    /*  See the help menu for details.  */
    /* '<S6>:1:5' */
    rtb_y = rtb_Ta1 * 0.00001 / SimDACyl4_B.PressureMaxADC * 32767.0;

    /* DataTypeConversion: '<Root>/ToINT1' */
    rtb_ResolutionSSI = rtb_y;
    if ((rtb_y < 4.5035996273704960E+015) && (rtb_y > -4.5035996273704960E+015))
    {
      rtb_ResolutionSSI = floor(rtb_y + 0.5);
    }

    rtb_ResolutionSSI = fmod((real_T)rtb_ResolutionSSI, 65536.0);
    if (rtb_ResolutionSSI < -32768.0) {
      rtb_ResolutionSSI += 65536.0;
    } else {
      if (rtb_ResolutionSSI >= 32768.0) {
        rtb_ResolutionSSI -= 65536.0;
      }
    }

    SimDACyl4_B.ToINT1 = (int16_T)rtb_ResolutionSSI;
    pNeg_ADC = SimDACyl4_B.ToINT1;
    SimDACyl4_B.pPosInit_bar = pPosInit_bar;

    /* DiscreteIntegrator: '<Root>/Integrator' incorporates:
     *  Gain: '<Root>/bar-Pa2'
     */
    if (SimDACyl4_DWork.Integrator_IC_LOADING) {
      SimDACyl4_DWork.Integrator_DSTATE = 1.0E+005 * SimDACyl4_B.pPosInit_bar;
      SimDACyl4_DWork.Integrator_IC_LOADING = 0U;
      rtb_ResolutionSSI = SimDACyl4_DWork.Integrator_DSTATE;
    } else {
      rtb_ResolutionSSI = SimDACyl4_DWork.Integrator_DSTATE;
    }

    if (rtb_ResolutionSSI >= 4.5E+007) {
      rtb_ResolutionSSI = 4.5E+007;
    } else {
      if (rtb_ResolutionSSI <= 1.0) {
        rtb_ResolutionSSI = 1.0;
      }
    }

    /* Gain: '<Root>/Ta' incorporates:
     *  Gain: '<Root>/Tcycle'
     */
    rtb_Ta = Tcycle * rtb_ResolutionSSI * 2500.0;

    /* DataTypeConversion: '<Root>/LREAL  -> REAL4' incorporates:
     *  Gain: '<Root>/Pa-bar'
     */
    SimDACyl4_B.LREALREAL4 = (real32_T)(0.00001 * rtb_Ta);
    pPosCyl = SimDACyl4_B.LREALREAL4;

    /* Embedded MATLAB: '<Root>/pA_ADC_Val' */

    /* Embedded MATLAB Function 'pA_ADC_Val': '<S5>:1' */
    /*  This block supports the Embedded MATLAB subset. */
    /*  See the help menu for details.  */
    /* '<S5>:1:5' */
    rtb_y_k = rtb_Ta * 0.00001 / SimDACyl4_B.PressureMaxADC * 32767.0;

    /* DataTypeConversion: '<Root>/ToINT2' */
    rtb_ResolutionSSI = rtb_y_k;
    if ((rtb_y_k < 4.5035996273704960E+015) && (rtb_y_k >
         -4.5035996273704960E+015)) {
      rtb_ResolutionSSI = floor(rtb_y_k + 0.5);
    }

    rtb_ResolutionSSI = fmod((real_T)rtb_ResolutionSSI, 65536.0);
    if (rtb_ResolutionSSI < -32768.0) {
      rtb_ResolutionSSI += 65536.0;
    } else {
      if (rtb_ResolutionSSI >= 32768.0) {
        rtb_ResolutionSSI -= 65536.0;
      }
    }

    SimDACyl4_B.ToINT2 = (int16_T)rtb_ResolutionSSI;
    pPos_ADC = SimDACyl4_B.ToINT2;
    SimDACyl4_B.sInit_mm = sInit_mm;

    /* DiscreteIntegrator: '<Root>/Integrator2' incorporates:
     *  Gain: '<Root>/mm-m1'
     */
    if (SimDACyl4_DWork.Integrator2_IC_LOADING) {
      SimDACyl4_DWork.Integrator2_DSTATE = 0.001 * SimDACyl4_B.sInit_mm;
      SimDACyl4_DWork.Integrator2_IC_LOADING = 0U;
      rtb_ResolutionSSI = SimDACyl4_DWork.Integrator2_DSTATE;
    } else {
      rtb_ResolutionSSI = SimDACyl4_DWork.Integrator2_DSTATE;
    }

    if (rtb_ResolutionSSI >= smax_mm * 0.001) {
      rtb_ResolutionSSI = smax_mm * 0.001;
      rtb_mmm1_h = 1.0;
    } else if (rtb_ResolutionSSI <= smin_mm * 0.001) {
      rtb_ResolutionSSI = smin_mm * 0.001;
      rtb_mmm1_h = -1.0;
    } else {
      rtb_mmm1_h = 0.0;
    }

    /* Gain: '<Root>/Ta2' incorporates:
     *  Gain: '<Root>/Tcycle2'
     */
    rtb_Ta2 = Tcycle * rtb_ResolutionSSI * 2500.0;

    /* DataTypeConversion: '<Root>/LREAL  -> REAL2' incorporates:
     *  Gain: '<Root>/m-mm'
     */
    SimDACyl4_B.LREALREAL2 = (real32_T)(1000.0 * rtb_Ta2);
    sCyl = SimDACyl4_B.LREALREAL2;

    /* DataTypeConversion: '<Root>/ToDINT' incorporates:
     *  Gain: '<Root>/ResolutionSSI'
     */
    rtb_ResolutionSSI = 1.0E+006 * rtb_Ta2;
    if ((rtb_ResolutionSSI < 4.5035996273704960E+015) && (rtb_ResolutionSSI >
         -4.5035996273704960E+015)) {
      rtb_ResolutionSSI = floor((real_T)rtb_ResolutionSSI + 0.5);
    }

    rtb_ResolutionSSI = fmod((real_T)rtb_ResolutionSSI, 4.294967296E+009);
    if (rtb_ResolutionSSI < 0.0) {
      rtb_ResolutionSSI += 4.294967296E+009;
    }

    SimDACyl4_B.ToDINT = (uint32_T)rtb_ResolutionSSI;
    sCyl_SSI = SimDACyl4_B.ToDINT;

    /* HitCross: '<Root>/Hit  Crossing' */
    zcEvent = rt_ZCFcn(ANY_ZERO_CROSSING,
                       &SimDACyl4_PrevZCSigState.HitCrossing_Input_ZCE,
                       (SimDACyl4_DWork.Integrator3_DSTATE));
    if (SimDACyl4_DWork.HitCrossing_MODE == 0) {
      if (zcEvent != NO_ZCEVENT) {
        SimDACyl4_B.HitCrossing = ((SimDACyl4_B.HitCrossing == 1 ? 0 : 1) != 0);
        SimDACyl4_DWork.HitCrossing_MODE = 1;
      } else if (SimDACyl4_B.HitCrossing == 1) {
        if (SimDACyl4_DWork.Integrator3_DSTATE != 0.0) {
          SimDACyl4_B.HitCrossing = 0U;
        }
      } else {
        if (SimDACyl4_DWork.Integrator3_DSTATE == 0.0) {
          SimDACyl4_B.HitCrossing = 1U;
        }
      }
    } else {
      if (SimDACyl4_DWork.Integrator3_DSTATE != 0.0) {
        SimDACyl4_B.HitCrossing = 0U;
      }

      SimDACyl4_DWork.HitCrossing_MODE = 0;
    }

    /* Logic: '<Root>/Logical Operator' */
    rtb_LogicalOperator = ((rtb_mmm1_h != 0.0) || SimDACyl4_B.HitCrossing);
    SimDACyl4_B.vInit_mms = vInit_mms;

    /* Gain: '<Root>/mm-m' */
    rtb_ResolutionSSI = 0.001 * SimDACyl4_B.vInit_mms;

    /* DiscreteIntegrator: '<Root>/Integrator3' */
    if (SimDACyl4_DWork.Integrator3_IC_LOADING) {
      SimDACyl4_DWork.Integrator3_DSTATE = rtb_ResolutionSSI;
      SimDACyl4_DWork.Integrator3_IC_LOADING = 0U;
      rtb_mmm1_h = SimDACyl4_DWork.Integrator3_DSTATE;
    } else if (rtb_LogicalOperator &&
               (SimDACyl4_DWork.Integrator3_PrevResetState <= 0)) {
      SimDACyl4_DWork.Integrator3_DSTATE = rtb_ResolutionSSI;
      rtb_mmm1_h = SimDACyl4_DWork.Integrator3_DSTATE;
    } else {
      rtb_mmm1_h = SimDACyl4_DWork.Integrator3_DSTATE;
    }

    if (rtb_LogicalOperator) {
      SimDACyl4_DWork.Integrator3_PrevResetState = 1;
    } else {
      SimDACyl4_DWork.Integrator3_PrevResetState = 0;
    }

    /* Gain: '<Root>/Ta3' incorporates:
     *  Gain: '<Root>/Tcycle3'
     */
    rtb_ResolutionSSI = Tcycle * rtb_mmm1_h * 2500.0;

    /* DataTypeConversion: '<Root>/LREAL  -> REAL3' incorporates:
     *  Gain: '<Root>/m-mm1'
     */
    SimDACyl4_B.LREALREAL3 = (real32_T)(1000.0 * rtb_ResolutionSSI);
    vCyl = SimDACyl4_B.LREALREAL3;

    /* Lookup Block: '<S4>/Valve Characteristic1'
     * About '<S4>/Valve Characteristic1 :'
     * Lookup Block: '<S4>/Valve Characteristic1'
     * Input0  Data Type:  Floating Point real_T
     * Output0 Data Type:  Floating Point real_T
     * Lookup Method: Linear_Endpoint
     *
     * XData parameter uses the same data type and scaling as Input0
     * YData parameter uses the same data type and scaling as Output0


     */
    LookUp_real_T_real_T( &(rtb_ValveCharacteristic1),
                         SimDACyl4_ConstP.ValveCharacteristic_m, rtb_barPa4,
                         SimDACyl4_ConstP.ValveCharacteristic1_, 4U);

    /* DataTypeConversion: '<Root>/LREAL  -> REAL1' */
    SimDACyl4_B.LREALREAL1 = (real32_T)rtb_ValveCharacteristic1;
    yValve = SimDACyl4_B.LREALREAL1;
    SimDACyl4_B.Fextern = Fextern;

    /* Gain: '<Root>/bar-Pa' incorporates:
     *  Constant: '<Root>/Constant1'
     */
    rtb_barPa = 1.0E+005 * psys_bar;

    /* Gain: '<Root>/bar-Pa1' incorporates:
     *  Constant: '<Root>/Constant2'
     */
    rtb_barPa1 = 1.0E+005 * ptank_bar;

    /* Embedded MATLAB: '<S3>/4-3 proportinal valve' */
    {
      real_T eml_dpnom;
      real_T eml_Kv1;
      real_T eml_Kv2;
      real_T eml_ClValve;
      real_T eml_dps1;
      real_T eml_dp2t;
      real_T eml_dp1t;
      real_T eml_dps2;

      /* Embedded MATLAB Function 'Valve/4-3 proportinal valve': '<S8>:1' */
      /*  proportional 4/3 valve with input xv and output q1 and q2 */
      /*  20/11/07: zehetleitnek */
      /* '<S8>:1:5' */
      /* '<S8>:1:6' */
      /* '<S8>:1:7' */
      eml_dpnom = dpnom_bar * 1.0E+005;

      /* '<S8>:1:9' */
      eml_Kv1 = Qnompos_lmin / 60000.0 / sqrt(eml_dpnom);

      /* '<S8>:1:10' */
      eml_Kv2 = Qnomneg_lmin / 60000.0 / sqrt(eml_dpnom);

      /* '<S8>:1:11' */
      /* polynomial approximation for dpValve = [-valv_eps .. valveps] */
      /* coeff. of polynomial approx. (valv_eps..[Pa]) */
      /* '<S8>:1:14' */
      eml_ClValve = cVleak_lminbar * 0.001 / 6.0E+006;

      /* cylpar(9);    %1e-13; */
      /* Ck20  = Ck20_lminbar*1e-3/(60*1e5);           %cylpar(10);    %1e-13; */
      /* '<S8>:1:16' */
      eml_dps1 = rtb_barPa - rtb_Ta;

      /* '<S8>:1:17' */
      eml_dp2t = rtb_Ta1 - rtb_barPa1;

      /* '<S8>:1:18' */
      eml_dp1t = rtb_Ta - rtb_barPa1;

      /* '<S8>:1:19' */
      eml_dps2 = rtb_barPa - rtb_Ta1;
      if (rtb_ValveCharacteristic1 > 0.0) {
        /* '<S8>:1:20' */
        if (fabs(eml_dps1) > 1.0E+006) {
          /* '<S8>:1:21' */
          /* '<S8>:1:22' */
          eml_dpnom = eml_dps1;
          if (eml_dps1 > 0.0) {
            eml_dpnom = 1.0;
          } else {
            if (eml_dps1 < 0.0) {
              eml_dpnom = -1.0;
            }
          }

          eml_Kv1 = rtb_ValveCharacteristic1 * eml_Kv1 * sqrt(fabs(eml_dps1)) *
            eml_dpnom;
        } else {
          /* '<S8>:1:24' */
          eml_dpnom = eml_dps1;
          if (eml_dps1 > 0.0) {
            eml_dpnom = 1.0;
          } else {
            if (eml_dps1 < 0.0) {
              eml_dpnom = -1.0;
            }
          }

          eml_Kv1 = rtb_ValveCharacteristic1 * eml_Kv1 * (-5.0E-010 * pow
            (eml_dps1, 2.0) + 0.0015 * fabs(eml_dps1)) * eml_dpnom;

          /* Approx. with polynomial */
        }

        if (fabs(eml_dp2t) > 1.0E+006) {
          /* '<S8>:1:26' */
          /* '<S8>:1:27' */
          eml_dpnom = eml_dp2t;
          if (eml_dp2t > 0.0) {
            eml_dpnom = 1.0;
          } else {
            if (eml_dp2t < 0.0) {
              eml_dpnom = -1.0;
            }
          }

          eml_dpnom *= (-rtb_ValveCharacteristic1) * eml_Kv2 * sqrt(fabs
            (eml_dp2t));
        } else {
          /* '<S8>:1:29' */
          eml_dpnom = eml_dp2t;
          if (eml_dp2t > 0.0) {
            eml_dpnom = 1.0;
          } else {
            if (eml_dp2t < 0.0) {
              eml_dpnom = -1.0;
            }
          }

          eml_dpnom *= (-rtb_ValveCharacteristic1) * eml_Kv2 * (-5.0E-010 * pow
            (eml_dp2t, 2.0) + 0.0015 * fabs(eml_dp2t));

          /* Approx. with polynomial */
        }
      } else {
        if (fabs(eml_dp1t) > 1.0E+006) {
          /* '<S8>:1:32' */
          /* '<S8>:1:33' */
          eml_dpnom = eml_dp1t;
          if (eml_dp1t > 0.0) {
            eml_dpnom = 1.0;
          } else {
            if (eml_dp1t < 0.0) {
              eml_dpnom = -1.0;
            }
          }

          eml_Kv1 = rtb_ValveCharacteristic1 * eml_Kv1 * sqrt(fabs(eml_dp1t)) *
            eml_dpnom;
        } else {
          /* '<S8>:1:35' */
          eml_dpnom = eml_dp1t;
          if (eml_dp1t > 0.0) {
            eml_dpnom = 1.0;
          } else {
            if (eml_dp1t < 0.0) {
              eml_dpnom = -1.0;
            }
          }

          eml_Kv1 = rtb_ValveCharacteristic1 * eml_Kv1 * (-5.0E-010 * pow
            (eml_dp1t, 2.0) + 0.0015 * fabs(eml_dp1t)) * eml_dpnom;

          /* Approx. with polynomial */
        }

        if (fabs(eml_dps2) > 1.0E+006) {
          /* '<S8>:1:37' */
          /* '<S8>:1:38' */
          eml_dpnom = eml_dps2;
          if (eml_dps2 > 0.0) {
            eml_dpnom = 1.0;
          } else {
            if (eml_dps2 < 0.0) {
              eml_dpnom = -1.0;
            }
          }

          eml_dpnom *= (-rtb_ValveCharacteristic1) * eml_Kv2 * sqrt(fabs
            (eml_dps2));
        } else {
          /* '<S8>:1:40' */
          eml_dpnom = eml_dps2;
          if (eml_dps2 > 0.0) {
            eml_dpnom = 1.0;
          } else {
            if (eml_dps2 < 0.0) {
              eml_dpnom = -1.0;
            }
          }

          eml_dpnom *= (-rtb_ValveCharacteristic1) * eml_Kv2 * (-5.0E-010 * pow
            (eml_dps2, 2.0) + 0.0015 * fabs(eml_dps2));

          /* Approx. with polynomial */
        }
      }

      /* '<S8>:1:43' */
      eml_Kv1 = (eml_Kv1 + eml_ClValve * eml_dps1) - eml_ClValve * eml_dp1t;

      /* '<S8>:1:44' */
      eml_dpnom = (eml_dpnom + eml_ClValve * eml_dps2) - eml_ClValve * eml_dp2t;

      /* '<S8>:1:46' */
      rtb_y_n[0] = eml_Kv1;
      rtb_y_n[1] = eml_dpnom;
    }

    /* SignalConversion: '<S7>/TmpHiddenBufferAt SFunction Inport1' */
    rtb_TmpHiddenBufferAtSFunctionI[0] = rtb_Ta;
    rtb_TmpHiddenBufferAtSFunctionI[1] = rtb_Ta1;
    rtb_TmpHiddenBufferAtSFunctionI[2] = rtb_Ta2;
    rtb_TmpHiddenBufferAtSFunctionI[3] = rtb_ResolutionSSI;

    /* Embedded MATLAB: '<S2>/double acting cylinder' */
    {
      real_T eml_p1;
      real_T eml_p2;
      real_T eml_sk;
      real_T eml_vk;
      real_T eml_Eoil;
      real_T eml_Aeff1;
      real_T eml_Aeff2;
      real_T eml_smin;
      real_T eml_smax;
      real_T eml_Ck12;
      int32_T eml_i0;
      real_T eml_b;

      /* Embedded MATLAB Function 'Hydraulic piston/double acting cylinder': '<S7>:1' */
      /*  This block supports the Embedded MATLAB subset. */
      /*  See the help menu for details.  */
      /* '<S7>:1:5' */
      /* '<S7>:1:6' */
      /* '<S7>:1:7' */
      eml_p1 = rtb_TmpHiddenBufferAtSFunctionI[0];

      /* '<S7>:1:8' */
      eml_p2 = rtb_TmpHiddenBufferAtSFunctionI[1];

      /* '<S7>:1:9' */
      eml_sk = rtb_TmpHiddenBufferAtSFunctionI[2];

      /* '<S7>:1:10' */
      eml_vk = rtb_TmpHiddenBufferAtSFunctionI[3];

      /* '<S7>:1:12' */
      eml_Eoil = Eoil_bar * 1.0E+005;

      /* hsyspar(1); */
      /* g    = hsyspar(2); */
      /* '<S7>:1:14' */
      eml_Aeff1 = Aeffpos_cm2 / 10000.0;

      /* cylpar(1); */
      /* '<S7>:1:15' */
      eml_Aeff2 = Aeffneg_cm2 / 10000.0;

      /* cylpar(2); */
      /* mk    = cylpar(3); */
      /* '<S7>:1:17' */
      /* cylpar(4); */
      /* '<S7>:1:18' */
      /* cylpar(5); */
      /* '<S7>:1:19' */
      eml_smin = smin_mm / 1000.0;

      /* cylpar(6); */
      /* '<S7>:1:20' */
      eml_smax = smax_mm / 1000.0;

      /* cylpar(7); */
      /* '<S7>:1:21' */
      eml_Ck12 = cK12leak_lminbar * 0.001 / 6.0E+006;

      /* cylpar(11);   %1e-12; */
      /* skstat = x0cyl1(3); */
      /* x0cyl1 = [p10_bar*1e5, p20_bar*1e5, sk0_mm/1000, 0]; */
      /* '<S7>:1:25' */
      /* '<S7>:1:26' */
      rtb_Fsum = ((real32_T)((eml_Aeff1 * eml_p1 - eml_Aeff2 * eml_p2) +
        mpiston_kg * gravconst) - SimDACyl4_B.Fextern) - (real32_T)(dDamp_Nsm *
        eml_vk);

      /* '<S7>:1:27' */
      rtb_Fhyd = eml_Aeff1 * eml_p1 - eml_Aeff2 * eml_p2;

      /* '<S7>:1:28' */
      for (eml_i0 = 0; eml_i0 < 5; eml_i0++) {
        rtb_dx[eml_i0] = 0.0;
      }

      if (eml_sk >= eml_smax - 0.002) {
        /* '<S7>:1:29' */
        /* '<S7>:1:30' */
        rtb_Fsum = rtb_Fsum - (real32_T)(2.0E+007 * (eml_sk - (eml_smax - 0.002)));

        /* '<S7>:1:31' */
        rtb_dx[4] = 1.0;
      } else {
        if (eml_sk <= eml_smin + 0.002) {
          /* '<S7>:1:32' */
          /* '<S7>:1:33' */
          rtb_Fsum = rtb_Fsum - (real32_T)(2.0E+007 * (eml_sk - (eml_smin +
            0.002)));

          /* '<S7>:1:34' */
          rtb_dx[4] = 2.0;
        }
      }

      if (((real_T)SimDACyl4_B.HitCrossing > 0.5) && ((real_T)(real32_T)fabs
           (rtb_Fsum) < FrStick)) {
        /* '<S7>:1:36' */
        /* '<S7>:1:37' */
        rtb_dx[2] = 0.0;

        /* '<S7>:1:38' */
        rtb_dx[3] = 0.0;

        /* '<S7>:1:39' */
        rtb_dx[4] = 3.0;
      } else {
        /* '<S7>:1:41' */
        eml_b = eml_vk;
        if (eml_vk > 0.0) {
          eml_b = 1.0;
        } else {
          if (eml_vk < 0.0) {
            eml_b = -1.0;
          }
        }

        rtb_Fsum = rtb_Fsum - (real32_T)(FrSlide * eml_b);

        /* '<S7>:1:42' */
        rtb_dx[2] = eml_vk;

        /* '<S7>:1:43' */
        rtb_dx[3] = (real_T)(rtb_Fsum / (real32_T)mpiston_kg);

        /* '<S7>:1:44' */
        rtb_dx[4] = 0.0;
      }

      /* '<S7>:1:46' */
      rtb_dx[0] = eml_Eoil * ((rtb_y_n[0] - eml_Aeff1 * eml_vk) - eml_Ck12 *
        (eml_p1 - eml_p2)) / (V0pos_cm3 / 1.0E+006 + eml_Aeff1 * (eml_sk -
        eml_smin));

      /* '<S7>:1:47' */
      rtb_dx[1] = eml_Eoil * ((rtb_y_n[1] + eml_Aeff2 * eml_vk) - eml_Ck12 *
        (eml_p2 - eml_p1)) / (V0neg_cm3 / 1.0E+006 + eml_Aeff2 * (eml_smax -
        eml_sk));
    }

    /* Update for DiscreteIntegrator: '<Root>/Integrator1' */
    SimDACyl4_DWork.Integrator1_DSTATE = 0.0004 * rtb_dx[1] +
      SimDACyl4_DWork.Integrator1_DSTATE;
    if (SimDACyl4_DWork.Integrator1_DSTATE >= 4.5E+007) {
      SimDACyl4_DWork.Integrator1_DSTATE = 4.5E+007;
    } else {
      if (SimDACyl4_DWork.Integrator1_DSTATE <= 1.0) {
        SimDACyl4_DWork.Integrator1_DSTATE = 1.0;
      }
    }

    /* Update for DiscreteIntegrator: '<Root>/Integrator' */
    SimDACyl4_DWork.Integrator_DSTATE = 0.0004 * rtb_dx[0] +
      SimDACyl4_DWork.Integrator_DSTATE;
    if (SimDACyl4_DWork.Integrator_DSTATE >= 4.5E+007) {
      SimDACyl4_DWork.Integrator_DSTATE = 4.5E+007;
    } else {
      if (SimDACyl4_DWork.Integrator_DSTATE <= 1.0) {
        SimDACyl4_DWork.Integrator_DSTATE = 1.0;
      }
    }

    /* Update for DiscreteIntegrator: '<Root>/Integrator2' */
    SimDACyl4_DWork.Integrator2_DSTATE = 0.0004 * rtb_dx[2] +
      SimDACyl4_DWork.Integrator2_DSTATE;
    if (SimDACyl4_DWork.Integrator2_DSTATE >= smax_mm * 0.001) {
      SimDACyl4_DWork.Integrator2_DSTATE = smax_mm * 0.001;
    } else {
      if (SimDACyl4_DWork.Integrator2_DSTATE <= smin_mm * 0.001) {
        SimDACyl4_DWork.Integrator2_DSTATE = smin_mm * 0.001;
      }
    }

    /* Update for DiscreteIntegrator: '<Root>/Integrator3' */
    SimDACyl4_DWork.Integrator3_DSTATE = 0.0004 * rtb_dx[3] +
      SimDACyl4_DWork.Integrator3_DSTATE;
  }
}

/* Model initialize function */
void SimDACyl4_initialize(boolean_T firstTime)
{
  (void)firstTime;
  SimDACyl4_PrevZCSigState.HitCrossing_Input_ZCE = UNINITIALIZED_ZCSIG;

  /* InitializeConditions for DiscreteIntegrator: '<Root>/Integrator1' */
  SimDACyl4_DWork.Integrator1_IC_LOADING = 1U;

  /* InitializeConditions for DiscreteIntegrator: '<Root>/Integrator' */
  SimDACyl4_DWork.Integrator_IC_LOADING = 1U;

  /* InitializeConditions for DiscreteIntegrator: '<Root>/Integrator2' */
  SimDACyl4_DWork.Integrator2_IC_LOADING = 1U;

  /* InitializeConditions for DiscreteIntegrator: '<Root>/Integrator3' */
  SimDACyl4_DWork.Integrator3_IC_LOADING = 1U;
  SimDACyl4_DWork.Integrator3_DSTATE = 0.0;
  SimDACyl4_DWork.Integrator3_PrevResetState = 2;
}

/* Model terminate function */
void SimDACyl4_terminate(void)
{
  /* (no terminate code required) */
}

/*======================== TOOL VERSION INFORMATION ==========================*
 * MATLAB 7.6 (R2008a)23-Jan-2008                                             *
 * Simulink 7.1 (R2008a)23-Jan-2008                                           *
 * Real-Time Workshop 7.1 (R2008a)23-Jan-2008                                 *
 * Real-Time Workshop Embedded Coder 5.1 (R2008a)23-Jan-2008                  *
 * Stateflow 7.1 (R2008a)23-Jan-2008                                          *
 * Stateflow Coder 7.1 (R2008a)23-Jan-2008                                    *
 * Simulink Fixed Point 5.6 (R2008a)23-Jan-2008                               *
 *============================================================================*/

/*======================= LICENSE IN USE INFORMATION =========================*
 * control_toolbox                                                            *
 * matlab                                                                     *
 * real-time_workshop                                                         *
 * rtw_embedded_coder                                                         *
 * simulink                                                                   *
 *============================================================================*/
