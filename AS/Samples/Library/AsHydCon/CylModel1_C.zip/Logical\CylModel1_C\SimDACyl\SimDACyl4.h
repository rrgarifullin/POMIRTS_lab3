/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer Industrie-Elektronik Ges.m.b.H.
 ********************************************************************
 * Program: SimDACyl4
 * File: SimDACyl4.h
 * Author: zehetleitnek
 * Created: Wed Feb 11 16:26:58 2009
 ********************************************************************
 * Header for program SimDACyl4
 ********************************************************************
 * Generated with B&R Automation Studio Target for Simulink V2.1
 ********************************************************************/

#ifndef RTW_HEADER_SimDACyl4_h_
#define RTW_HEADER_SimDACyl4_h_
#ifndef SimDACyl4_COMMON_INCLUDES_
# define SimDACyl4_COMMON_INCLUDES_
#include <stdlib.h>
#include <stddef.h>
#include <math.h>
#include "rtwtypes.h"
#include "rtlibsrc.h"
#include "rt_zcfcn.h"
#endif                                 /* SimDACyl4_COMMON_INCLUDES_ */

#include "SimDACyl4_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((void*) 0)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((void) 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((void*) 0)
#endif

#ifndef MIN
#define MIN(a,b)                       ((a) < (b) ? (a) : (b))
#endif

#ifndef MAX
#define MAX(a,b)                       ((a) > (b) ? (a) : (b))
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T pNegInit_bar;                 /* '<Root>/pNegInit_bar' */
  real_T PressureMaxADC;               /* '<Root>/PressureMaxADC' */
  real_T pPosInit_bar;                 /* '<Root>/pPosInit_bar' */
  real_T sInit_mm;                     /* '<Root>/sInit_mm' */
  real_T vInit_mms;                    /* '<Root>/vInit_mms' */
  real32_T LREALREAL;                  /* '<Root>/LREAL  -> REAL' */
  real32_T LREALREAL5;                 /* '<Root>/LREAL  -> REAL5' */
  real32_T LREALREAL4;                 /* '<Root>/LREAL  -> REAL4' */
  real32_T LREALREAL2;                 /* '<Root>/LREAL  -> REAL2' */
  real32_T LREALREAL3;                 /* '<Root>/LREAL  -> REAL3' */
  real32_T LREALREAL1;                 /* '<Root>/LREAL  -> REAL1' */
  real32_T Fextern;                    /* '<Root>/Fextern' */
  uint32_T ToDINT;                     /* '<Root>/ToDINT' */
  int16_T gUV_DAC;                     /* '<Root>/gUV_DAC' */
  int16_T ToINT1;                      /* '<Root>/ToINT1' */
  int16_T ToINT2;                      /* '<Root>/ToINT2' */
  boolean_T HitCrossing;               /* '<Root>/Hit  Crossing' */
} BlockIO_SimDACyl4;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T Integrator1_DSTATE;           /* '<Root>/Integrator1' */
  real_T Integrator_DSTATE;            /* '<Root>/Integrator' */
  real_T Integrator2_DSTATE;           /* '<Root>/Integrator2' */
  real_T Integrator3_DSTATE;           /* '<Root>/Integrator3' */
  int_T HitCrossing_MODE;              /* '<Root>/Hit  Crossing' */
  int8_T Integrator3_PrevResetState;   /* '<Root>/Integrator3' */
  uint8_T Integrator1_IC_LOADING;      /* '<Root>/Integrator1' */
  uint8_T Integrator_IC_LOADING;       /* '<Root>/Integrator' */
  uint8_T Integrator2_IC_LOADING;      /* '<Root>/Integrator2' */
  uint8_T Integrator3_IC_LOADING;      /* '<Root>/Integrator3' */
} D_Work_SimDACyl4;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState HitCrossing_Input_ZCE;    /* '<Root>/Hit  Crossing' */
} PrevZCSigStates_SimDACyl4;

/* Constant parameters (auto storage) */
typedef struct {
  /* Expression: xnodes
   * '<S4>/Valve Characteristic1'
   */
  real_T ValveCharacteristic1_[5];

  /* Expression: ynodes
   * '<S4>/Valve Characteristic1'
   */
  real_T ValveCharacteristic_m[5];
} ConstParam_SimDACyl4;

/* Block signals (auto storage) */
extern BlockIO_SimDACyl4 SimDACyl4_B;

/* Block states (auto storage) */
extern D_Work_SimDACyl4 SimDACyl4_DWork;

/* Constant parameters (auto storage) */
extern const ConstParam_SimDACyl4 SimDACyl4_ConstP;

/* Model entry point functions */
extern void SimDACyl4_initialize(boolean_T firstTime);
extern void SimDACyl4_step(void);
extern void SimDACyl4_terminate(void);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : SimDACyl4
 * '<S1>'   : SimDACyl4/Environment Controller
 * '<S2>'   : SimDACyl4/Hydraulic piston
 * '<S3>'   : SimDACyl4/Valve
 * '<S4>'   : SimDACyl4/Valve-Characteristic
 * '<S5>'   : SimDACyl4/pA_ADC_Val
 * '<S6>'   : SimDACyl4/pB_ADC_Val
 * '<S7>'   : SimDACyl4/Hydraulic piston/double acting cylinder
 * '<S8>'   : SimDACyl4/Valve/4-3 proportinal valve
 */
#endif                                 /* RTW_HEADER_SimDACyl4_h_ */
