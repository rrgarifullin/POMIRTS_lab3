/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer Industrie-Elektronik Ges.m.b.H.
 ********************************************************************
 * Program: SimDACyl4
 * File: SimDACyl4_private.h
 * Author: zehetleitnek
 * Created: Wed Feb 11 16:26:58 2009
 ********************************************************************
 * Header for program SimDACyl4
 ********************************************************************
 * Generated with B&R Automation Studio Target for Simulink V2.1
 ********************************************************************/

#ifndef RTW_HEADER_SimDACyl4_private_h_
#define RTW_HEADER_SimDACyl4_private_h_
#include "rtwtypes.h"
#define _ASMATH_
#define ASSTRING_H_
#include <bur/plctypes.h>
#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "rtlibsrc.h"
#define CALL_EVENT                     (MAX_uint8_T)
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else

/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S16I32L32N32F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                 /* RTWTYPES_ID_C08S16I32L32N32F1 */
#endif                                 /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                 /* __RTWTYPES_H__ */

#ifndef MIN
#define MIN(a,b)                       ((a) < (b) ? (a) : (b))
#endif

#ifndef MAX
#define MAX(a,b)                       ((a) > (b) ? (a) : (b))
#endif

/* Imported (extern) block parameters */
extern real_T Aeffneg_cm2;             /* Variable: Aeffneg_cm2
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T Aeffpos_cm2;             /* Variable: Aeffpos_cm2
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T Eoil_bar;                /* Variable: Eoil_bar
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T FrSlide;                 /* Variable: FrSlide
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T FrStick;                 /* Variable: FrStick
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T Qnomneg_lmin;            /* Variable: Qnomneg_lmin
                                        * '<S3>/4-3 proportinal valve'
                                        */
extern real_T Qnompos_lmin;            /* Variable: Qnompos_lmin
                                        * '<S3>/4-3 proportinal valve'
                                        */
extern real_T Tcycle;                  /* Variable: Tcycle
                                        * Referenced by blocks:
                                        * '<Root>/Tcycle'
                                        * '<Root>/Tcycle1'
                                        * '<Root>/Tcycle2'
                                        * '<Root>/Tcycle3'
                                        */
extern real_T V0neg_cm3;               /* Variable: V0neg_cm3
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T V0pos_cm3;               /* Variable: V0pos_cm3
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T cK12leak_lminbar;        /* Variable: cK12leak_lminbar
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T cVleak_lminbar;          /* Variable: cVleak_lminbar
                                        * '<S3>/4-3 proportinal valve'
                                        */
extern real_T dDamp_Nsm;               /* Variable: dDamp_Nsm
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T dpnom_bar;               /* Variable: dpnom_bar
                                        * '<S3>/4-3 proportinal valve'
                                        */
extern real_T gravconst;               /* Variable: gravconst
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T mpiston_kg;              /* Variable: mpiston_kg
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T psys_bar;                /* Variable: psys_bar
                                        * '<Root>/Constant1'
                                        */
extern real_T ptank_bar;               /* Variable: ptank_bar
                                        * '<Root>/Constant2'
                                        */
extern real_T smax_mm;                 /* Expression: smax_mm*1e-3
                                        * Referenced by blocks:
                                        * '<Root>/Integrator2'
                                        * '<S2>/double acting cylinder'
                                        */
extern real_T smin_mm;                 /* Expression: smin_mm*1e-3
                                        * Referenced by blocks:
                                        * '<Root>/Integrator2'
                                        * '<S2>/double acting cylinder'
                                        */
void BINARYSEARCH_real_T( uint32_T *piLeft, uint32_T *piRght, real_T u, const
  real_T *pData, uint32_T iHi);
void LookUp_real_T_real_T( real_T *pY, const real_T *pYData, real_T u, const
  real_T *pUData, uint32_T iHi);

#endif                                 /* RTW_HEADER_SimDACyl4_private_h_ */
