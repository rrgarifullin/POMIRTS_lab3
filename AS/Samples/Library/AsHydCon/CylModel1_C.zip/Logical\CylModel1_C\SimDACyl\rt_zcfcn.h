/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer Industrie-Elektronik Ges.m.b.H.
 ********************************************************************
 * Program: SimDACyl4
 * File: rt_zcfcn.h
 * Author: zehetleitnek
 * Created: Wed Feb 11 16:26:58 2009
 ********************************************************************
 * Header for program SimDACyl4
 ********************************************************************
 * Generated with B&R Automation Studio Target for Simulink V2.1
 ********************************************************************/

#ifndef RTW_HEADER_rt_zcfcn_h_
#define RTW_HEADER_rt_zcfcn_h_
#include "rtwtypes.h"
#include "solver_zc.h"
# define rt_SET_RZC_SIGSTATE(sig)      ( ((sig) < 0.0) ? NEG_ZCSIG : ((sig) > 0.0 ? POS_ZCSIG : ZERO_ZCSIG) )
#define rt_SET_IZC_SIGSTATE(sig)       ( ((sig) < 0) ? NEG_ZCSIG : ((sig) > 0 ? POS_ZCSIG : ZERO_ZCSIG) )
#define rt_SET_UZC_SIGSTATE(sig)       (((sig) > 0)? POS_ZCSIG : ZERO_ZCSIG)
#define rt_SET_BZC_SIGSTATE(sig)       ((sig)? POS_ZCSIG : ZERO_ZCSIG)
#ifndef slZcHadEvent
#define slZcHadEvent(ev, zcsDir)       ( (ev & zcsDir) != 0x00 )
#endif

#ifndef slZcUnAliasEvents
#define slZcUnAliasEvents(evL, evR)    ( ( ( slZcHadEvent(evL,SL_ZCS_EVENT_N2Z) && slZcHadEvent(evR,SL_ZCS_EVENT_Z2P) ) || ( slZcHadEvent(evL,SL_ZCS_EVENT_P2Z) && slZcHadEvent(evR,SL_ZCS_EVENT_Z2N) ) ) ? SL_ZCS_EVENT_NUL : evR )
#endif

#ifndef MIN
#define MIN(a,b)                       ((a) < (b) ? (a) : (b))
#endif

#ifndef MAX
#define MAX(a,b)                       ((a) > (b) ? (a) : (b))
#endif

extern ZCEventType rt_ZCFcn(ZCDirection direction,
  ZCSigState *prevzc,
  real_T zcSig);

#endif                                 /* RTW_HEADER_rt_zcfcn_h_ */
