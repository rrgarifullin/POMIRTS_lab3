/********************************************************************
* COPYRIGHT -- Bernecker + Rainer
	********************************************************************
	* Program: Guarding
	* File: Guarding.st
	* Author: Bernecker + Rainer
	* Created: March 24, 2014
 ********************************************************************
* Implementation of program Guarding
	********************************************************************/

#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

void _INIT GuardingInit(void)
{
	Guarding.cfgUpdateSeconds = 1;
}

void _CYCLIC GuardingCyclic(void)
{
	/*
	Description of Guarding.Step:

	0........Wait State
	
	1........Read available B&R Technology Guards

	10.......Register license
	11.......Check license
	12.......Deregister license
	
	20.......Reads operating time
	
	30.......Reads customer operating time counter
	31.......Starts customer operating time counter
	32.......Stops customer operating time counter

	40.......Read user data
	41.......Write user data

	50.......Read B&R dongle context data
	51.......Write license data to B&R dongle
	
	
	100......Here some error Handling has to be implemented */


	switch (Guarding.Step)
	{
		case 0:	/* Wait State */			
			break;		
		
		case 1:	/* Read available B&R Technology Guards */
			Guarding.guardGetDongles_0.enable         = 1;
			Guarding.guardGetDongles_0.pDongleInfos   = &Guarding.dongleInfos[0];
			Guarding.guardGetDongles_0.dongleInfoSize = sizeof(Guarding.dongleInfos);
			guardGetDongles(&Guarding.guardGetDongles_0);		/* Call the function block */
		
			if (Guarding.guardGetDongles_0.status == ERR_OK) /* guardGetDongles successful */
			{
				Guarding.Step        = 0;
				Guarding.dongleCnt   = Guarding.guardGetDongles_0.neededSize;
				if (Guarding.dongleCnt > 0) 
				{
					Guarding.boxMask = Guarding.dongleInfos[0].boxMask;
					Guarding.serNo   = Guarding.dongleInfos[0].serNo;
				}
			}
			else if (Guarding.guardGetDongles_0.status == ERR_FUB_BUSY)
			{
				/* busy */
			}
			else
			{
				Guarding.Step      = 100;		/* go to error step */
				Guarding.dongleCnt = 0;
				brsmemset((UDINT) Guarding.dongleInfos, 0, sizeof(Guarding.dongleInfos));
			}
			break;
		
		case 10:	/* Register license */
			Guarding.guardRegisterLicense_0.enable       = 1;
			Guarding.guardRegisterLicense_0.firmCode     = 10;			/* Wibu Firmcode for testing purpose */
			Guarding.guardRegisterLicense_0.productCode  = 1;
			brsstrcpy((UDINT) Guarding.guardRegisterLicense_0.orderNumber, (UDINT) "Testlicense");
			brsstrcpy((UDINT) Guarding.guardRegisterLicense_0.description, (UDINT) "WIBU Systems - Testlicense");
			Guarding.guardRegisterLicense_0.registerType = guardREGISTER_ALWAYS;
			Guarding.guardRegisterLicense_0.reaction     = guardLIC_REACT_LOGBOOK | guardLIC_REACT_BLINK_CPU_LED;
			guardRegisterLicense(&Guarding.guardRegisterLicense_0);			/* Call the function block */
		
			if (Guarding.guardRegisterLicense_0.status == ERR_OK)
			{
				Guarding.Step = 0;
			}				
			else if (Guarding.guardRegisterLicense_0.status == ERR_FUB_BUSY)
			{
				/* busy */
			}
			else
			{
				Guarding.Step = 100;
			}
			break;
		
		case 11:	/* Check license */
			Guarding.guardCheckLicense_0.enable = 1;
			Guarding.guardCheckLicense_0.ident  = Guarding.guardRegisterLicense_0.ident;
			guardCheckLicense(&Guarding.guardCheckLicense_0);				/* Call the function block */
			
			if (Guarding.guardCheckLicense_0.status == ERR_OK)
			{
				Guarding.Step = 0;
			}
			else
			{
				Guarding.Step = 100;
			}
			break;
				
		case 12:	/* Deregister license */
			Guarding.guardDeregisterLicense_0.enable = 1;
			Guarding.guardDeregisterLicense_0.ident  = Guarding.guardRegisterLicense_0.ident;
			guardDeregisterLicense(&Guarding.guardDeregisterLicense_0);			/* Call the function block */
		
			if (Guarding.guardDeregisterLicense_0.status == ERR_OK)
			{
				Guarding.Step = 0;
			}
			else if (Guarding.guardDeregisterLicense_0.status == ERR_FUB_BUSY)
			{
				/* busy */
			}
			else
			{
				Guarding.Step = 100;
			}
			break;
		
		case 20:	/* Reads operating time */
			Guarding.guardReadOperatingTime_0.enable      = 1;
			Guarding.guardReadOperatingTime_0.boxMask     = Guarding.boxMask;
			Guarding.guardReadOperatingTime_0.serNo       = Guarding.serNo;
			Guarding.guardReadOperatingTime_0.counterType = guardGENERAL_OP_TIME_COUNTER;
			guardReadOperatingTime(&Guarding.guardReadOperatingTime_0);		/* Call the function block */
		
			if (Guarding.guardReadOperatingTime_0.status == ERR_OK)
			{
				Guarding.Step = 0;
			
				/* convert to readable Format */
				DT_TO_DTStructure(Guarding.guardReadOperatingTime_0.operatingTime, (UDINT) &Guarding.operatingTime);
				Guarding.operatingTime.year  = Guarding.operatingTime.year  - 1970;		/* correction to date 01.01.1970 */
				Guarding.operatingTime.month = Guarding.operatingTime.month - 1;		/* correction to date 01.01.1970 */
				Guarding.operatingTime.day   = Guarding.operatingTime.day   - 1;		/* correction to date 01.01.1970 */
			}
			else if (Guarding.guardReadOperatingTime_0.status == ERR_FUB_BUSY)
			{
				/* busy */
			}
			else /* go to error step */
			{
				Guarding.Step = 100;
			}
			break;
		
		case 30:	/* Reads customer operating time */
			Guarding.guardReadOperatingTime_0.enable      = 1;
			Guarding.guardReadOperatingTime_0.boxMask     = Guarding.boxMask;
			Guarding.guardReadOperatingTime_0.serNo       = Guarding.serNo;
			Guarding.guardReadOperatingTime_0.counterType = guardCUSTOMER_OP_TIME_COUNTER;
			guardReadOperatingTime(&Guarding.guardReadOperatingTime_0);			/* Call the function block */
		
			if (Guarding.guardReadOperatingTime_0.status == ERR_OK)
			{
				Guarding.Step = 0;
				/* convert to readable Format */
				DT_TO_DTStructure(Guarding.guardReadOperatingTime_0.operatingTime, (UDINT) &Guarding.operatingTime);
				Guarding.operatingTime.year  = Guarding.operatingTime.year - 1970;		/* correction to date 01.01.1970 */
				Guarding.operatingTime.month = Guarding.operatingTime.month - 1;		/* correction to date 01.01.1970 */
				Guarding.operatingTime.day   = Guarding.operatingTime.day   - 1;		/* correction to date 01.01.1970 */
			}	
			else if (Guarding.guardReadOperatingTime_0.status == ERR_FUB_BUSY)
			{
				/* busy */
			}
			else /* go to error step */
			{
				Guarding.Step = 100;
			}
			break;
		
		case 31:	/* Starts customer operating time counter */
			Guarding.guardStartCustomCounter_0.enable           = 1;
			Guarding.guardStartCustomCounter_0.boxMask          = Guarding.boxMask;
			Guarding.guardStartCustomCounter_0.serNo            = Guarding.serNo;
			Guarding.guardStartCustomCounter_0.counterType      = guardCUSTOMER_OP_TIME_COUNTER;
			Guarding.guardStartCustomCounter_0.cfgUpdateSeconds = Guarding.cfgUpdateSeconds;
			guardStartCustomOpTimeCounter(&Guarding.guardStartCustomCounter_0);		/* Call the function block */
		
			if (Guarding.guardStartCustomCounter_0.status == ERR_OK)
			{
				Guarding.Step = 0;
			}
			else if ( Guarding.guardStartCustomCounter_0.status == ERR_FUB_BUSY)
			{
				/* busy */
			}
			else
			{
				Guarding.Step = 100;
			}
			break;
		
		case 32:	/* Stops customer operating time counter*/
			Guarding.guardStopCustomCounter_0.enable = 1;
			Guarding.guardStopCustomCounter_0.ident  = Guarding.guardStartCustomCounter_0.ident;
			guardStopCustomOpTimeCounter(&Guarding.guardStopCustomCounter_0);		/* Call the function block */
		
			if (Guarding.guardStopCustomCounter_0.status == ERR_OK)
			{
				Guarding.Step = 0;
			}
			else if (Guarding.guardStopCustomCounter_0.status == ERR_FUB_BUSY)
			{
				/* busy */
			}
			else
			{
				Guarding.Step = 100;
			}
			break;
		
		case 40:	/* Read user data */
			Guarding.guardReadData_0.enable      = 1;
			Guarding.guardReadData_0.boxMask     = Guarding.boxMask;
			Guarding.guardReadData_0.serNo       = Guarding.serNo;
			guardReadData(&Guarding.guardReadData_0);				/* Call the function block */
		
			if (Guarding.guardReadData_0.status == ERR_OK)
			{
				Guarding.Step = 0;
				brsstrcpy((UDINT) Guarding.userData, (UDINT) Guarding.guardReadData_0.userData);
			}
			else if ( Guarding.guardReadData_0.status == ERR_FUB_BUSY )
			{
				/* busy */
			}
			else
			{
				Guarding.Step = 100;
			}
			break;
		
		case 41:	/*Write user data */
			Guarding.guardWriteData_0.enable      = 1;
			Guarding.guardWriteData_0.boxMask     = Guarding.boxMask;
			Guarding.guardWriteData_0.serNo       = Guarding.serNo;
			brsstrcpy((UDINT) Guarding.guardWriteData_0.userData, (UDINT) Guarding.userData);
			Guarding.guardWriteData_0.userDataLen = brsstrlen((UDINT) Guarding.userData);
			guardWriteData(&Guarding.guardWriteData_0);				/* Call the function block */

			if (Guarding.guardWriteData_0.status == ERR_OK)
			{
				Guarding.Step = 0;
			}
			else if (Guarding.guardWriteData_0.status == ERR_FUB_BUSY)
			{
				/* busy */
			}
			else
			{
				Guarding.Step = 100;
			}
			break;
		
		case 50:	/* Read B&R dongle context data */
			Guarding.guardGetContext_0.enable              = 1;
			Guarding.guardGetContext_0.boxMask             = Guarding.boxMask;
			Guarding.guardGetContext_0.serNo               = Guarding.serNo;
			Guarding.guardGetContext_0.firmCode            = guardBR_FIRMCODE;
			Guarding.guardGetContext_0.maxContextDataCount = sizeof(Guarding.contextData);
			Guarding.guardGetContext_0.pContextData        = (UDINT) Guarding.contextData;
			guardGetContext(&Guarding.guardGetContext_0);
		
			if (Guarding.guardGetContext_0.status == ERR_OK)
			{
				Guarding.Step = 0;
			}
			else if (Guarding.guardGetContext_0.status == ERR_FUB_BUSY)
			{
				/* busy */
			}
			else
			{
				Guarding.Step = 100;
			}
			break;
		
		case 51:	/* Write license data TO B&R dongle */
			Guarding.guardUpdateLicenses_0.enable           = 1;
			Guarding.guardUpdateLicenses_0.pLicenseData     = (UDINT) Guarding.licenseData;
			Guarding.guardUpdateLicenses_0.licenseDataCount = brsstrlen((UDINT) Guarding.licenseData);
			guardUpdateLicenses(&Guarding.guardUpdateLicenses_0);
		
			if (Guarding.guardUpdateLicenses_0.status == ERR_OK)
			{
				Guarding.Step = 0;
			}
			else if (Guarding.guardUpdateLicenses_0.status == ERR_FUB_BUSY)
			{
				/* busy */
			}
			else
			{
				Guarding.Step = 100;
			}
			break;
			
		case 100:  /* Here some error handling has to be implemented */
			break;
	}
}
