static void openSocketSsl();
static void connectToServer();
static void sendData();
static void receiveData();
static void closeSocket();
static void delay(UDINT delayMs);

void TemperatureControlInit();
void TemperatureControl();
