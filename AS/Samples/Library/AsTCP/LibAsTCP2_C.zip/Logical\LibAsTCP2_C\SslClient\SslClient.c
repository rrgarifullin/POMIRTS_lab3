/********************************************************************
* COPYRIGHT -- Bernecker + Rainer
********************************************************************
* Program: SslClient
* File: SslClient.c
* Author: Bernecker + Rainer
* Created: April 15, 2015
********************************************************************
* Implementation of program SslClient
********************************************************************/
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif
#include <SslClient.h>

void _CYCLIC ProgramCyclic(void)
{
	switch (Client.Internal.Step)
	{
		case STEP_START:
			Client.Internal.Step = STEP_OPEN_SOCKET_SSL;
			break;
				
		/* opens ethernet interface for use with SSL */
		case STEP_OPEN_SOCKET_SSL:
			openSocketSsl();
			break;
		
		/* connects to the server */
		case STEP_CONNECT_TO_SERVER:
			connectToServer();
			break;
		
		/* sends data to the server */
		case STEP_SEND_DATA: 
			sendData();
			break;
					
		/* receives data from the server */
		case STEP_RECEIVE_DATA: 
			receiveData();
			break;
		
		/* closes connection */
		case STEP_CLOSE_SOCKET: 
			closeSocket();
			break;
		
		/* error handling */
		case STEP_ERROR:
			Client.Internal.Step = STEP_WAIT;
			break;
		
		case STEP_WAIT:
			delay(Client.Configuration.UpdateTimeMs);
			break;
		
		case STEP_READY:
			Client.Internal.Step = STEP_START;
			break;
	}
	
	TemperatureControl();
}

/* Opens a socket with the given port. */
static void openSocketSsl()
{
	Client.Internal.Fubs.TcpOpenSsl_0.enable 	  = 1;	
	Client.Internal.Fubs.TcpOpenSsl_0.pIfAddr 	  = 0;
	Client.Internal.Fubs.TcpOpenSsl_0.port 		  = Client.Internal.ServerPort;
	Client.Internal.Fubs.TcpOpenSsl_0.sslCfgIdent = 0;
	Client.Internal.Fubs.TcpOpenSsl_0.options 	  = Client.Internal.TcpOptions;	
	TcpOpenSsl(&Client.Internal.Fubs.TcpOpenSsl_0);
						
	if (Client.Internal.Fubs.TcpOpenSsl_0.status == ERR_OK)
	{
		Client.Internal.Step 	  = STEP_CONNECT_TO_SERVER;
		Client.Internal.Ident 	  = Client.Internal.Fubs.TcpOpenSsl_0.ident;
	}
	else if (Client.Internal.Fubs.TcpOpenSsl_0.status != ERR_FUB_BUSY )
	{
		Client.Internal.Step	  = STEP_ERROR;
		Client.Internal.LastError = Client.Internal.Fubs.TcpOpenSsl_0.status;
	}
}

/* Connects to the given server. */
static void connectToServer()
{
	Client.Internal.Fubs.TcpClient_0.enable   = 1;
	Client.Internal.Fubs.TcpClient_0.ident 	  = Client.Internal.Ident;
	Client.Internal.Fubs.TcpClient_0.portserv = Client.Internal.ServerPort;  			/* SSL Port on server side to use */
	Client.Internal.Fubs.TcpClient_0.pServer  = (UDINT) Client.Internal.ServerIpHost; 	/* Server IP address / hostname */
	TcpClient(&Client.Internal.Fubs.TcpClient_0);
			
	if (Client.Internal.Fubs.TcpClient_0.status == ERR_OK)
	{
		Client.Internal.Step = STEP_SEND_DATA;
	}
	else if (Client.Internal.Fubs.TcpClient_0.status != ERR_FUB_BUSY)
	{
		Client.Internal.ErrorFlag = 1;
		Client.Internal.Step 	  = STEP_CLOSE_SOCKET;
		Client.Internal.LastError = Client.Internal.Fubs.TcpClient_0.status;
	}
}

/* Prepares the data to send. */
static void prepareSendData()
{
	Client.Internal.DTGetTime_0.enable = 1;
	DTGetTime(&Client.Internal.DTGetTime_0);
	if(Client.Internal.DTGetTime_0.status == ERR_OK)
	{
		Client.Internal.LastUpdateTimestamp = Client.Internal.DTGetTime_0.DT1;
	}
	Client.SendData.Version 	 = DATA_VERSION_1;
	Client.SendData.ModuleID 	 = Client.ModuleID;
	Client.SendData.SerialNumber = Client.SerialNumber;
	Client.SendData.Timestamp	 = Client.Internal.DTGetTime_0.DT1;
	Client.SendData.Temperature1 = Client.RoomTemperature.CurrentTemperature;
	Client.SendData.Temperature2 = Client.WaterTemperature.CurrentTemperature;
	brsmemset(Client.SendData.TargetDescription, 0, sizeof(Client.SendData.TargetDescription));
	brsstrcpy(Client.SendData.TargetDescription, Client.Configuration.TargetDescription);
}

/* Sends data to the server */
static void sendData()
{
	prepareSendData();
	
	Client.Internal.Fubs.TcpSend_0.enable  = 1;				
	Client.Internal.Fubs.TcpSend_0.ident   = Client.Internal.Ident;
	Client.Internal.Fubs.TcpSend_0.pData   = (UDINT) &(Client.SendData);
	Client.Internal.Fubs.TcpSend_0.datalen = sizeof(Client.SendData);
	Client.Internal.Fubs.TcpSend_0.flags   = 0;
	TcpSend(&Client.Internal.Fubs.TcpSend_0);
				
	if (Client.Internal.Fubs.TcpSend_0.status == ERR_OK)
	{
		Client.Internal.Step = STEP_RECEIVE_DATA;
	}
	else if (Client.Internal.Fubs.TcpSend_0.status != ERR_FUB_BUSY)
	{
		Client.Internal.ErrorFlag = 1;
		Client.Internal.Step	  = STEP_CLOSE_SOCKET;
		Client.Internal.LastError = Client.Internal.Fubs.TcpSend_0.status;
	} 
}

/* Stores the received data. */
static void storeReceivedData()
{
	if (Client.ReceiveData.Version == DATA_VERSION_1)
	{
		Client.RoomTemperature.ReferenceTemperature  = Client.ReceiveData.Temperature1;
		Client.WaterTemperature.ReferenceTemperature = Client.ReceiveData.Temperature2;
	}
}

/* Receives data from server. */
static void receiveData()
{
	Client.Internal.Fubs.TcpRecv_0.enable  = 1;
	Client.Internal.Fubs.TcpRecv_0.ident   = Client.Internal.Ident;
	Client.Internal.Fubs.TcpRecv_0.pData   = (UDINT) &(Client.ReceiveData);
	Client.Internal.Fubs.TcpRecv_0.datamax = sizeof(Client.ReceiveData);
	Client.Internal.Fubs.TcpRecv_0.flags   = 0;
	TcpRecv(&Client.Internal.Fubs.TcpRecv_0);

	if (Client.Internal.Fubs.TcpRecv_0.status == ERR_OK)
	{
		Client.Internal.Step 		   = STEP_CLOSE_SOCKET;
		Client.Internal.ReceiveTimeout = 0;
		
		storeReceivedData();
	}
	else if (Client.Internal.Fubs.TcpRecv_0.status == tcpERR_NO_DATA) 					/* no data received - try again */
	{
		Client.Internal.ReceiveTimeout 	   = Client.Internal.ReceiveTimeout + 1;
		if (Client.Internal.ReceiveTimeout > 50)
		{
			Client.Internal.Step 		   = STEP_CLOSE_SOCKET;
			Client.Internal.ReceiveTimeout = 0;
		}
	}
	else if (Client.Internal.Fubs.TcpSend_0.status != ERR_FUB_BUSY)
	{
		Client.Internal.ErrorFlag = 1;
		Client.Internal.Step 	  = STEP_CLOSE_SOCKET;
		Client.Internal.LastError = Client.Internal.Fubs.TcpSend_0.status;
	}
}

/* Closes the socket. */
static void closeSocket()
{
	Client.Internal.Fubs.TcpClose_0.enable = 1;
	Client.Internal.Fubs.TcpClose_0.ident  = Client.Internal.Ident;
	Client.Internal.Fubs.TcpClose_0.how    = 0;
	TcpClose(&Client.Internal.Fubs.TcpClose_0);
	
	if (Client.Internal.Fubs.TcpClose_0.status == ERR_OK)
	{
		Client.Internal.Step      = STEP_WAIT;
	}
	else if (Client.Internal.Fubs.TcpClose_0.status != ERR_FUB_BUSY)
	{
		Client.Internal.Step 	  = STEP_ERROR;
		Client.Internal.LastError = Client.Internal.Fubs.TcpClose_0.status;
	}
}

/* delays execution for some time */
static void delay(UDINT delayMs)
{
	TIME time = clock_ms();
	if (Client.Internal.LastUpdateTime < (time - delayMs))
	{
		Client.Internal.LastUpdateTime = time;
		Client.Internal.Step = STEP_READY;
	}
}
