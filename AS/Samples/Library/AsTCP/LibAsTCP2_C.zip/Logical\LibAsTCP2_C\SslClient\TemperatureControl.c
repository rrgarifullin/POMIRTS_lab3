
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

/* Returns TRUE if it is time to update the temperature, FALSE otherwise. */
static BOOL isTimeToUpdate(UpdateTimeType * pTime)
{
	TIME currentTimeMs = clock_ms();
	if ((currentTimeMs - pTime->LastUpdateTimeMs) > pTime->UpdateTimeEveryMs)
	{
		pTime->LastUpdateTimeMs = currentTimeMs;
		return 1;
	}
	return 0;
}

static REAL min(REAL a, REAL b)
{
	return (a<b) ? a : b;
}

/* Updates the current temperature. */
static void updateTemperature(TemperatureType * pTemp, REAL maxUpdateValue)
{
	REAL diff = pTemp->ReferenceTemperature - pTemp->CurrentTemperature;
	REAL absolute = (diff < 0) ? -diff : diff;
	REAL adjustValue = min (absolute, maxUpdateValue);
	if (absolute < maxUpdateValue)
		adjustValue *= 1.5;
	if (diff<0)
		adjustValue=-adjustValue;
	pTemp->CurrentTemperature += adjustValue;
}

/* Initial temperature and update values. */
void TemperatureControlInit()
{
	Client.RoomTemperature.CurrentTemperature    = 19.7;
	Client.RoomTemperature.ReferenceTemperature  = 22.0;
	Client.WaterTemperature.CurrentTemperature   = 37.4;
	Client.WaterTemperature.ReferenceTemperature = 50.0;
	Client.Internal.Control.RoomTemperatureTime.UpdateTimeEveryMs  = 500;
	Client.Internal.Control.RoomTemperatureTime.UpdateValue        = 0.008826;
	Client.Internal.Control.WaterTemperatureTime.UpdateTimeEveryMs = 200;
	Client.Internal.Control.WaterTemperatureTime.UpdateValue       = 0.037914;
}

/* Main functions controlling temperature values. */
void TemperatureControl(void)
{
	if (isTimeToUpdate(&Client.Internal.Control.RoomTemperatureTime))
		updateTemperature(&Client.RoomTemperature, Client.Internal.Control.RoomTemperatureTime.UpdateValue);
	
	if (isTimeToUpdate(&Client.Internal.Control.WaterTemperatureTime))
		updateTemperature(&Client.WaterTemperature, Client.Internal.Control.WaterTemperatureTime.UpdateValue);
}
