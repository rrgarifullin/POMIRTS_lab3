/********************************************************************
* COPYRIGHT -- Bernecker + Rainer
********************************************************************
* Program: SslClient
* File: SslClientInit.c
* Author: Bernecker + Rainer
* Created: April 15, 2015
********************************************************************
* Implementation of InitUP of program SslClient
********************************************************************/
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

void TemperatureControlInit();

void _INIT ProgramInit(void)
{	
	/* description of the target */
	brsstrcpy(Client.Configuration.TargetDescription, "SSL Demo");

	/* perform update every 5 seconds */
	Client.Configuration.UpdateTimeMs = 5 * 1000;
	
	/***** internal *****/
	/* server hostname or ip-address*/
	/* strcpy(Client.Internal.ServerIpHost, "80.123.168.215"); */
	brsstrcpy(Client.Internal.ServerIpHost, "10.43.131.50");
	/* strcpy(Client.Internal.ServerIpHost, "sps-socket.br-automation.com"); */
	
	Client.Internal.ServerPort = 7777;				/* server port */
	Client.Internal.ClientPort = 12121;				/* client port */
	Client.Internal.LastUpdateTime = 0;
	Client.Internal.Step = STEP_START;				/* start step for state machine */
	Client.Internal.TcpOptions = tcpOPT_REUSEADDR;	/* TCP option */
	
	TemperatureControlInit();
}
