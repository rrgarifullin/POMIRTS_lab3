/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer 
 ********************************************************************
 * Program: twn4Transp
 * File: twn4Transp.c
 * Author: Bernecker + Rainer
 * Created: december 13, 2017
 ********************************************************************
 * Description: Supports TWN4 transponder reader
 ********************************************************************/


#pragma region "Documentation / comments"
/*
 *	NOTE: Communication based on ISO14443A
 *
 *
 *	Initialization sequence:
 *	------------------------
 *	o- USB_GETNODELIST
 *	|
 *	o- USB_SEARCHDEVICE
 *	|
 *	o- DVF_DEVICEOPEN
 *	|
 *	o- RFID_READ_TAG
 *	|
 *	o- RFID_WRITE
 *	|
 *	o- RFID_READ
 *
 *
 *	Command sequence:
 *	------------------------
 *	o- RFID_GETTAGTYPES | ISO14443A_SEARCHMULTITAG 
 *	|
 *	o- RFID_WRITE
 *	|
 *	o- RFID_READ
 *
 */
#pragma end region


/********************************************************************
 * INCLUDES
 ********************************************************************/
#include <bur/plctypes.h>
#ifdef _DEFAULT_INCLUDES
 #include <AsDefault.h>
#endif
#include <AsUSB.h>
#include <DVFrame.h>
#include <string.h>

#ifndef TRUE
#define	TRUE	1
#endif
#ifndef FALSE
#define	FALSE	0
#endif

/********************************************************************
 * CONSTANTS
 ********************************************************************/
enum{
	IDLE = 0,
	
	USB_GETNODELIST = 		1,
	USB_SEARCHDEVICE,
	DVF_DEVICEOPEN,
	
	RFID_READ_TAG = 		5,
	RFID_WRITE,
	RFID_READ,
	
	RFID_GETTAGTYPES	 		=	10,
	ISO14443A_SEARCHMULTITAG 	= 	20,
};

BOOL is_Twn4_Transponder (usbNode_typ usbDevice)
{
	if (usbDevice.vendorId == TRANSPONDER_TWN4_VENDOR_ID
		&& usbDevice.productId == TRANSPONDER_TWN4_PRODUCT_ID
		&& usbDevice.bcdDevice == TRANSPONDER_TWN4_BCD )
	{
		return TRUE;
	}
	return FALSE;
}


/********************************************************************
 * INIT UP
 ********************************************************************/
void _INIT TranspINIT( void )
{
	usbAttachDetachCount = 0;
    usbNodeIx = 0;
	step = USB_GETNODELIST;	
}


/********************************************************************
 * CYCLIC TASK
 ********************************************************************/
void _CYCLIC TranspCYCLIC( void )
{
	switch (step)
	{
		
		case IDLE:
			/* Idle */
			strcpy((char*)&actionText, (char*)&"IDLE");
		break;
		
		
		case USB_GETNODELIST:
			strcpy((char*)&actionText, (char*)&"USB_GETNODELIST");
			UsbNodeListGetFub.enable = 1;
			UsbNodeListGetFub.pBuffer = (UDINT)&usbNodeList;
			UsbNodeListGetFub.bufferSize = sizeof(usbNodeList);
			UsbNodeListGetFub.filterInterfaceClass = 0;
			UsbNodeListGetFub.filterInterfaceSubClass = 0;
			UsbNodeListGet(&UsbNodeListGetFub);
			
			if (UsbNodeListGetFub.status == ERR_OK && UsbNodeListGetFub.listNodes)
			{
				/* USB Device Attach or detach */
				step = USB_SEARCHDEVICE;
				usbNodeIx = 0;
				usbAttachDetachCount = UsbNodeListGetFub.attachDetachCount;
			}
			/*else if (UsbNodeListGetFub.status == asusbERR_BUFSIZE || UsbNodeListGetFub.status == asusbERR_NULLPOINTER)
				/* Error Handling */
		break;
	
	
		case USB_SEARCHDEVICE:
			strcpy((char*)&actionText, (char*)&"USB_SEARCHDEVICE");
			sizeUsbNode = sizeof(usbDevice);
			UsbNodeGetFub.enable = 1;
			UsbNodeGetFub.nodeId = usbNodeList[usbNodeIx];
			UsbNodeGetFub.pBuffer = (UDINT)&usbDevice;
			UsbNodeGetFub.bufferSize = sizeof(usbDevice);
			UsbNodeGet(&UsbNodeGetFub);
			
			if (UsbNodeGetFub.status == ERR_OK )
			{
				/* USB TWN4 Transponder ? */
				if (TRUE == is_Twn4_Transponder(usbDevice))
				{
					/* USB TWN4 Transponder found */
					strcpy((char*)StringDevice, usbDevice.ifName);
					usbNodeId = usbNodeList[usbNodeIx];
					step = DVF_DEVICEOPEN;
				}
				else
				{
					usbNodeIx++;
					if (usbNodeIx >= UsbNodeListGetFub.allNodes)
						/* USB Device not found */
						step = USB_GETNODELIST;
				}
			}
			else if (UsbNodeGetFub.status == asusbERR_USB_NOTFOUND)
				/* USB Device not found */
				step = USB_GETNODELIST;

			/*else if (UsbNodeGetFub.status == asusbERR_BUFSIZE || UsbNodeGetFub.status == asusbERR_NULLPOINTER)
				/* Error Handling */
		break;
	
	
		case DVF_DEVICEOPEN:
			strcpy((char*)&actionText, (char*)&"DVF_DEVICEOPEN");
			/* initialize open structure */
			FrameXOpenFub.device = (UDINT) StringDevice;
			FrameXOpenFub.mode = (UDINT) 0;
			FrameXOpenFub.config = (UDINT) 0;
			FrameXOpenFub.enable = 1;
			FRM_xopen(&FrameXOpenFub); /* open an interface */
			
			if (FrameXOpenFub.status == frmERR_OK)
			{
				step = RFID_READ_TAG;
			}
				
		break;
	
		case RFID_READ_TAG:
			strcpy((char*)&actionText, (char*)&"RFID_READ_TAG");
			strcpy((char*)WriteData, "050020\r\n");
			ReadAnswer = 1; /* 1 answer */
			step = RFID_WRITE;
		break;
	
	
		case RFID_GETTAGTYPES:
			strcpy((char*)&actionText, (char*)&"RFID_GETTAGTYPES");
			strcpy((char*)WriteData,  "0503\r\n"); 
			ReadAnswer = 1; 		/* 1 slot answer */
			step = RFID_WRITE;
		break;

		
		case ISO14443A_SEARCHMULTITAG:
			strcpy((char*)&actionText, (char*)&"ISO14443A_SEARCHMULTITAG");
			strcpy((char*)WriteData,  "1208FF\r\n"); 
			ReadAnswer = 1; 		/* 1 slot answer */
			step = RFID_WRITE;
			break;

				
		case RFID_WRITE:
			strcpy((char*)&actionText, (char*)&"RFID_WRITE");

			/* initialize write structure */
			FrameWriteFub.ident = FrameXOpenFub.ident;
			FrameWriteFub.buffer = (UDINT)&WriteData;
			FrameWriteFub.buflng = strlen((char*)&WriteData);
			FrameWriteFub.enable = 1;
			FRM_write(&FrameWriteFub); /* write data to interface */
			
			if (FrameWriteFub.status == frmERR_OK) /* check status */
			{
				step = RFID_READ; 
				ReadCount = 0;
			}
		break;


		case RFID_READ:
			strcpy((char*)&actionText, (char*)&"RFID_READ");
			/* initialize read structure */
			FrameReadFub.enable = 1;
			FrameReadFub.ident = FrameXOpenFub.ident;
			FRM_read(&FrameReadFub); /* read data form reader */
			
			pReadBuffer = (UDINT*) FrameReadFub.buffer; /* get adress of read buffer */
			ReadBufferLength = FrameReadFub.buflng; /* get length of read buffer */
			
			if (FrameReadFub.status == frmERR_OK) /* check status */
			{
				memset(ReadData, 0, sizeof(ReadData));
				memcpy(ReadData, (char*)pReadBuffer, ReadBufferLength); 	/* copy read data into array */
				if (ReadBufferLength > 7)
					strcpy(ReadTag, ReadData);	/* copy read data into Tag array */
				
				/* initialize release buffer structure */
				FrameReleaseBufferFub.enable = 1;
				FrameReleaseBufferFub.ident = FrameXOpenFub.ident;
				FrameReleaseBufferFub.buffer = (UDINT) pReadBuffer;
				FrameReleaseBufferFub.buflng = ReadBufferLength;
				FRM_rbuf(&FrameReleaseBufferFub); /* release read buffer */
				
				ReadCount++;
				/* read cycle finished */
				if (ReadCount == ReadAnswer)
					step = IDLE;
			}
		break;

	} /* switch (step) */
	
} /* TranspCYCLIC */
