/**
 * \file    shm.c
 *
 * \brief   Shared Memory implementation
 *
 * \copyright (c) 2012-2015 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  01j, 2017-09-25, Y.Zaporozhets - removed support of kernels older than 2.6.32
 * \li  01i, 2015-06-15, S.Fausser, Y.Zaporozhets - fixed bug #1508 (mapping in shmComOpen was under some
 *                                                  circumstances beyond the shared memory block); in addition fixed
 *                                                  calculation of page offset in lShmMap.
 * \li  01h, 2014-12-05, S.Fausser - replaced schedule() by schedule_timeout in shmComLockAcquire
 * \li  01g, 2013-10-14, S.Fausser - fixed bug #1179, shmComLockAcquire is now interruptible by a signal
 * \li  01f, 2013-07-15, S.Fausser - changed variable type from unsigned to unsigned long in shmComLockAcquire (fixes waiting for timeout)
 * \li  01e, 2013-07-09, S.Fausser - fixed check for offsets greater than area size in shmComRead / shmComWrite,
 *                                   using the variable mAreaSizeReal
 * \li  01d, 2013-01-24, S.Fausser - 1. Ensure that the physical address pointing to the rthCtrl structure addressable within 32 bit
 *                                      (replaced kmalloc w/ GFP_KERNEL by __get_free_pages w/ GFP_DMA32)
 *                                   2. Use enums for register offsets instead of hard-coded values
 * \li  01c, 2012-09-21, C.Gmeiner - fix to use shared memory partitions > 32 MB - #1005
 * \li  01b, 2012-05-30, S.Fausser -  Added memory barriers, mostly wmb() after outl.
 *                                    Without these the return value might be read before the outl is performed
 *                                    due to compiler 'optimizations'
 * \li  01a, 2012-02-15, F.Harmuth - based on S.Fausser/T.Kuehn shmDriver,
 *                                   rewritten for new RTH PCI-Device
 */


/***************************************************************************************************
 *                                            INCLUDES
 */

#include "common.h"

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
#include <linux/sched/signal.h>
#endif

/***************************************************************************************************
 *                                            DEFINES
 */

/**
 * \brief   Return code for an invalid shared memory key.
 *
 * This value is returned, if a function is supposed to return a
 * valid shared memory key but cannot. It generally indicates an error.
 */
#define SHM_KEY_INVALID -1
#define IOREMAP_MAX_MEMORY (32*1024*1024)

/***************************************************************************************************
 *                                           DATA TYPES
 */

typedef struct
{

    char *mpName;

    unsigned long mSize, mBase, mAreaOffset, mAreaSize, mAreaSizeReal;

    void *mpAreaBasePtr;

    int mIsLockedByMe, mIsShmPartitionOpen;
} tShmDesc;

/***************************************************************************************************
 *                                        LOCAL VARIABLES
 */

/**
 * memory the shmPartition to map for next mmap call
 */
static int partitionToMap = -1;
static tShmDesc lpShm[eShmAmount_max];
static uint32_t nShmPartitions = 0;
extern long baseDrv_ioaddr;

/***************************************************************************************************
 *                                      FORWARD DECLARATIONS
 */

/***************************************************************************************************
 *                                         IMPLEMENTATION
 */
static int
rthCall_shmPartGetByIndex(const unsigned index, uint32_t * size, char *mpName, uint32_t * physAddr)
{
    int err = 0;
    tRthCall_shmPartGetByIndex * rthCall;

    if(size == NULL || mpName == NULL || physAddr == NULL)
        return -1;

    if(sizeof(tRthCall_shmPartGetByIndex) > PAGE_SIZE)
        return -1;

    rthCall = (tRthCall_shmPartGetByIndex *) __get_free_pages(GFP_DMA32, 0);
    if(!rthCall)
        return -1;

    memset(rthCall, 0, sizeof(*rthCall));

    rthCall->mHead.mCallSize = sizeof(tRthCall_shmPartGetByIndex);
    rthCall->mHead.mCallNr = eRthCtrl_shmPartGetByIndex;
    rthCall->mShmIdx = index;

    outl(virt_to_phys(rthCall), baseDrv_ioaddr + eRthDevIoOffset_CallPhyAddr);
    wmb();

    if(rthCall->mHead.mReturn != 0)
    {
        *size = rthCall->mShmSize & 0xFFFFFFFF;
        memcpy(mpName, &(rthCall->mShmName), MAX_SHM_PART_NAME_SIZE);
        *physAddr = rthCall->mHead.mReturn & 0xFFFFFFFF;
    }
    else
        err = -1;

    free_pages((unsigned long) rthCall, 0);

    return err;
}

static int
rthCall_shmLockAcquire(const tShmKey key, uint32_t * ret)
{
    tRthCall_shmLockAcquire * rthCall;

    if(ret == NULL)
        return -1;

    if(sizeof(tRthCall_shmLockAcquire) > PAGE_SIZE)
        return -1;

    rthCall = (tRthCall_shmLockAcquire *) __get_free_pages(GFP_DMA32, 0);
    if(!rthCall)
        return -1;

    memset(rthCall, 0, sizeof(*rthCall));

    rthCall->mHead.mCallSize = sizeof(tRthCall_shmLockAcquire);
    rthCall->mHead.mCallNr = eRthCtrl_shmLockAcquire;
    rthCall->mShmIdx = key;

    outl(virt_to_phys(rthCall), baseDrv_ioaddr + eRthDevIoOffset_CallPhyAddr);
    wmb();

    *ret = rthCall->mHead.mReturn & 0xFFFFFFFF;

    free_pages((unsigned long) rthCall, 0);

    return 0;
}

static int
rthCall_shmLockRelease(const tShmKey key, uint32_t * ret)
{
    tRthCall_shmLockRelease * rthCall;

    if(ret == NULL)
        return -1;

    if(sizeof(tRthCall_shmLockRelease) > PAGE_SIZE)
        return -1;

    rthCall = (tRthCall_shmLockRelease *) __get_free_pages(GFP_DMA32, 0);
    if(!rthCall)
        return -1;

    memset(rthCall, 0, sizeof(*rthCall));

    rthCall->mHead.mCallSize = sizeof(tRthCall_shmLockRelease);
    rthCall->mHead.mCallNr = eRthCtrl_shmLockRelease;
    rthCall->mShmIdx = key;

    outl(virt_to_phys(rthCall), baseDrv_ioaddr + eRthDevIoOffset_CallPhyAddr);
    wmb();

    *ret = rthCall->mHead.mReturn & 0xFFFFFFFF;

    free_pages((unsigned long) rthCall, 0);

    return 0;
}

/**
 * \brief search shm partition id of the partition with the name pPName
 *
 * search in local list for a shm partition with the name pPname
 * \return id of the first partition which was found or -1
 */
static int
shmGetPNr(const char *pPName                 /**< the name of the partition */
    )
{
    int i;
    tShmDesc *pEntry = NULL;


    if(NULL == pPName)
        return -1;

    pEntry = lpShm;

    for(i = 0; i < nShmPartitions; i++, pEntry++)
    {
        if(NULL != pEntry->mpName)
        {
            if(0 == strcmp(pPName, pEntry->mpName))
            {
                /* got it! */
                return i;
            }
        }
    }
    /* not found... */
    return -1;
}


/**
 * \brief Initialize shared memory subsystem.
 */
int shmInitialize(void)
{
    unsigned i;
    tShmDesc *pEntry = lpShm;

    if(doRthCall_32(eRthCtrl_shmNumPartGet, &nShmPartitions)) {
        ERR_MSG("%s: shmNumPartGet failed\n", __func__);
        return -2;
    }

    DBG_MSG("%s: number of partitions (%i)\n", __func__, nShmPartitions);

    for(i = 0; i < nShmPartitions; i++, pEntry++) {
        uint32_t size = 0, physAddr = 0;
        char *mpName = (char *) __get_free_pages(GFP_DMA32, 0);

        pEntry->mpName = NULL;
        pEntry->mSize = 0;
        pEntry->mBase = 0;
        pEntry->mAreaOffset = 0;
        pEntry->mAreaSize = 0;
        pEntry->mAreaSizeReal = 0;
        pEntry->mpAreaBasePtr = NULL;
        pEntry->mIsShmPartitionOpen = 0;

        /* check if partition with index i is defined in registry */
        rthCall_shmPartGetByIndex(i, &size, mpName, &physAddr);
        if(0 != physAddr) {
            /* shm partition found */

            /* set shared memory name */
            pEntry->mpName = mpName;

            /* set shared memory physical base address */
            pEntry->mBase = (unsigned long) physAddr;

            /* set shared memory size */
            pEntry->mSize = size;

            DBG_MSG("(shmComInit): partition found: '%s'\n", pEntry->mpName);
        }
    }                       /* end for */

    return 0;
}

/**
 * \brief Shutdown of shared memory subsystem.
 */
void shmShutdown(void)
{
    unsigned i;
    tShmDesc *pEntry = lpShm;

    for(i = 0; i < nShmPartitions; i++, pEntry++) {
        free_pages((unsigned long) pEntry->mpName, 0);
    }
}

/**
 * \brief
 */
unsigned long shmComSizeGet(const char *pName)
{
    int partNr = -1;

    partNr = shmGetPNr(pName);

    DBG_MSG("(shmComSizeGet): partNr (%i)\n", partNr);

    if(partNr == -1)
        return 0;

    return lpShm[partNr].mSize;
}

int
shmComIsKeyValid(const tShmKey key)
{
    if(key < 0 || key >= nShmPartitions)
        return 0;

    if(0 == lpShm[key].mSize || 0 == lpShm[key].mBase)
        return 0;

    return 1;
}

volatile void *
shmComAddrGet(const tShmKey key)
{
    /* check parameters */
    if(shmComIsKeyValid(key))
        return lpShm[key].mpAreaBasePtr;
    else
        return NULL;
}

unsigned long
shmComPhysGet(const tShmKey key)
{
    /* check parameters */
    if(shmComIsKeyValid(key))
        return lpShm[key].mBase + lpShm[key].mAreaOffset;
    else
        return 0;
}

/*  try to open a shared memory area and return the partition number or -1 */
tShmKey
shmComOpen(const char *pShmName, const unsigned long offset, unsigned long *pSize)
{
    int key = SHM_KEY_INVALID;

    /* check arguments */
    if(NULL == pSize)
        return SHM_KEY_INVALID;

    if(NULL == pShmName)
    {
        *pSize = 0;
        return SHM_KEY_INVALID;
    }

    if(!*pSize)
        return SHM_KEY_INVALID;

    key = shmGetPNr(pShmName);

    /* check, if pShmName was found */
    if(-1 == key)
    {
        ERR_MSG("%s: no such partition\n", __func__);
        *pSize = 0;
        return SHM_KEY_INVALID;
    }

    /* test if ppAreaBasePtr is not NULL, meaning shm partition is already open) */
    if(NULL != lpShm[key].mpAreaBasePtr)
    {
        ERR_MSG("%s: partition '%s' is already open\n", __func__, pShmName);
        *pSize = 0;
        return SHM_KEY_INVALID;
    }

    /* check that offset argument is not bigger than size */
    if(offset >= lpShm[key].mSize)
    {
        ERR_MSG("%s: offset 0x%lX greater or equal partition size 0x%lX\n",
               __func__, offset, lpShm[key].mSize);
        *pSize = 0;
        return SHM_KEY_INVALID;
    }

    lpShm[key].mAreaOffset = offset;

    /* if we overlap the maximum size of shared memory area -> reduce the area size */

    if(lpShm[key].mSize - offset < *pSize)
        *pSize = lpShm[key].mSize - offset;

    lpShm[key].mAreaSize = *pSize;
    lpShm[key].mAreaSizeReal = *pSize;

    /* can't map every size reduce it */
    if( lpShm[key].mAreaSize > IOREMAP_MAX_MEMORY)
    {
        lpShm[key].mAreaSize = IOREMAP_MAX_MEMORY;
        *pSize = lpShm[key].mAreaSize;
    }


    /* map physical address to accessible address (e.g. virtual address space) */
    lpShm[key].mpAreaBasePtr =
        ioremap_cache(lpShm[key].mBase + lpShm[key].mAreaOffset, lpShm[key].mAreaSize);

    if(NULL == lpShm[key].mpAreaBasePtr)
    {
        ERR_MSG("%s: memory error\n", __func__);
        lpShm[key].mAreaSize = 0;
        *pSize = 0;
        return SHM_KEY_INVALID;
    }

    /* mark it as open */
    lpShm[key].mIsShmPartitionOpen = 1;

    return key;
}

int
shmComClose(const tShmKey key)
{
    /* check parameters */
    if(0 == shmComIsKeyValid(key))
    {
        ERR_MSG("%s:: invalid key\n", __func__);
        return -1;
    }

    /* shared memory is not open if ppAreaBasePtr == NULL */
    if(NULL == lpShm[key].mpAreaBasePtr)
    {
        ERR_MSG("%s: partition is not open\n", __func__);
        return -1;
    }

    /* shared memory is not open if ... */

    if(0 == lpShm[key].mIsShmPartitionOpen)
    {
        ERR_MSG("%s: partition is not open\n", __func__);
        return -1;
    }

    /* unmap it! */
    iounmap((void __iomem *) ((unsigned long) lpShm[key].mpAreaBasePtr));

    lpShm[key].mpAreaBasePtr = NULL;
    lpShm[key].mIsShmPartitionOpen = 0;

    return 0;
}

unsigned long
shmComRead(const tShmKey key, const unsigned long offset, unsigned long size, void *pBuf)
{
    /* check arguments */
    if(NULL == pBuf)
        return 0;

    if(0 == shmComIsKeyValid(key))
    {
        ERR_MSG("%s: invalid key\n", __func__);
        return 0;
    }

    /* check if partition is open */
    if(0 == lpShm[key].mIsShmPartitionOpen)
    {
        ERR_MSG("%s: partition not open\n", __func__);
        return 0;
    }

    /* check if user tries to read beyond range */
    if(offset > lpShm[key].mAreaSizeReal)
        return 0;

    /* reduce size if too big */
    if(offset + size > lpShm[key].mAreaSizeReal)
        size = lpShm[key].mAreaSizeReal - offset;

    /* copy from shared memory partition to caller memory */
    if (copy_to_user(pBuf, (uint8_t *) lpShm[key].mpAreaBasePtr + offset, size))
    {
        ERR_MSG("%s: copy_to_user failed\n", __func__);
        return 0;
    }

    return size;
}

unsigned long
shmComWrite(const tShmKey key, const unsigned long offset, unsigned long size, const void *pBuf)
{
    /* check arguments */
    if(NULL == pBuf)
        return 0;

    if(0 == shmComIsKeyValid(key))
    {
        ERR_MSG("%s: invalid key\n", __func__);
        return 0;
    }

    /* check if partition is open */
    if(0 == lpShm[key].mIsShmPartitionOpen)
    {
        ERR_MSG("%s: partition not open\n", __func__);
        return 0;
    }

    /* check if user tries to write beyond range */
    if(offset > lpShm[key].mAreaSizeReal)
        return 0;

    /* reduce size if too big */
    if(offset + size > lpShm[key].mAreaSizeReal)
        size = lpShm[key].mAreaSizeReal - offset;

    /* copy from caller memory to shared memory partition */
    if (copy_from_user(lpShm[key].mpAreaBasePtr + offset, pBuf, size))
    {
        ERR_MSG("%s: copy_from_user failed\n", __func__);
        return 0;
    }

    return size;
}

int
shmComLockAcquire(const tShmKey key, const unsigned long timeout)
{
    /* check arguments */
    if(0 == shmComIsKeyValid(key))
    {
        ERR_MSG("%s: invalid key\n", __func__);
        return -2;
    }

    /* check if partition is open */
    if(0 == lpShm[key].mIsShmPartitionOpen)
    {
        ERR_MSG("%s: partition not open\n", __func__);
        return -2;
    }
    else
    {
        const unsigned long start = jiffies, delta = (HZ * timeout) / 1000;  /* might be zero, but it's ok */

        do
        {

            uint32_t ret = 0;
            rthCall_shmLockAcquire(key, &ret);
            if(!ret)
                return 0;

            if(timeout == 0)
                return -1;

            set_current_state(TASK_INTERRUPTIBLE);

            if(signal_pending(current))
            {
                /* interrupted by a signal */
                return -3;
            }

            schedule_timeout(1);

            if(timeout == (unsigned long) -1)
                continue;

        }
        while(jiffies - start <= delta);
    }

    return -1;
}

int
shmComLockRelease(const tShmKey key)
{
    uint32_t ret;

    /* check arguments */
    if(0 == shmComIsKeyValid(key))
    {
        ERR_MSG("%s: invalid key\n", __func__);
        return -2;
    }

    /* check if partition is open */
    if(0 == lpShm[key].mIsShmPartitionOpen)
    {
        ERR_MSG("%s: partition not open\n", __func__);
        /* not open => key invalid */
        return -2;
    }

    rthCall_shmLockRelease(key, &ret);
    if(ret)
        /* not locked by self or not locked at all */
        return -1;

    return 0;
}

/**
 * \brief Cleanup of a shared memory partition.
 */
void shmComCleanup(const char *pName)
{
    uint32_t ret;
    const int key = shmGetPNr(pName);

    if(key < 0)
        return;

    /* release lock if set, don't care about return value */
    rthCall_shmLockRelease(key, &ret);

    /* close partition if open */
    if(NULL != lpShm[key].mpAreaBasePtr)
        iounmap((void __iomem *) ((unsigned long) lpShm[key].mpAreaBasePtr));

    lpShm[key].mpAreaBasePtr = NULL;
    lpShm[key].mIsShmPartitionOpen = 0;
}

/**
 * \brief
 */
static int lShmOpen(const unsigned long arg)
{
    tShmOpen * openPack = NULL;
    char *partitionName = NULL;
    int err =0;

    DBG_MSG("(lShmOpen): ++\n");
    /* check parameter */
    if(0 == arg)
        return -1;

    openPack = (tShmOpen *) arg;

    partitionName = vmalloc(openPack->shmNameSize);
    if(partitionName == NULL)
        return -1;

    if(copy_from_user(partitionName, openPack->pShmName, openPack->shmNameSize))
    {
        err = -1;
        goto out;
    }

    openPack->shmKey = shmComOpen((const char *) partitionName, openPack->offset, openPack->pSize);

out:
    vfree(partitionName);

    return err;
}

static int
lShmClose(const unsigned long arg)
{
    tShmClose *closePack = NULL;


    DBG_MSG("shmClose\n");
    if(0 == arg)
        return -1;

    closePack = (tShmClose *) arg;

    DBG_MSG("(lShmClose): key: %d\n", closePack->shmKey);
    closePack->retVal = shmComClose(closePack->shmKey);

    return 0;
}

static int
lShmRead(const unsigned long arg)
{
    tShmRead *pRead = NULL;


    DBG_MSG("(shmRead): ++\n");

    if(0 == arg)
        return -1;

    pRead = (tShmRead *) arg;

    pRead->bytesRead = shmComRead(pRead->shmKey, pRead->shmOffset, pRead->size, pRead->pCopyTo);

    return 0;
}

static int
lShmWrite(const unsigned long arg)
{
    tShmWrite *pWrite = NULL;


    DBG_MSG("(shmWrite): ++\n");

    if(0 == arg)
        return -1;

    pWrite = (tShmWrite *) arg;

    pWrite->bytesWritten =
        shmComWrite(pWrite->shmKey, pWrite->shmOffset, pWrite->size, pWrite->pCopyFrom);
    return 0;
}

static int
lShmSizeGet(const unsigned long arg)
{
    tShmSizeGet *pParam = (tShmSizeGet *) arg;
    char *partitionName = NULL;
    int err =0;

    DBG_MSG("(shmSizeGet): ++\n");

    partitionName = vmalloc(pParam->shmNameSize);
    if(partitionName == NULL)
        return -1;

    if(copy_from_user(partitionName, pParam->pName, pParam->shmNameSize))
    {
        err =-1;
        goto out;
    }

    pParam->size = shmComSizeGet((const char *) partitionName);

out:
    vfree(partitionName);

    return err;
}

/**
 * \brief
 */
static int lShmMap(const unsigned long arg)
{
    tShmMmap *mapPack = NULL;


    DBG_MSG("(shmMap): ++\n");
    if(0 == arg)
        return -1;

    mapPack = (tShmMmap *) arg;

    if (0 == shmComIsKeyValid(mapPack->partNr))
        return -1;

    partitionToMap = mapPack->partNr;
    /* calculate the page offset */
    mapPack->offset = shmComPhysGet(partitionToMap) % PAGE_SIZE;

    return 0;
}

static int
lShmLockAcquire(const unsigned long arg)
{
    tShmLockAcquire *lockAcquirePack = NULL;

    DBG_MSG("(shmLockAcquire): ++\n");
    if(0 == arg)
        return -1;

    lockAcquirePack = (tShmLockAcquire *) arg;

    lockAcquirePack->retVal = shmComLockAcquire(lockAcquirePack->shmKey, lockAcquirePack->timeout);
    return 0;
}

static int
lShmLockRelease(const unsigned long arg)
{
    tShmLockRelease *lockReleasePack = NULL;


    DBG_MSG("(shmLockRelease): ++\n");
    if(0 == arg)
        return -1;

    lockReleasePack = (tShmLockRelease *) arg;

    lockReleasePack->retVal = shmComLockRelease(lockReleasePack->shmKey);
    return 0;
}

/**
 * \brief Get the name of a shared partition name for a given OS.
 */
static int lShmTracePartitionNameGet(const unsigned long arg)
{
    tRthCall_shmTracePartGet *rthCall;
    tShmTraceGet pack;
    int len, ret = 0;

    if (0 == arg)
        return -1;

    /* Copy the structure from user space */
    if (copy_from_user(&pack, (void *)arg, sizeof(pack)))
        return -2;

    RTHCALL_PREPARE(rthCall, eRthCtrl_shmTracePartGet);

    if (pack.pOsName) {
        /* OS name supplied */
        if (strncpy_from_user(rthCall->mOsName, pack.pOsName, sizeof(rthCall->mOsName)) < 0) {
            ret = eErrCopyToKern;
            goto out;
        }
    } else {
        /* Use "calling OS" */
        uint32_t osId;
        if (rthCall_osIdGet(&osId)) {
            ret = eErrInternal;
            goto out;
        }

        if (rthCall_osCtrlNameGet(osId, rthCall->mOsName, sizeof(rthCall->mOsName))) {
            ret = eErrInternal;
            goto out;
        }
    }

    /* Get the partition name */
    RTHCALL_DO(rthCall);
    ret = rthCall->mHead.mReturn & 0xFFFFFFFF;
    if (ret)
        goto out;

    DBG_MSG("%s: got trace partition name '%s'\n", __func__, rthCall->mShmName);

    /* Copy partition name to user space */
    len = strlen(rthCall->mShmName) + 1;
    if (pack.shmNameSize < len) {
        ret = eErrBufSizeTooSmall;
        goto out;
    }
    if (copy_to_user(pack.pShmTracePartName, rthCall->mShmName, len)) {
        ret = eErrCopyFromKern;
        goto out;
    }

out:
    RTHCALL_FINI(rthCall);
    return ret;
}

/**
 * \brief Clean up the shared memory partition.
 */
static int lShmCleanup(const unsigned long arg)
{
    tShmCleanup *pCleanupPack = NULL;
    char *partitionName = NULL;
    int err =0;

    DBG_MSG("(shmCleanup): ++\n");

    if(0 == arg)
        return -1;

    pCleanupPack = (tShmCleanup *) arg;

    partitionName = vmalloc(pCleanupPack->shmNameSize);
    if(partitionName == NULL)
        return -1;

    if(copy_from_user(partitionName, pCleanupPack->pShmName, pCleanupPack->shmNameSize))
    {
        err = -1;
        goto out;
    }

    shmComCleanup((const char *) partitionName);

out:
    vfree(partitionName);

    return 0;
}

/**
 * \brief Shared memory IOCTL handler.
 */
int shmIoctl(const unsigned cmd, const unsigned long arg, bool *processed)
{
    *processed = true;
    switch (cmd) {
    case eRthIoctl_noFunction:
        return 0;

    case eRthIoctl_shmOpen:
        return lShmOpen(arg);

    case eRthIoctl_shmClose:
        return lShmClose(arg);

    case eRthIoctl_shmRead:
        return lShmRead(arg);

    case eRthIoctl_shmWrite:
        return lShmWrite(arg);

    case eRthIoctl_shmSizeGet:
        return lShmSizeGet(arg);

    case eRthIoctl_shmMmap:
        return lShmMap(arg);

    case eRthIoctl_shmLockAcquire:
        return lShmLockAcquire(arg);

    case eRthIoctl_shmLockRelease:
        return lShmLockRelease(arg);

    case eRthIoctl_shmTracePartitionNameGet:
        return lShmTracePartitionNameGet(arg);

    case eRthIoctl_shmCleanup:
        return lShmCleanup(arg);

    default:
        *processed = false;
    }

    return -1;
}

/**
 * \brief Map shm partition previously set by lShmMap
 */
int shmMapPartition(struct vm_area_struct *vma)
{
    return remap_pfn_range(vma, vma->vm_start,
                shmComPhysGet(partitionToMap) >> PAGE_SHIFT,
                vma->vm_end - vma->vm_start,
                vma->vm_page_prot);
}
