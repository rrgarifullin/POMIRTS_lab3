/**
 * \file    common.h
 *
 * \brief   Declarations for rthBaseDrv
 *
 * \copyright (c) 2012-2016 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  01c, 2016-11-23, Y.Zaporozhets - added RTHCALL_PREPARE, RTHCALL_DO and RTHCALL_FINI
 * \li  01b, 2013-01-24, S.Fausser - removed unnecessary defines for register offsets that
 *                                   are already available as enums in rthVirtPciDev.h
 * \li  01a, 2012-02-17, F.Harmuth - created
 *
 */

#ifndef COMMON_H
#define COMMON_H

/***************************************************************************************************
 *                                            INCLUDES
 */

#include <linux/kernel.h>
#include <linux/version.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,32)
#error Kernel version 2.6.32 or newer is required by this driver
#endif

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/ioport.h>
#include <linux/mm.h>
#include <linux/vmalloc.h>
#include <linux/kthread.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,12,0)
#include <linux/uaccess.h>
#else
#include <asm/uaccess.h>
#endif
#include <asm/io.h>

/* We must define tEventKey here, before including ioctl structures */
typedef int tEventKey;

#include "rthIoctl.h"
#include "rthIoctlDef.h"
#include "rthInterface.h"
#include "rthVirtPciDev.h"

/***************************************************************************************************
 *                                            DEFINES
 */

/* RTH base driver name */
#define DRIVER_NAME             "rthBaseDrv"

/* RTH base driver module name */
#define DRV_MODULE_NAME         DRIVER_NAME"Virt"

/* RTH base driver version */
#define DRIVER_VERSION          "1.5.04"

/* Define this to enable debug printouts */
//#define DEBUG

#ifdef DEBUG
# define DBG_MSG(x...)  pr_info(DRIVER_NAME ": " x)
#else
# define DBG_MSG(x...)
#endif

#define ERR_MSG(x...)   pr_err(DRIVER_NAME ": " x)

/*
 * The actual hypervisor call happens in three stages:
 *   first we prepare the call descriptor (it must be always allocated below 4G)
 *      and fill in necessary fields;
 *   then we perform the actual call;
 *   finally, we free the allocated memory.
 * The sequence is split into three steps for cases when something must be done
 * in between (like filling in additional fields, getting the result etc).
 *
 * Parameters to these macros:
 *  ptr:  the pointer to call descriptor
 *  nr:   call number (from eRthCtrl list)
 */
#define RTHCALL_PREPARE(ptr, nr)    ({\
    if(sizeof(*ptr) > PAGE_SIZE) {  \
        pr_err("%s: rth call structure is bigger than page size", __func__); \
        return -1;                  \
    }                               \
    ptr = (void *) __get_free_pages(GFP_DMA32, 0); \
    if(!ptr) {                      \
        pr_err("%s: could not get free memory page in DMA32 region", __func__); \
        return -1;                  \
    }                               \
    memset(ptr, 0, sizeof(*ptr));   \
                                    \
    ptr->mHead.mCallSize = sizeof(*ptr); \
    ptr->mHead.mCallNr = nr; })

#define RTHCALL_DO(ptr) ({\
    outl(virt_to_phys(ptr), baseDrv_ioaddr + eRthDevIoOffset_CallPhyAddr); \
    wmb();})

#define RTHCALL_FINI(ptr) \
    free_pages((unsigned long) ptr, 0);


/* To allocate memory below 4G */
#define VMALLOC32(n)    __vmalloc(n, GFP_DMA32, PAGE_KERNEL)

/***************************************************************************************************
 *                                           DATA TYPES
 */

/**
 * \brief   Type definition for a shared memory key.
 *
 *  This data type defines a shared memory key, which is used to
 *  identify and access a shared memory partition.
 */
typedef int tShmKey;



/*
 * A note regarding return values in ioctl handlers (from the LDD book):
 *
 * On return from any system call, a positive value is preserved, while a
 * negative value is considered an error and is used to set errno in user space.
 */

/* Error codes, used throughout the driver, helping to diagnose problems */
#define ERRBV -1000
enum {
    eErrInternal        = ERRBV-1,
    eErrOsNameNull      = ERRBV-2,
    eErrOsNameInvalid   = ERRBV-3,
    eErrStringInvalid   = ERRBV-4,
    eErrNullBuffer      = ERRBV-5,
    eErrBufSizeTooBig   = ERRBV-6,
    eErrBufSizeTooSmall = ERRBV-7,
    eErrCopyToKern      = ERRBV-8,
    eErrCopyFromKern    = ERRBV-9,
    eErrMemAlloc        = ERRBV-10
};

/* Maximum number of shm partitions */
enum { eShmAmount_max = 100 };

/***************************************************************************************************
 *                                     FUNCTION DECLARATIONS
 */

/* misc.c */
int rthIoctlMisc (const unsigned cmd, const unsigned long arg, bool *processed);
int doRthCall_64 (const tRthCtrl type, uint64_t * n);
int doRthCall_32 (const tRthCtrl type, uint32_t * n);
int doRthCall_Param1 (const tRthCtrl type, uint32_t *param);

/* timeSync.c */
int timeSync (const unsigned cmd, const unsigned long arg, bool *processed);

/* event.c */
int rthIoctlEvent (const unsigned cmd, const unsigned long arg, bool *processed);
irqreturn_t event_isr (int irq, void *dev);
void initEventSystem (void);
void cleanupEventSystem (void);

/* wdIncTask.c */
int startWdIncTask (void);
void stopWdIncTask (void);
void rthOsWatchdogKick (void);

/* osCtrl.c */
int osCtrl (const unsigned cmd, const unsigned long arg, bool *processed);
int rthCall_osIdGet (uint32_t * ret);
int rthCall_osCtrlNameGet (const uint32_t osId, char *pBuf, uint32_t buf_size);
int rthCall_osCtrlCommandGet (void);
int rthCall_osCtrlStateSet (uint32_t state);

/* shm.c */
int shmIoctl (const unsigned cmd, const unsigned long arg, bool *processed);
int shmInitialize (void);
void shmShutdown (void);

unsigned long shmComSizeGet (const char *pName);
tShmKey shmComOpen (const char *pShmName, const unsigned long offset, unsigned long *pSize);
int shmComClose (const tShmKey key);
int shmComIsKeyValid (const tShmKey key);
unsigned long shmComPhysGet (const tShmKey key);
int shmMapPartition(struct vm_area_struct *vma);

int shmComLockAcquire (const tShmKey key, const unsigned long timeout);
int shmComLockRelease (const tShmKey key);

#endif /* COMMON_H */
