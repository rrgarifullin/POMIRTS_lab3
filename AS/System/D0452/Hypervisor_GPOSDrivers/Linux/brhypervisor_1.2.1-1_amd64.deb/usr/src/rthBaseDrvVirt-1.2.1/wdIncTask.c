/**
 * \file    wdIncTask.c
 *
 * \brief   Implementation of watchdog task
 *
 * \copyright (c) 2012-2013 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  01b, 2013-01-24, S.Fausser - Use enums for register offsets instead of hard-coded values
 * \li  01a, 2012-02-16, F.Harmuth - created
 *
 */


/***************************************************************************************************
 *                                            INCLUDES
 */

#include "common.h"


/***************************************************************************************************
 *                                            DEFINES
 */

/***************************************************************************************************
 *                                           DATA TYPES
 */

/***************************************************************************************************
 *                                        LOCAL VARIABLES
 */
static struct task_struct *wdInc_task;
extern long baseDrv_ioaddr;

/***************************************************************************************************
 *                                      FORWARD DECLARATIONS
 */

/***************************************************************************************************
 *                                         IMPLEMENTATION
 */

/**
 * \brief Increment the watchdog.
 */
void rthOsWatchdogKick(void)
{
    outl(1 << 1, baseDrv_ioaddr + eRthDevIoOffset_Command);
}

static int
wdIncTask(void *pArg)
{
    pr_info(DRIVER_NAME ": %s: started\n", __func__);

    while(!kthread_should_stop())
    {
        /* increment watchdog count */
        outl(1 << 1, baseDrv_ioaddr + eRthDevIoOffset_Command);

        /* sleep for (at least) 1000 milliseconds */
        schedule_timeout_interruptible(msecs_to_jiffies(1000));
    }

    pr_info(DRIVER_NAME ": %s: stopped\n", __func__);

    return 0;
}

int
startWdIncTask(void)
{
    wdInc_task = kthread_run(wdIncTask, NULL, "rthWatchdogTask");

    if(IS_ERR(wdInc_task))
    {
        ERR_MSG("%s: Unable to create kernel thread\n", __func__);
        return -1;
    }

    DBG_MSG("%s: Kernel thread created and started\n", __func__);
    return 0;
}

void
stopWdIncTask(void)
{
    kthread_stop(wdInc_task);
}
