/**
 * \file    osCtrl.c
 *
 * \brief   OS Control API implementation
 *
 * \copyright (c) 2012-2015 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  02b, 2017-09-25, Y.Zaporozhets - removed support of kernels older than 2.6.32
 * \li  02a, 2017-09-20, Y.Zaporozhets - removed all occurrences of strlen_user (required for 4.13+)
 * \li  01m, 2017-08-23, Y.Zaporozhets - added implementations of lOsRuntimeGet() and lOsWdBootTimeoutSet()
 * \li  01l, 2017-08-22, Y.Zaporozhets - removed much of duplicated code, use RTHCALL macros instead
 * \li  01k, 2017-08-21, Y.Zaporozhets - added lOsBootlineGet
 * \li  01j, 2015-10-08, Y.Zaporozhets - use ioremap_cache() for kernels versions 2.6.25+
 *                                       (fixes bug #1591)
 * \li  01i, 2014-12-11, S.Fausser - fixed bug #1330 (32 bit Linux related): copy image from kernel to
 *                                   user space chunk-wise (1 MByte per chunk)
 * \li  01h, 2014-12-06, S.Fausser - fixed bug #1330: fixed maximum string lengths
 *                                   (note that strlen_user returns the string size including the terminating '\0')
 * \li  01g, 2014-03-18, M.Schunda - add function lRthSysCtrlShutdown and lRthSysCtrlReboot
 * \li  01f, 2013-07-25, S.Fausser - fixed bug #1089: fixed type in lOsBootlineSet
 * \li  01e, 2013-01-29, S.Fausser - fixed bug #1071 (lOsReset function set eRthCtrl_osCtrlReboot instead of eRthCtrl_osCtrlReset)
 * \li  01d, 2013-01-24, S.Fausser - 1. Ensure that the physical address pointing to the rthCtrl structure addressable within 32 bit
 *                                      (replaced kmalloc w/ GFP_KERNEL by __get_free_pages w/ GFP_DMA32)
 *                                   2. Use enums for register offsets instead of hard-coded values
 *                                   3. Fixed buffer size in copy_from_user to be 'provably' correct
 * \li  01c, 2012-06-19, S.Fausser - lRthOsLoadImage rewritten (fixes bug 925)
 * \li  01b, 2012-05-30, S.Fausser -  Added memory barriers, mostly wmb() after outl.
 *                                    Without these the return value might be read before the outl is performed
 *                                    due to compiler 'optimizations'
 * \li  01a, 2012-02-15, F.Harmuth - created
 *
 */


/***************************************************************************************************
 *                                            INCLUDES
 */

#include "common.h"
#include "shmImgStructs.h"

/***************************************************************************************************
 *                                            DEFINES
 */

#define MAX_SIZE_IOREMAP 0x100000

/***************************************************************************************************
 *                                           DATA TYPES
 */

/***************************************************************************************************
 *                                        LOCAL VARIABLES
 */

extern long baseDrv_ioaddr;

/***************************************************************************************************
 *                                      FORWARD DECLARATIONS
 */

/***************************************************************************************************
 *                                         IMPLEMENTATION
 */

static int lRthSysCtrlShutdown(void)
{
    int err = 0;

    tRthCall *rthCall;

    if(sizeof(tRthCall) > PAGE_SIZE)
        return -1;

    rthCall = (tRthCall *) __get_free_pages(GFP_DMA32, 0);
    if(!rthCall)
        return -1;

    memset(rthCall, 0, sizeof(*rthCall));

    rthCall->mCallSize = sizeof(tRthCall);
    rthCall->mCallNr = eRthCtrl_sysShutdown;
    rthCall->mReturn = -1;

    pr_info("RTH: system shutdown requested\n");
    RTHCALL_DO(rthCall);

    err = rthCall->mReturn;

    RTHCALL_FINI(rthCall);

    return err;
}

static int lRthSysCtrlReboot(void)
{
    int err = 0;

    tRthCall *rthCall;

    if(sizeof(tRthCall) > PAGE_SIZE)
        return -1;

    rthCall = (tRthCall *) __get_free_pages(GFP_DMA32, 0);
    if(!rthCall)
        return -1;

     memset(rthCall, 0, sizeof(*rthCall));

    rthCall->mCallSize = sizeof(tRthCall);
    rthCall->mCallNr = eRthCtrl_sysReboot;
    rthCall->mReturn = -1;

    pr_info("RTH: system reboot requested\n");
    RTHCALL_DO(rthCall);

    err = rthCall->mReturn;

    RTHCALL_FINI(rthCall);

    return err;
}

int
rthCall_osIdGet(uint32_t *ret)
{
    int err = 0;
    tRthCall_osCtrlIdGet *rthCall;

    if(ret == NULL)
        return -1;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osCtrlIdGet);
    RTHCALL_DO(rthCall);

    if(!rthCall->mHead.mReturn)
        *ret = rthCall->mOsId;
    else
        err = rthCall->mHead.mReturn;

    RTHCALL_FINI(rthCall);

    return err;
}

int
rthCall_osCtrlNameGet(const uint32_t osId, char *pBuf, uint32_t buf_size)
{
    tRthCall_osCtrlNameGet *rthCall;

    if(pBuf == NULL || buf_size == 0)
    {
        ERR_MSG("%s: pBuf == NULL || buf_size == 0", __func__);
        return -1;
    }

    RTHCALL_PREPARE(rthCall, eRthCtrl_osCtrlNameGet);

    rthCall->mOsId = osId;
    rthCall->mOsName[0] = '\0';

    RTHCALL_DO(rthCall);

    if(rthCall->mHead.mReturn == 0)
        memcpy(pBuf, rthCall->mOsName, buf_size);

    RTHCALL_FINI(rthCall);

    return rthCall->mHead.mReturn & 0xFFFFFFFF;
}

int
rthCall_osCtrlCommandGet(void)
{
    uint32_t ret;

    if(doRthCall_32(eRthCtrl_osCtrlCommandGet, &ret))
        return -1;
    else
        return ret;
}

int
rthCall_osCtrlStateSet(uint32_t state)
{
    int err = 0;
    tRthCall1Param *rthCall;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osCtrlStateSet);

    rthCall->mParam0 = state;

    RTHCALL_DO(rthCall);

    err = 0 - (rthCall->mHead.mReturn & 0xFFFFFFFF);

    RTHCALL_FINI(rthCall);

    return err;
}

static int lOsMaxIdGet(const unsigned long arg)
{
    uint32_t * maxId;

    if(arg == 0)
        return -1;

    maxId = (uint32_t *) arg;

    if(doRthCall_32(eRthCtrl_osCtrlMaxIdGet, maxId))
        return -1;

    DBG_MSG("%s: maxId %d\n", __func__, *maxId);

    return 0;
}

/**
 * \brief Get the operating system name from its id.
 */
static int lOsNameGet(const unsigned long arg)
{
    tOsNameGet *param = (tOsNameGet *) arg;
    char *pBuffer;
    int err = eErrInternal;

    if (arg == 0)
        return err;

    if (param->pBuffer == NULL)
        return eErrNullBuffer;

    if (param->bufferSize > MAX_OS_NAME_SIZE) {
        ERR_MSG("buf_size %d (max allowed %d)\n", param->bufferSize, MAX_OS_NAME_SIZE);
        return eErrBufSizeTooBig;
    }

    pBuffer = VMALLOC32(param->bufferSize);
    if (pBuffer == NULL)
        return eErrMemAlloc;

    err = rthCall_osCtrlNameGet(param->osId, pBuffer, param->bufferSize);
    if (err) {
        DBG_MSG("%s: osCtrlNameGet failed (%i)\n", __func__, err);
        goto out;
    }

    if (copy_to_user((void *) param->pBuffer, pBuffer, param->bufferSize)) {
        DBG_MSG("%s: copy_to_user failed\n", __func__);
        err = eErrCopyFromKern;
        goto out;
    }

out:
    vfree(pBuffer);

    return err;
}

static int
lOsIdGet(const unsigned long arg)
{
    uint32_t maxId, actId;
    tOsIdGet * param;
    char *pOsName, *pName;
    int err = -1;

    if(arg == 0)
        return -1;

    param = (tOsIdGet *) arg;
    if(param->pOsName == NULL) {
        /* Use the "calling OS" */
        err = rthCall_osIdGet(&actId);

        if(!err)
            param->osId = actId;

        return err;
    }

    /* Allocate buffers */
    pOsName = VMALLOC32(MAX_OS_NAME_SIZE);
    if (pOsName == NULL)
        return eErrMemAlloc;
    pName = VMALLOC32(MAX_OS_NAME_SIZE);
    if (pName == NULL) {
        vfree(pOsName);
        return eErrMemAlloc;
    }

    /* Copy OS name from the user space */
    if (strncpy_from_user(pOsName, param->pOsName, MAX_OS_NAME_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    pOsName[MAX_OS_NAME_SIZE-1] = '\0';

    if(doRthCall_32(eRthCtrl_osCtrlMaxIdGet, &maxId))
        goto out;

    for(actId = 0; actId <= maxId; actId++)
    {
        if(!rthCall_osCtrlNameGet(actId, pName, MAX_OS_NAME_SIZE))
        {
            if(!strcmp(pName, pOsName))
            {
                param->osId = actId;
                err = 0;
                goto out;
            }
        }
    }

out:
    vfree(pOsName);
    vfree(pName);
    return err;
}

static int
lOsStateGet(const unsigned long arg)
{
    tOsStateGet *param = (tOsStateGet *) arg;
    tRthCall_osCtrlStateGet *rthCall;
    int err;
    const int n = sizeof(rthCall->mOsName);

    if(arg == 0)
        return -1;

    if(param->pOsName == 0)
        return -1;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osCtrlStateGet);

    if (strncpy_from_user(rthCall->mOsName, param->pOsName, n) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mOsName[n-1] = '\0';

    RTHCALL_DO(rthCall);

    err = rthCall->mHead.mReturn & 0xFFFFFFFF;
    param->osState = rthCall->mOsState;

out:
    RTHCALL_FINI(rthCall);

    return err;
}

static int
lOsShutDown(const unsigned long arg)
{
    int err = eErrInternal;
    tOsShutDown *param = (tOsShutDown *)arg;
    tRthCall_osCtrlShutDown *rthCall;
    const int n = sizeof(rthCall->mOsName);

    if(arg == 0)
        return err;

    if(param->pOsName == NULL)
        return err;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osCtrlShutDown);

    if (strncpy_from_user(rthCall->mOsName, param->pOsName, n) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mOsName[n-1] = '\0';

    RTHCALL_DO(rthCall);

    err = rthCall->mHead.mReturn & 0xFFFFFFFF;

out:
    RTHCALL_FINI(rthCall);

    return err;
}

static int
lOsHalt(const unsigned long arg)
{
    tOsHalt *param = (tOsHalt *) arg;
    tRthCall_osCtrlHalt *rthCall;
    int err = eErrInternal;

    if(arg == 0)
        return err;

    if(param->pOsName == NULL)
        return eErrOsNameInvalid;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osCtrlHalt);

    /* Copy OS name from the user space */
    if (strncpy_from_user(rthCall->mOsName, param->pOsName, MAX_OS_NAME_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mOsName[MAX_OS_NAME_SIZE-1] = '\0';

    RTHCALL_DO(rthCall);

    err = rthCall->mHead.mReturn & 0xFFFFFFFF;

out:
    RTHCALL_FINI(rthCall);

    return err;
}

static int
lOsBoot(const unsigned long arg)
{
    tOsBoot *param = (tOsBoot *) arg;
    tRthCall_osCtrlBoot *rthCall;
    int err = eErrInternal;

    if(arg == 0)
        return err;

    if(param->pOsName == NULL)
        return eErrOsNameInvalid;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osCtrlBoot);

    /* Copy OS name from the user space */
    if (strncpy_from_user(rthCall->mOsName, param->pOsName, MAX_OS_NAME_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mOsName[MAX_OS_NAME_SIZE-1] = '\0';
    rthCall->mRuntime = param->runtime;

    RTHCALL_DO(rthCall);

    err = rthCall->mHead.mReturn & 0xFFFFFFFF;

out:
    RTHCALL_FINI(rthCall);

    return err;
}

static int
lOsReboot(const unsigned long arg)
{
    tOsReboot *param = (tOsReboot *) arg;
    tRthCall_osCtrlReboot *rthCall;
    int err = eErrInternal;

    if(arg == 0)
        return -1;

    if(param->pOsName == NULL)
        return eErrOsNameInvalid;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osCtrlReboot);

    /* Copy OS name from the user space */
    if (strncpy_from_user(rthCall->mOsName, param->pOsName, MAX_OS_NAME_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mOsName[MAX_OS_NAME_SIZE-1] = '\0';
    rthCall->mRuntime = param->runtime;

    RTHCALL_DO(rthCall);

    err = rthCall->mHead.mReturn & 0xFFFFFFFF;

out:
    RTHCALL_FINI(rthCall);

    return err;
}

static int
lOsReset(const unsigned long arg)
{
    tOsReset *param = (tOsReset *) arg;
    tRthCall_osCtrlReset *rthCall;
    int err = eErrInternal;

    if(arg == 0)
        return -1;

    if(param->pOsName == NULL)
        return eErrOsNameInvalid;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osCtrlReset);

    /* Copy OS name from the user space */
    if (strncpy_from_user(rthCall->mOsName, param->pOsName, MAX_OS_NAME_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mOsName[MAX_OS_NAME_SIZE-1] = '\0';
    rthCall->mRuntime = param->runtime;

    RTHCALL_DO(rthCall);

    err = rthCall->mHead.mReturn & 0xFFFFFFFF;

out:
    RTHCALL_FINI(rthCall);

    return err;
}

/**
 * \brief Set the bootline for the given OS / runtime
 */
static int lOsBootlineSet(const unsigned long arg)
{
    tOsBootlineSet *param = (tOsBootlineSet *) arg;
    tRthCall_osBootlineSet *rthCall;
    int err = eErrInternal;

    if(arg == 0)
        return err;

    if(param->pOsName == NULL)
        return eErrOsNameInvalid;

    if(param->pBootline == NULL)
        return eErrStringInvalid;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osBootlineSet);

    /* Copy OS name from the user space */
    if (strncpy_from_user(rthCall->mOsName, param->pOsName, MAX_OS_NAME_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mOsName[MAX_OS_NAME_SIZE-1] = '\0';

    /* Copy boot line from the user space */
    if (strncpy_from_user(rthCall->mBootline, param->pBootline, MAX_OS_BOOTLINE_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mBootline[MAX_OS_BOOTLINE_SIZE-1] = '\0';

    rthCall->mRuntime = param->runtime;

    RTHCALL_DO(rthCall);

    err = rthCall->mHead.mReturn & 0xFFFFFFFF;

out:
    RTHCALL_FINI(rthCall);

    return err;
}

/**
 * \brief Get the bootline for the given OS / runtime
 */
static int lOsBootlineGet(const unsigned long arg)
{
    tOsBootlineGet *param = (tOsBootlineGet *) arg;
    tRthCall_osBootlineGet *rthCall;
    int len_Bootline;
    int err = eErrInternal;

    if(arg == 0)
        return err;

    /* Validate the OS name */
    if(param->pOsName == NULL)
        return eErrOsNameNull;

    /* Is buffer for bootline supplied? */
    if(param->pBootline == NULL)
        return eErrNullBuffer;

    /* Buffer may be bigger than our bootline size, but not too much */
    if(param->bootlineBufSize > MAX_OS_BOOTLINE_SIZE*2)
        return eErrBufSizeTooBig;

    /* Zero-length buffer also hasn't much use */
    if(param->bootlineBufSize < 1)
        return eErrBufSizeTooSmall;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osBootlineGet);

    /* Copy OS name from the user space */
    if (strncpy_from_user(rthCall->mOsName, param->pOsName, MAX_OS_NAME_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mOsName[MAX_OS_NAME_SIZE-1] = '\0';

    rthCall->mRuntime = param->runtime;

    RTHCALL_DO(rthCall);

    /* If boot line was truncated, this is not an error */
    err = rthCall->mHead.mReturn & 0xFFFFFFFF;
    if ((err != 0) && (err != 5))
        goto out;

    len_Bootline = strlen(rthCall->mBootline) + 1;
    if (len_Bootline > MAX_OS_BOOTLINE_SIZE) {
        /* Quite unlikely scenario, but better exit at this point */
        err = eErrInternal;
        goto out;
    }

    if (len_Bootline > param->bootlineBufSize)
    {
        /* We truncate the boot line */
        err = 5;
        len_Bootline = param->bootlineBufSize;
    }

    /* Copy boot line into the user buffer */
    if(copy_to_user(param->pBootline, rthCall->mBootline, len_Bootline)) {
        err = eErrCopyFromKern;
    }

out:
    RTHCALL_FINI(rthCall);

    return err;
}

/**
 * \brief Copy bytes from user-space to shared memory partition.
 */
static int copyUserToKernel(const char *pShmName,
                            const unsigned long initialoffset,
                            unsigned long size,
                            const void __user *pUser)
{
    tShmKey shmKey;
    unsigned long sizeRest = size;
    char *pShm;
    const void __user *pUserTmp;
    unsigned long offset = initialoffset;

    do
    {
        unsigned long shmOpenSize = sizeRest;

        if(shmOpenSize > MAX_SIZE_IOREMAP)
            shmOpenSize = MAX_SIZE_IOREMAP;

        shmKey = shmComOpen(pShmName, offset, &shmOpenSize);
        if(!shmComIsKeyValid(shmKey))
            return -1;

        if(shmComLockAcquire(shmKey, 1000))
        {
            shmComClose(shmKey);
            return -2;
        }

        /* Map shared memory partition */
        pShm = (char *) ioremap_cache(shmComPhysGet(shmKey), shmOpenSize);

        pUserTmp = (const void __user *) ((uint8_t *) pUser + offset - initialoffset);

        /* Copy the contents to shared memory partition */
        if(copy_from_user(pShm, pUserTmp, shmOpenSize))
        {
            shmComLockRelease(shmKey);
            shmComClose(shmKey);
            return -3;
        }

        iounmap(pShm);

        sizeRest -= shmOpenSize;
        offset += shmOpenSize;

        shmComLockRelease(shmKey);
        shmComClose(shmKey);
    } while(sizeRest > 0);

    return 0;
}

/**
 * \brief Load the operating system image.
 */
static int lOsLoadImage(const unsigned long arg)
{
    tOsLoadImage *param = (tOsLoadImage *) arg;
    char *pOsName, *pName, *pShmPartName;
    uint32_t maxId, actId, shmSize;
    tShmKey shmKey;
    unsigned long shmOpenSize;
    char *pShm;
    tShmImage *pShmImage;
    int err = eErrInternal;

    if(arg == 0)
        return err;

    if(param->pOsName == NULL)
        return eErrOsNameInvalid;

    /* Allocate buffers */
    err = eErrMemAlloc;
    pOsName = VMALLOC32(MAX_OS_NAME_SIZE);
    if (pOsName == NULL)
        return err;
    pName = VMALLOC32(MAX_OS_NAME_SIZE);
    if (pName == NULL)
        goto out3;
    pShmPartName = VMALLOC32(MAX_SHM_PART_NAME_SIZE);
    if (pName == NULL)
        goto out2;

    /* Copy the OS name to the buffer */
    if(strncpy_from_user(pOsName, param->pOsName, MAX_OS_NAME_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }

    if(doRthCall_32(eRthCtrl_osCtrlMaxIdGet, &maxId))
        goto out;

    /* Find the operating system id */
    for(actId = 0; actId <= maxId; actId++)
    {
        if(!rthCall_osCtrlNameGet(actId, pName, MAX_OS_NAME_SIZE)) {
            if(!strcmp(pName, pOsName))
                break;
        }
    }

    err = eErrOsNameInvalid;
    if(actId > maxId)
        goto out;

    snprintf(pShmPartName, MAX_OS_NAME_SIZE, "%s%02u%02u%02u", SHM_IMG_PREFIX, actId, (unsigned) param->runtime,
             (unsigned) param->imageNumber);
    DBG_MSG("%s: shm part name %s\n", __func__, pShmPartName);

    shmSize = shmComSizeGet(pShmPartName);
    if(!shmSize)
        goto out;

    // Update image size in header

    shmOpenSize = sizeof(tShmImage);
    shmKey = shmComOpen(pShmPartName, 0, &shmOpenSize);

    if(!shmComIsKeyValid(shmKey))
        goto out;

    if(shmOpenSize != sizeof(tShmImage)) {
        shmComClose(shmKey);
        goto out;
    }

    if(shmComLockAcquire(shmKey, 1000)) {
        shmComClose(shmKey);
        goto out;
    }

    /* Map shared memory partition */
    pShm = ioremap_cache(shmComPhysGet(shmKey), shmOpenSize);
    if(pShm == 0)
    {
        shmComLockRelease(shmKey);
        shmComClose(shmKey);
        return -1;
    }

    pShmImage = (tShmImage *) pShm;

    /* Check if size of shared memory partition (shmSize) is equal or greater than the size
     * of the image to load (param->imageSize) and the structure size (pShmImage->mStructSize)*/
    if(shmSize < (param->imageSize + pShmImage->mStructSize))
    {
        shmComLockRelease(shmKey);
        shmComClose(shmKey);
        return -3;
    }

    if(pShmImage->mStructSize != sizeof(tShmImage)) {
        shmComLockRelease(shmKey);
        shmComClose(shmKey);
        err = eErrInternal;
        goto out;
    }

    /* Set new image size */
    pShmImage->mImageSize = param->imageSize;

    /* Unmap shared memory partition (access to it will result in page fault) */
    iounmap(pShm);

    shmComLockRelease(shmKey);
    shmComClose(shmKey);

    /* Open shared memory partition, offset = structure size (sizeof(pShmImage->mStructSize)) */
    err = copyUserToKernel(pShmPartName, sizeof(tShmImage), param->imageSize, param->pImage);

    if (err)
        err = eErrCopyFromKern;

out:
    vfree(pShmPartName);
out2:
    vfree(pName);
out3:
    vfree(pOsName);

    return err;
}

static int lOsWdCountGet(const unsigned long arg)
{
    tOsWdCountGet *param = (tOsWdCountGet *) arg;
    tRthCall_wdCountGet *rthCall;
    int err = eErrInternal;

    if(arg == 0)
        return err;

    if(param->pOsName == NULL)
        return eErrOsNameInvalid;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osCtrlWdCountGet);

    /* Copy the OS name to the buffer */
    if(strncpy_from_user(rthCall->mOsName, param->pOsName, MAX_OS_NAME_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mOsName[MAX_OS_NAME_SIZE - 1] = '\0';

    RTHCALL_DO(rthCall);

    err = rthCall->mHead.mReturn & 0xFFFFFFFF;

    if(!err)
        param->wdCount = rthCall->mCount;

out:
    RTHCALL_FINI(rthCall);

    return err;
}

static int
lOsCtrlCommandGet (const unsigned long arg)
{
    int ret;
    tOsCtrlCommandGet * param = (tOsCtrlCommandGet *) arg;

    if(arg == 0)
        return -1;

    ret = rthCall_osCtrlCommandGet();
    if(ret == -1)
    {
        ERR_MSG("%s: Unable to get OS id of running OS (%d)\n", __func__, ret);
        return -1;
    }

    param->osCommand = ret;

    return 0;
}

static int
lOsCtrlStateSet (const unsigned long arg)
{
    tOsCtrlStateSet *param = (tOsCtrlStateSet *) arg;

    if(arg == 0)
        return -1;

    return rthCall_osCtrlStateSet(param->state);
}

/**
 * \brief Get information about active runtime and configured runtimes.
 */
static int lOsRuntimeGet(const unsigned long arg)
{
    tOsRuntimeGet *param = (tOsRuntimeGet *)arg;
    tRthCall_osRuntimeGet *rthCall;
    int err = eErrInternal;
    const int n = sizeof(rthCall->mOsName);

    RTHCALL_PREPARE(rthCall, eRthCtrl_osRuntimeGet);

    if (strncpy_from_user(rthCall->mOsName, param->pOsName, n) < 0) {
        err = eErrCopyToKern;
        goto out;
    }
    rthCall->mOsName[n-1] = '\0';

    RTHCALL_DO(rthCall);

    err = eErrCopyFromKern;
    if (param->pActiveRuntime) {
        if (copy_to_user(param->pActiveRuntime, &rthCall->mActiveRuntime,
                     sizeof(rthCall->mActiveRuntime))) {
            ERR_MSG("%s: copy_to_user failed (actRuntime)\n", __func__);
            goto out;
        }
    }
    if (param->pMaxRuntime) {
        if (copy_to_user(param->pMaxRuntime, &rthCall->mMaxRuntime,
                     sizeof(rthCall->mMaxRuntime))) {
            ERR_MSG("%s: copy_to_user failed (maxRuntime)\n", __func__);
            goto out;
        }
    }

    err = rthCall->mHead.mReturn & 0xFFFFFFFF;

out:
    RTHCALL_FINI(rthCall);
    return err;
}

/**
 * Set boot watchdog timeout (together with next runtime to be run)
 */
static int lOsWdBootTimeoutSet(const unsigned long arg)
{
    tOsWdBootTimeoutSet *param = (tOsWdBootTimeoutSet *)arg;
    tRthCall_wdBootTimeoutSet *rthCall;
    int err = eErrInternal;

    RTHCALL_PREPARE(rthCall, eRthCtrl_osWdBootTimeoutSet);

    if (strncpy_from_user(rthCall->mOsName, param->pOsName, MAX_OS_NAME_SIZE) < 0) {
        err = eErrCopyToKern;
        goto out;
    }

    rthCall->mRuntime = param->runtime;
    rthCall->mTimeout = param->timeout;
    rthCall->mNextRuntime = param->nextRuntime;

    RTHCALL_DO(rthCall);
    err = rthCall->mHead.mReturn & 0xFFFFFFFF;

out:
    RTHCALL_FINI(rthCall);
    return err;
}


/**
 * \brief Main dispatch function for OS control interface
 */
int
osCtrl(const unsigned cmd, const unsigned long arg, bool *processed)
{
    *processed = true;
    switch (cmd) {
    case eRthIoctl_sysShutdown:
        return lRthSysCtrlShutdown();

    case eRthIoctl_sysReboot:
        return lRthSysCtrlReboot();

    case eRthIoctl_osMaxIdGet:
        return lOsMaxIdGet(arg);

    case eRthIoctl_osNameGet:
        return lOsNameGet(arg);

    case eRthIoctl_osIdGet:
        return lOsIdGet(arg);

    case eRthIoctl_osStateGet:
        return lOsStateGet(arg);

    case eRthIoctl_osShutDown:
        return lOsShutDown(arg);

    case eRthIoctl_osHalt:
        return lOsHalt(arg);

    case eRthIoctl_osBoot:
        return lOsBoot(arg);

    case eRthIoctl_osReboot:
        return lOsReboot(arg);

    case eRthIoctl_osReset:
        return lOsReset(arg);

    case eRthIoctl_osBootlineSet:
        return lOsBootlineSet(arg);

    case eRthIoctl_osLoadImage:
        return lOsLoadImage(arg);

    case eRthIoctl_osWdCountGet:
        return lOsWdCountGet(arg);

    case eRthIoctl_osCtrlCommandGet:
        return lOsCtrlCommandGet(arg);

    case eRthIoctl_osCtrlStateSet:
        return lOsCtrlStateSet(arg);

    case eRthIoctl_osBootlineGet:
        return lOsBootlineGet(arg);

    case eRthIoctl_osRuntimeGet:
        return lOsRuntimeGet(arg);

    case eRthIoctl_osWdBootTimeoutSet:
        return lOsWdBootTimeoutSet(arg);

    case eRthIoctl_osWdKick:
        rthOsWatchdogKick();
        return 0;

    default:
        *processed = false;
    }

    return -1;
}
