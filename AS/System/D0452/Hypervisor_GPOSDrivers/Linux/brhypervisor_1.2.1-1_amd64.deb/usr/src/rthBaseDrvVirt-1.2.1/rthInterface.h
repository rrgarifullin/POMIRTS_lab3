/**
 * \file    rthInterface.h
 *
 * \brief   RTH control module method number definitions
 *
 *  See RTH_Porting_Guide for detailed documentation
 *
 * \copyright
 * \n       All Rights Reserved
 * \n       Copyright (c) 2008 - 2016
 * \n       Real-Time Systems GmbH
 * \n       Ravensburg, Germany
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * This software is provided by the author and contributors ``as is'' and any
 * express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are disclaimed.
 * In no event shall the author or contributors be liable for any direct, indirect,
 * incidental, special, exemplary, or consequential damages (including, but not
 * limited to, procurement of substitute goods or services; loss of use, data, or
 * profits; or business interruption) however caused and on any theory of liability,
 * whether in contract, strict liability, or tort (including negligence or otherwise)
 * arising in any way out of the use of this software, even if advised of the
 * possibility of such damage.
 *
 * \par Modification History:
 *
 * \li  01n, 2014-03-18, M.Schunda - added eRthCtrl_sysShutdown and eRthCtrl_sysReboot
 * \li  01m, 2012-04-18, S.Fausser - added eRthCtrl_hpet* definitions
 * \li  01l, 2011-12-20, S.Fausser - added eRthCtrl_osCtrlWdCount* definitions
 * \li  01k, 2009-11-12, T.Kuehn - added eRthCtrl_msiBaseIndexSet
 * \li  01j, 2009-10-23, C.Gmeiner - added eRthCtrl_tscFreqGetKHz
 * \li  01i, 2009-09-30, T.Kuehn - added eRthCtrl_msiIndexGet, eRthCtrl_msiVectorSet, and
 *                                 eRthCtrl_msiMaskSet
 * \li  01i, 2009-09-22, S.Fausser - added MSI and OS control typedefs
 * \li  01h, 2009-05-20, S.Fausser - changed typedef eRthCtrl_vnetIntMask to eRthCtrl_vnetIntDisable
 *                                   and eRthCtrl_vnetIntEnable to eRthCtrl_vnetIntUnmask
 * \li  01g, 2009-04-29, T.Kuehn - added Interprocessor Interrupt (IPI) for Virtual Network and
 *                                 Message Signaled Interrupt (MSI) related enumerators
 * \li  01f, 2008-12-17, T.Kuehn - added I/O APIC and Local APIC related enumerators
 * \li  01e, 2008-12-08, T.Kuehn - added eRthCtrl_ioAccessModeGet
 * \li  01d, 2008-12-04, T.Kuehn - added eRthCtrl_lockCmpXchg and Shared Memory related enumerators
 * \li  01c, 2008-11-06, T.Kuehn - added Virtual Network related enumerators
 * \li  01b, 2008-11-04, T.Kuehn - added eRthCtrl_smpSipiPageGet
 * \li  01a, 2008-09-02, T.Kuehn - created
 *
 */

#ifndef RTHINTERFACE_H
#define RTHINTERFACE_H

/***************************************************************************************************
 *                                            INCLUDES
 */

/***************************************************************************************************
 *                                            DEFINES
 */

/***************************************************************************************************
 *                                           DATA TYPES
 */

typedef enum eRthCtrl
{
    eRthCtrl_lastErrorGet           = 0,
    eRthCtrl_revisionGet            = 1,
    eRthCtrl_lockCmpXchg            = 3,
    eRthCtrl_versionRthGet          = 10,
    eRthCtrl_regGet                 = 100,
    eRthCtrl_regVirtBaseSet         = 101,
    eRthCtrl_osImageBaseGet         = 200,
    eRthCtrl_osMemSizeGet           = 201,
    eRthCtrl_osBootedSignal         = 202,
    eRthCtrl_osReboot               = 203,
    eRthCtrl_tscFreqGetKHz          = 300,
    eRthCtrl_sysShutdown            = 302,
    eRthCtrl_sysReboot              = 303,
    eRthCtrl_ioIn8                  = 400,
    eRthCtrl_ioIn16                 = 401,
    eRthCtrl_ioIn32                 = 402,
    eRthCtrl_ioOut8                 = 403,
    eRthCtrl_ioOut16                = 404,
    eRthCtrl_ioOut32                = 405,
    eRthCtrl_ioAccessModeGet        = 406,
    eRthCtrl_pciConfRead8           = 500,
    eRthCtrl_pciConfRead16          = 501,
    eRthCtrl_pciConfRead32          = 502,
    eRthCtrl_pciConfWrite8          = 503,
    eRthCtrl_pciConfWrite16         = 504,
    eRthCtrl_pciConfWrite32         = 505,
    eRthCtrl_pciEnumModeSet         = 506,
    eRthCtrl_vnetGet                = 600,
    eRthCtrl_vnetVirtBaseSet        = 601,
    eRthCtrl_vnetInstanceInit       = 602,
    eRthCtrl_vnetInstanceDeinit     = 603,
    eRthCtrl_vnetDevFlagsGet        = 604,
    eRthCtrl_vnetDevFlagsSet        = 605,
    eRthCtrl_vnetMacAddrGet         = 606,
    eRthCtrl_vnetMacAddrSet         = 607,
    eRthCtrl_vnetNumInstancesGet    = 608,
    eRthCtrl_vnetNumInstancesMaxGet = 609,
    eRthCtrl_vnetRxElemGet          = 610,
    eRthCtrl_vnetRxElemMaxGet       = 611,
    eRthCtrl_vnetPacketSizeMaxGet   = 612,
    eRthCtrl_vnetPacketSend         = 613,
    eRthCtrl_vnetPacketReceive      = 614,
    eRthCtrl_vnetNumIpConfigGet     = 615,
    eRthCtrl_vnetIpConfigGet        = 616,
    eRthCtrl_vnetVectorSet          = 617,
    eRthCtrl_vnetVectorGet          = 618,
    eRthCtrl_vnetIntDisable         = 619,
    eRthCtrl_vnetIntEnable          = 620,
    eRthCtrl_vnetIpiAckIrq          = 621,
    eRthCtrl_ioApicRead             = 700,
    eRthCtrl_ioApicWrite            = 701,
    eRthCtrl_ioApicListGet          = 702,
    eRthCtrl_ioApicVirtBaseSet      = 703,
    eRthCtrl_ioApicVirtBaseGet      = 704,
    eRthCtrl_ioApicIrqVectorSet     = 705,
    eRthCtrl_ioApicIrqVectorGet     = 706,
    eRthCtrl_ioApicIrqMaskSet       = 707,
    eRthCtrl_ioApicIrqMaskGet       = 708,
    eRthCtrl_smpCoresGet            = 800,
    eRthCtrl_smpSipiPageGet         = 801,
    eRthCtrl_timerBaseGetKHz        = 1000,
    eRthCtrl_timerFreqSet           = 1001,
    eRthCtrl_timerFreqGet           = 1002,
    eRthCtrl_timerVectorSet         = 1003,
    eRthCtrl_timerVectorGet         = 1004,
    eRthCtrl_timerMaskSet           = 1005,
    eRthCtrl_timerMaskGet           = 1006,
    eRthCtrl_timerCurCountGet       = 1007,
    eRthCtrl_loApicAddrGet          = 1100,
    eRthCtrl_loApicIdGet            = 1101,
    eRthCtrl_loApicVirtBaseSet      = 1102,
    eRthCtrl_loApicVirtBaseGet      = 1103,
    eRthCtrl_loApicIsrGet           = 1104,
    eRthCtrl_loApicEoi              = 1105,
    eRthCtrl_loApicStateGet         = 1106,
    eRthCtrl_loApicStateSet         = 1107,
    eRthCtrl_shmNumPartGet          = 1200,
    eRthCtrl_shmPartGetByIndex      = 1201,
    eRthCtrl_shmPartGetByName       = 1202,
    eRthCtrl_shmLockAcquire         = 1203,
    eRthCtrl_shmLockRelease         = 1204,
    eRthCtrl_shmCleanup             = 1205,
    eRthCtrl_shmTracePartGet        = 1206,
    eRthCtrl_shmFrameBufPartGet     = 1207,
    eRthCtrl_msiIsCapable           = 1300,
    eRthCtrl_msiIndexGet            = 1304,
    eRthCtrl_msiVectorSet           = 1305,
    eRthCtrl_msiMaskSet             = 1306,
    eRthCtrl_msiBaseIndexSet        = 1307,
    eRthCtrl_msiSetDestination      = 1320,
    eRthCtrl_msiGetDestination      = 1321,
    eRthCtrl_osCtrlMaxIdGet         = 1400,
    eRthCtrl_osCtrlNameGet          = 1401,
    eRthCtrl_osCtrlStateGet         = 1402,
    eRthCtrl_osCtrlShutDown         = 1403,
    eRthCtrl_osCtrlHalt             = 1404,
    eRthCtrl_osCtrlBoot             = 1405,
    eRthCtrl_osCtrlReboot           = 1406,
    eRthCtrl_osCtrlReset            = 1407,
    eRthCtrl_osBootlineSet          = 1408,
    eRthCtrl_osLoadImage            = 1409,
    eRthCtrl_osCtrlRebootAck        = 1410,
    eRthCtrl_osCtrlIdGet            = 1411,
    eRthCtrl_osCtrlImgShmNameGet    = 1412,
    eRthCtrl_osCtrlCommandGet       = 1413,
    eRthCtrl_osCtrlStateSet         = 1414,
    eRthCtrl_osCtrlWdCountInc       = 1415,
    eRthCtrl_osCtrlWdCountGet       = 1416,
    eRthCtrl_osBootlineGet          = 1417,
    eRthCtrl_osRuntimeGet           = 1418,
    eRthCtrl_osWdBootTimeoutSet     = 1419,
    eRthCtrl_hpetAddrGet            = 1500,
    eRthCtrl_hpetVirtBaseSet        = 1501,
    eRthCtrl_hpetRead               = 1502,
    eRthCtrl_hpetWrite              = 1503,
    eRthCtrl_timeSyncGetMaster       = 1700,
    eRthCtrl_timeSyncSetMaster       = 1701,
    eRthCtrl_timeSyncGetSyncInterval = 1702,
    eRthCtrl_timeSyncSetSyncInterval = 1703,
    eRthCtrl_timeSyncGetAutoStart    = 1704,
    eRthCtrl_timeSyncGetTime         = 1705,
    eRthCtrl_timeSyncSetTime         = 1706,
    eRthCtrl_eventCreate            = 1800,
    eRthCtrl_eventDestroy           = 1801,
    eRthCtrl_eventStateSet          = 1802,
    eRthCtrl_eventStateGet          = 1803,
    eRthCtrl_eventSyncObjectGet     = 1804,
    eRthCtrl_eventSyncObjectSet     = 1805,
    eRthCtrl_eventPending           = 1806,
    eRthCtrl_eventSetIpiVector      = 1807,
    eRthCtrl_eventsReset            = 1808,
    eRthCtrl_eventNameGet           = 1809
} tRthCtrl;

typedef struct
{
    char *pName;
    uint32_t runtime;
    uint32_t imageNumber;
} __attribute__((packed)) tOsId;

/**
 * \brief Type definition for version information
 */
typedef struct {
    uint32_t mRthVersionInfoSize; /**< Size of tVersionInfo     */
    uint32_t mMajor;              /**< Major version number     */
    uint32_t mMinor;              /**< Minor version number     */
    uint32_t mSubMinor;           /**< Sub-minor version number */
    uint32_t mRevision;           /**< Revision number          */
    uint32_t mReleased;           /**< 1: ready for production  */
} tVersionInfo;

/***************************************************************************************************
 *                                     FUNCTION DECLARATIONS
 */

#endif /* RTHINTERFACE_H */
