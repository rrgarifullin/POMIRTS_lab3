/**
 * \file    rthIoctlDef.h
 *
 * \brief   Definitions of data structures passed between the RTH base driver and user space.
 *
 * This file can (and will) be included by both the kernel driver and libRth.
 *
 * \copyright (c) 2007-2017 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  02a, 2017-11-09, Y.Zaporozhets - coalesced all ioctl structure definitions into one file
 * \li  01f, 2017-08-21, Y.Zaporozhets - changed MAX_OS_BOOTLINE_SIZE from 2048 to 1536
 * \li  01e, 2013-08-06, S.Fausser - added tTimeSyncSetTimezone
 * \li  01d, 2012-05-14, S.Fausser - added timeSync interface typedefs
 * \li  01c, 2012-05-03, S.Fausser - added offset to tShmMmap
 * \li  01b, 2009-11-04, S.Fausser - added tShmCleanup
 * \li  01a, 2009-07-14, S.Fausser - initial version
 */

#ifndef _RTH_IOCTL_DEF_H
#define _RTH_IOCTL_DEF_H

/***************************************************************************************************
 *                                            INCLUDES
 */

#ifndef __KERNEL__
#include <stdbool.h>
#endif

/***************************************************************************************************
 *                                            DEFINES
 */

/*
 * Limits for maximal name lengths
 */

/* Maximum length of OS name */
#define MAX_OS_NAME_SIZE        256
/* Maximum length of OS boot line */
#define MAX_OS_BOOTLINE_SIZE    1536
/* Maximum length of shared partition name */
#define MAX_SHM_PART_NAME_SIZE  256
/* Maximum length of event name */
#define MAX_EVENT_NAME_SIZE     256

/***************************************************************************************************
 *                                           DATA TYPES
 */

/**
 * parameter package of shmSizeGet function
 */
typedef struct {
    const char *pName;
    unsigned long shmNameSize;
    unsigned long size;
} tShmSizeGet;

/**
 * parameter package of shmOpen function
 */
typedef struct {
    const char *pShmName;
    unsigned long shmNameSize;
    unsigned long offset;
    unsigned long *pSize;

    int shmKey;        /**< negative values are errors, otherwise a validate key */
} tShmOpen;

/**
 * parameter package of shmClose function
 */
typedef struct {
    int shmKey;
    int retVal;
} tShmClose;


/**
 * parameter package of shmWrite function
 */
typedef struct {
    int shmKey;
    unsigned long shmOffset;
    const void *pCopyFrom;
    unsigned long size;

    unsigned long bytesWritten;
} tShmWrite;

/**
 * parameter package of shmRead function
 */
typedef struct {
    int shmKey;
    unsigned long shmOffset;
    void *pCopyTo;
    unsigned long size;

    unsigned long bytesRead;
} tShmRead;

/**
 * parameter package of shmAddrGet function
 */
typedef struct {
    int partNr;
    unsigned long offset;
} tShmMmap;

/**
 * parameter package of shmLockAcquire function
 */
typedef struct {
    int shmKey;
    unsigned long timeout;

    int retVal;
} tShmLockAcquire;

/**
 * parameter package of shmLockRelease function
 */
typedef struct {
    int shmKey;
    int retVal;
} tShmLockRelease;

/**
 * parameter package of shmFindPartition function
 */
typedef struct {
    const char *pPartName;
    int partNumber;
} tShmFindPart;

/**
 * parameter package of shmTracePartitionNameGet function
 */
typedef struct {
    const char *pOsName;        /**< [in]  Name of OS with Trace Partition (NULL is the calling OS)  */
    char *pShmTracePartName;    /**< [out] Name of the Trace Partition for this OS (NULL is invalid) */
    int  shmNameSize;           /**< [out] Size of the buffer to put the name */
} tShmTraceGet;

/**
 * parameter package of shmCleanup function
 */
typedef struct {
    const char *pShmName;
    unsigned long shmNameSize;
} tShmCleanup;

/*** OS Control IOCTL interface structures ************************************/

/**
 * parameter package of rthOsNameGet function
 */
typedef struct {
    unsigned osId;
    const char *pBuffer;
    unsigned bufferSize;
} tOsNameGet;

/**
 * parameter package of rthOsIdGet function
 */
typedef struct {
    unsigned osId;
    const char *pOsName;
} tOsIdGet;

/**
 * parameter package of rthOsStateGet function
 */
typedef struct {
    const char *pOsName;
    unsigned long osState;
} tOsStateGet;

/**
 * parameter package of rthOsShutDown function
 */
typedef struct {
    const char *pOsName;
} tOsShutDown;

/**
 * parameter package of rthOsHalt function
 */
typedef struct {
    const char *pOsName;
} tOsHalt;

/**
 * parameter package of rthOsBoot function
 */
typedef struct {
    const char *pOsName;
    unsigned long runtime;
} tOsBoot;

/**
 * parameter package of rthOsReboot function
 */
typedef struct {
    const char *pOsName;
    unsigned long runtime;
} tOsReboot;

/**
 * parameter package of rthOsReset function
 */
typedef struct {
    const char *pOsName;
    unsigned long runtime;
} tOsReset;

/**
 * parameter package of rthOsBootlineSet function
 */
typedef struct {
    const char *pOsName;
    unsigned long runtime;
    const char *pBootline;
} tOsBootlineSet;

/**
 * parameter package of rthOsLoadImage function
 */
typedef struct {
    const char *pOsName;
    unsigned long runtime;
    unsigned long imageNumber;
    const char *pImage;
    unsigned long imageSize;
} tOsLoadImage;

/**
 * parameter package of rthOsWdCountGet function
 */
typedef struct {
    const char *pOsName;
    unsigned long long wdCount;
} tOsWdCountGet;

/**
 * parameter package of osCtrlCommandGet (OS Ctrl Daemon) function
 */
typedef struct {
    unsigned long osCommand;
} tOsCtrlCommandGet;

/**
 * parameter package of osCtrlStateSet (OS Ctrl Daemon) function
 */
typedef struct {
    unsigned long state;
} tOsCtrlStateSet;

/**
 * Parameter package: tOsRuntimeGet
 */
typedef struct {
    const char *pOsName;
    unsigned *pActiveRuntime;
    unsigned *pMaxRuntime;
} tOsRuntimeGet;

/**
 * Parameter package: tOsBootlineGet
 */
typedef struct {
    const char  *pOsName;
    unsigned    runtime;
    char        *pBootline;
    unsigned    bootlineBufSize;
} tOsBootlineGet;

/**
 * Parameter package: of tOsWdBootTimeoutSet
 */
typedef struct {
    const char *pOsName;
    unsigned   runtime;
    unsigned   nextRuntime;
    unsigned   timeout;
} tOsWdBootTimeoutSet;


/*** Event subsystem IOCTL interface structures *******************************/

/**
 * parameter package of rthEventCreate/rthEventOpen function
 */
typedef struct {
    const char *pEventName;             /**< [in] Event name */
    unsigned long lenName;              /**< [in] Length of event name */
    unsigned long mode;                 /**< [in] CREATE_OR_OPEN or OPEN_OR_FAIL */
    unsigned long initialState;         /**< [in] 0 or 1 */
    int efd;                            /**< [in] eventfd file descriptor */
    tEventKey eventKey;                 /**< [out] key for the event */
    bool eventFdExists;                 /**< [out] TRUE if eventfd already exists for this process */
} tEventCreate;

/**
 * parameter package of rthEventClose function
 */
typedef struct {
    tEventKey eventKey;                 /**< [in]  Event name */
    int efd;                            /**< [out] eventfd descriptor for this key */
} tEventClose;

/**
 * parameter package of EventStateSet function
 */
typedef struct {
    tEventKey eventKey;
    unsigned long eventState;
} tEventStateSet;

/**
 * parameter package of EventStateGet function
 */
typedef struct {
    tEventKey eventKey;                 /**< [in]  Event key */
    int efd;                            /**< [out] Event file descriptor */
} tEventStateGet;

#endif                          /* _RTH_IOCTL_DEF_H */
