/**
 * \file    rthBaseDrv.c
 *
 * \brief   Implementation of rthBaseDrv
 *
 * \copyright (c) 2012-2014 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  02b, 2017-09-25, Y.Zaporozhets - removed support of kernels older than 2.6.32
 * \li  02a, 2017-08-25, Y.Zaporozhets - correct implementation using character device class.
 *                                       Now the device node is created automatically by udev/systemd.
 * \li  01f, 2017-08-23, Y.Zaporozhets - do not start watchdog thread if "nowdstart"
 *                                       parameter is passed to the module
 * \li  01e, 2014-03-18, M.Schunda - add case eRthIoctl_sysShutdown and eRthIoctl_sysReboot
 * \li  01d, 2013-07-25, S.Fausser - fixed bug #1089: added case eRthIoctl_osBootlineSet
 * \li  01c, 2013-01-15, S.Fausser - added support for Linux Kernel 3.7
 * \li  01b, 2012-05-21, S.Fausser - 1. added support for Linux Kernel 2.6.39, 3.0, 3.1, 3.2 and 3.3
 *                                   2. added timeSync support
 * \li  01a, 2012-02-15, F.Harmuth - based on S.Fausser/T.Kuehn shmDriver,
 *                                   rewritten for new RTH PCI-Device
 */


/***************************************************************************************************
 *                                            INCLUDES
 */

#include "common.h"

#include <linux/device.h>
#include <linux/cdev.h>
#include <linux/moduleparam.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36) && LINUX_VERSION_CODE < KERNEL_VERSION(2,6,39)
#  include <linux/smp_lock.h>
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,39)
#  include <linux/mutex.h>
#endif

/***************************************************************************************************
 *                                            DEFINES
 */

#define PCI_VENDORID_RTH_BASEDRV    0xFFFC
#define PCI_DEVICEID_RTH_BASEDRV    0x5254

#define PCI_IO_SIZE 0x40

MODULE_AUTHOR("Real-Time Systems GmbH");
MODULE_DESCRIPTION("RTH base driver");
MODULE_LICENSE("GPL");

/***************************************************************************************************
 *                                           DATA TYPES
 */

/***************************************************************************************************
 *                                      FORWARD DECLARATIONS
 */
static int baseDrv_open(struct inode *pDev, struct file *pInstance);
static int baseDrv_close(struct inode *pDev, struct file *pInstance);
static int baseDrv_mmap(struct file *instance, struct vm_area_struct *vma);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
static int baseDrv_ioctl(struct inode *pDev, struct file *pInstance, unsigned int cmd, unsigned long arg);
#else
static long baseDrv_ioctl(struct file *pInstance, unsigned int cmd, unsigned long arg);
#endif
static int baseDrv_probe(struct pci_dev *pDev, const struct pci_device_id *id);
static void __exit baseDrv_remove(struct pci_dev *pDev);

int startTimeSync (uint32_t forceStart);
void stopTimeSync (void);

/***************************************************************************************************
 *                                        LOCAL VARIABLES
 */
static dev_t        rth_dev;            /* Device numbers (major,minor) */
static struct class *rthdev_class;      /* Device class */
static struct cdev  rth_cdev;           /* Character device */

static struct pci_device_id baseDrv_ids[] = {
    {PCI_DEVICE(PCI_VENDORID_RTH_BASEDRV, PCI_DEVICEID_RTH_BASEDRV)},
    {}
};

static struct pci_driver pci_driver = {
    .name = "pci_baseDrv",
    .id_table = baseDrv_ids,
    .probe = baseDrv_probe,
    .remove = baseDrv_remove,
};

DEFINE_MUTEX(lMutex);

MODULE_DEVICE_TABLE(pci, baseDrv_ids);

static struct file_operations fops = {
    .release = baseDrv_close,
    .open = baseDrv_open,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
    .ioctl = baseDrv_ioctl,
#else
    .unlocked_ioctl = baseDrv_ioctl,
#endif
    .mmap = baseDrv_mmap,
    .owner = THIS_MODULE
};

static struct vm_operations_struct baseDrv_vma_ops = {
};

long baseDrv_ioaddr;

/* Module parameters */
static bool nowdstart;

module_param(nowdstart, bool, 0);
MODULE_PARM_DESC(nowdstart, "Disable starting of watchdog increment thread");

/***************************************************************************************************
 *                                         IMPLEMENTATION
 */
static int
baseDrv_open(struct inode *pDev, struct file *pInstance)
{
    return 0;
}

static int
baseDrv_close(struct inode *pDev, struct file *pInstance)
{
    return 0;
}

/**
 * \brief Mmap method.
 */
static int baseDrv_mmap(struct file *filp, struct vm_area_struct *vma)
{
    vma->vm_ops = &baseDrv_vma_ops;
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,7,0)
    vma->vm_flags |= VM_RESERVED;
#else
    vma->vm_flags |= (VM_DONTEXPAND | VM_DONTDUMP);
#endif

    if (shmMapPartition(vma)) {
        ERR_MSG("%s: remap_page_range failed.\n", __func__);
        return -EAGAIN;
    }

    return 0;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
static int baseDrv_ioctl(struct inode *pDev, struct file *pInstance, unsigned int cmd, unsigned long arg)
#else
static long baseDrv_ioctl(struct file *pInstance, unsigned int cmd, unsigned long arg)
#endif
{
    int err = 0;
    bool processed;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36) && LINUX_VERSION_CODE < KERNEL_VERSION(2,6,39)
    lock_kernel();
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,39)
    mutex_lock(&lMutex);
#endif

    err = shmIoctl(cmd, arg, &processed);
    if (processed)
        goto out;
    err = osCtrl(cmd, arg, &processed);
    if (processed)
        goto out;
    err = rthIoctlEvent(cmd, arg, &processed);
    if (processed)
        goto out;
    err = timeSync(cmd, arg, &processed);
    if (processed)
        goto out;
    err = rthIoctlMisc(cmd, arg, &processed);
    if (processed)
        goto out;

    ERR_MSG("unknown IOCTL 0x%x\n", cmd);
    err = -1;

out:
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36) && LINUX_VERSION_CODE < KERNEL_VERSION(2,6,39)
    unlock_kernel();
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,39)
    mutex_unlock(&lMutex);
#endif

    return err;
}

/* Function to set custom permissions on our device node */
static int rthdev_uevent(struct device *dev, struct kobj_uevent_env *env)
{
    /* TODO: ensure at least minimal security on the device node (udev rules?) */
    //add_uevent_var(env, "GROUP=%s", "adm");
    add_uevent_var(env, "DEVMODE=%#o", 0666);
    return 0;
}

static int
baseDrv_probe(struct pci_dev *pDev, const struct pci_device_id *id)
{
    int err;

    pr_info(DRIVER_NAME ": initializing (disable kernel watchdog thread: %s)\n",
                nowdstart ? "YES" : "NO");

    err = pci_enable_device(pDev);
    if(err) {
        ERR_MSG("%s: cannot enable PCI device\n", __func__);
        goto err_pci_enable;
    }

    pr_info(DRIVER_NAME ": pci bus (%i), dev (%i), func (%i)\n",
             pDev->bus->number, PCI_SLOT(pDev->devfn), PCI_FUNC(pDev->devfn));

    baseDrv_ioaddr = pci_resource_start(pDev, 0);

    if(!baseDrv_ioaddr || ((pci_resource_flags(pDev, 0) & IORESOURCE_IO) == 0))
    {
        ERR_MSG("%s: no I/O resource at PCI BAR #0\n", __func__);
        err = -ENODEV;
        goto err_pci_res;
    }

    if(request_region(baseDrv_ioaddr, PCI_IO_SIZE, DRV_MODULE_NAME) == NULL)
    {
        ERR_MSG("%s: I/O resource 0x%x @ 0x%lx busy\n", __func__,
                PCI_IO_SIZE, baseDrv_ioaddr);
        err = -EBUSY;
        goto err_pci_res;
    }

    /* Set upper 32 bit value of 64 bit physical address to zero (clear it) */
    outl(0x0, baseDrv_ioaddr + eRthDevIoOffset_CallPhyAddrHigh);

    /* Allocate major number for character device */
    err = alloc_chrdev_region(&rth_dev, 0, 1, DRIVER_NAME);
    if (err < 0) {
        ERR_MSG("could not allocate major number for device (%d)\n", err);
        goto err_alloc_chrdev;
    }

    /* Create the device class */
    rthdev_class = class_create(THIS_MODULE, "rth");
    if (rthdev_class == NULL) {
        ERR_MSG("could not create device class 'rth'\n");
        goto err_class;
    }
    rthdev_class->dev_uevent = rthdev_uevent;

    /* Create the device */
    if (device_create(rthdev_class, NULL, rth_dev, NULL, DRIVER_NAME) == NULL) {
        ERR_MSG("could not create device\n");
        goto err_dev;
    }

    /* Add character device */
    cdev_init(&rth_cdev, &fops);
    if (cdev_add(&rth_cdev, rth_dev, 1) == -1) {
        ERR_MSG("could not add character device\n");
        goto err_cdevadd;
    }

    err = shmInitialize();
    if(err) {
        ERR_MSG("%s: shm init failed (%d)\n", __func__, err);
        goto err_shm_init;
    }

    if (!nowdstart) {
        if(startWdIncTask()) {
            err = -1;
            goto err_wd;
        }
    }

    startTimeSync(0);

    initEventSystem();

    err = request_irq(pDev->irq, event_isr, IRQF_SHARED, DRV_MODULE_NAME, pDev);
    if (err) {
        ERR_MSG("%s: request_irq failed (%d)\n", __func__, err);
        goto err_irq;
    }

    /* enable Event IRQs */
    outl(1<<0, baseDrv_ioaddr + eRthDevIoOffset_IntEnable);

    /* Indicate that the OS has booted */
    rthCall_osCtrlStateSet(1);

    pr_info(DRIVER_NAME ": driver version %s, device major number %d\n", DRIVER_VERSION, MAJOR(rth_dev));

    return 0;

err_irq:
    if (!nowdstart)
        stopWdIncTask();

err_wd:
    shmShutdown();

err_shm_init:
    cdev_del(&rth_cdev);
err_cdevadd:
    device_destroy(rthdev_class, rth_dev);
err_dev:
    class_destroy(rthdev_class);
err_class:
    unregister_chrdev_region(rth_dev, 1);

err_alloc_chrdev:
    release_region(baseDrv_ioaddr, PCI_IO_SIZE);

err_pci_res:
    pci_disable_device(pDev);

err_pci_enable:
    return err;
}

static void __exit
baseDrv_remove(struct pci_dev *pDev)
{
    DBG_MSG("freeing irq\n");
    free_irq(pDev->irq, pDev);

    DBG_MSG("stopping timesync task\n");
    stopTimeSync();

    if (!nowdstart) {
        DBG_MSG("stopping watchdog task\n");
        stopWdIncTask();
    }

    DBG_MSG("unloading shm components\n");
    shmShutdown();

    DBG_MSG("cleanup event system components\n");
    cleanupEventSystem();

    /* Unregister device, class and character device */
    cdev_del(&rth_cdev);
    device_destroy(rthdev_class, rth_dev);
    class_destroy(rthdev_class);
    unregister_chrdev_region(rth_dev, 1);

    release_region(baseDrv_ioaddr, PCI_IO_SIZE);

    pci_disable_device(pDev);
}

/*
 * Initialization
 */
static int __init baseDrv_init(void)
{
    int res = pci_register_driver(&pci_driver);
    if (res == 0)
        pr_info(DRIVER_NAME ": loaded\n");
    else
        ERR_MSG("error %d\n", res);
    return res;
}

/*
 * Shutdown
 */
static void __exit baseDrv_exit(void)
{
    pci_unregister_driver(&pci_driver);

    pr_info(DRIVER_NAME ": unloaded\n");
}

module_init(baseDrv_init);
module_exit(baseDrv_exit);
