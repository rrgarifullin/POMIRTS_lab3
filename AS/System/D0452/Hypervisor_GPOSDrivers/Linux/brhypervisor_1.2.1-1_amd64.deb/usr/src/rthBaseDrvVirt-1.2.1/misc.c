/**
 * \file    misc.c
 *
 * \brief   Miscellaneous routines
 *
 * \copyright (c) 2016 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  01a, 2016-11-22, Y.Zaporozhets - first version
 */

/***************************************************************************************************
 *                                            DEFINES
 */

#include "common.h"

/***************************************************************************************************
 *                                        LOCAL VARIABLES
 */

extern long baseDrv_ioaddr;

/***************************************************************************************************
 *                                         IMPLEMENTATION
 */

/**
 * \brief
 */
int doRthCall_64(const tRthCtrl type, uint64_t * n)
{
    tRthCall * rthCall;

    if(n == NULL)
        return -1;

    if(sizeof(tRthCall) > PAGE_SIZE)
        return -1;

    rthCall = (tRthCall *) __get_free_pages(GFP_DMA32, 0);
    if(!rthCall)
        return -1;

    memset(rthCall, 0, sizeof(*rthCall));

    rthCall->mCallSize = sizeof(tRthCall);
    rthCall->mCallNr = type;

    RTHCALL_DO(rthCall);

    *n = rthCall->mReturn;

    RTHCALL_FINI(rthCall);

    return 0;
}

/**
 * \brief
 */
int doRthCall_32(const tRthCtrl type, uint32_t * n)
{
    uint64_t tmp = 0;

    if(doRthCall_64(type, &tmp))
        return -1;

    *n = tmp & 0xFFFFFFFF;

    return 0;
}

/**
 * \brief
 */
int doRthCall_Param1(const tRthCtrl type, uint32_t *param)
{
    int ret;
    tRthCall1Param *rthCall;

    if (param == NULL)
        return -1;

    RTHCALL_PREPARE(rthCall, type);
    rthCall->mParam0 = *param;

    RTHCALL_DO(rthCall);

    ret = rthCall->mHead.mReturn & 0xFFFFFFFF;
    *param = rthCall->mParam0;

    RTHCALL_FINI(rthCall);

    return ret;
}

/**
 * \brief Get hypervisor version information.
 * \param[out] userAddr user address of tVersionInfo structure to copy version info
 * \return 0 in case of success, a negative value otherwise
 */
static int lRthVersionGet(unsigned long userAddr)
{
    tRthCall_VersionGet *rthCall;
    tVersionInfo info;
    int ret;

    RTHCALL_PREPARE(rthCall, eRthCtrl_versionRthGet);
    rthCall->mVersion.mRthVersionInfoSize = sizeof(tVersionInfo);
    RTHCALL_DO(rthCall);
    ret = rthCall->mHead.mReturn & 0xFFFFFFFF;
    info = rthCall->mVersion;
    RTHCALL_FINI(rthCall);

    if (ret < 0)
        return ret;
    if (ret > 0)
        return 0 - ret;

    if (copy_to_user((void *)userAddr, &info, sizeof(info))) {
        ERR_MSG("%s: copy_to_user failed\n", __func__);
        return -1;
    }

    return 0;
}

/*
 * \brief ioctl interface for miscellaneous routines.
 */
int rthIoctlMisc(const unsigned cmd, const unsigned long arg, bool *processed)
{
    *processed = true;
    switch (cmd) {
        case eRthIoctl_versionGet:
            return lRthVersionGet(arg);
        default:
            *processed = false;
            return -1;
    }
}
