/**
 * \file    vnet_rth_virt.h
 *
 * \brief   Header file for vnet driver (virtualized Linux)
 *
 * \copyright (c) 2006-2018 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 *
 * \par Modification History:
 *
 * \li  01e, 2018-01-22, Y.Zaporozhets - added feature_tx_status_mem field
 * \li  01d, 2018-01-05, Y.Zaporozhets - changed vnet structure; added version info
 * \li  01c, 2017-12-28, Y.Zaporozhets - introduced logging macros (*_MSG)
 * \li  01b, 2017-12-18, Y.Zaporozhets - removed support of very old kernels (older than 2.6.32)
 * \li  01a, 2006-08-24, S.Fausser - written, based on privileged Linux driver
 *
 */

/***************************************************************************************************
 *                                            INCLUDES
 */

#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/timer.h>
#include <linux/spinlock.h>
#include <linux/workqueue.h>

/***************************************************************************************************
 *                                            DEFINES
 */

/** device flag for promiscuous mode*/
#define       VNET_PROMISCUOUS_FLAG          0x01
/** device flag for multicast mode*/
#define       VNET_MULTICAST_FLAG            0x02

/*Default Debug Messages*/
#define VNET_DEF_MSG              \
       (                          \
    /*  NETIF_MSG_DRV       | */  \
    /*  NETIF_MSG_LINK      | */  \
    /*  NETIF_MSG_TX_QUEUED | */  \
        NETIF_MSG_RX_ERR    |     \
        NETIF_MSG_TX_ERR          \
       )

#undef VNET_ENTRY_MESSAGES
#undef VNET_CLEANUP_DEBUG

#define VNET_RECV_PACKETS_MAX  64
#define VNET_ALLOC_RINGS

#ifdef DEBUG
# define DBG_MSG(x...)  pr_dbg(DRIVER_NAME ": " x)
#else
# define DBG_MSG(x...)
#endif

#define ERR_MSG(x...)   pr_err("###" DRIVER_NAME ": " x)
#define INFO_MSG(x...)  pr_info(DRIVER_NAME ": " x)

/* Driver version */
#define DRIVER_VERSION  "2.0.00"

/***************************************************************************************************
 *                                            TYPE DEFINITIONS
 */

enum {
    RX_TIMER_INTERVAL = 5       /* default value in milliseconds */
};

struct vnet
{
    /* Network device Information */
    struct net_device *dev;
    struct net_device_stats net_stats;

    struct pci_dev *pdev;

    /* For faster access (than accessing the shared memory) */
    u32 package_size_max;

    spinlock_t tx_lock;
    /* indicates if receive task is already active */

    /* Bitmap variable for debugging messages */
    u32 msg_enable;

    /* Linux Kernel Timer */
    struct timer_list rx_timer;
    u16 rx_timer_interval;
    u16 rx_timer_jiffies;
    /* 1 = Timer is on, 0 = Timer is off */
    u8 rx_timer_power;
    /* true if polling mode, false if interrupt mode is enabled */
    bool polling;

    /* Linux wakeup Kernel Timer */
    struct timer_list wakeup_timer;
    u16 wakeup_timer_interval;
    u16 wakeup_timer_jiffies;

    /* interrupt level */
    int irq;

    struct semaphore sem;

    bool feature_tx_status_mem;
};

/***************************************************************************************************
 *                                            PRIVATE VARIABLES
 */

static const s32 vnet_debug = -1;       /* Use VNET_DEF_MSG for debug level */
