/**
 * \file    rthVirtPciDev.h
 *
 * \brief   RTH device interface definition
 *
 * for internal use only!
 *
 * \copyright (c) 2011-2016 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  01f, 2017-08-23, Y.Zaporozhets - added two new parameter structures (wdBootTimeoutSet and osRuntimeGet)
 * \li  01e, 2017-08-21, Y.Zaporozhets - added tRthCall_osBootlineGet structure, removed unused defines
 * \li  01d, 2017-08-21, Y.Zaporozhets - changed MAX_OS_BOOTLINE_SIZE from 2048 to 1536
 * \li  01c, 2016-11-23, Y.Zaporozhets - added tRthCall_VersionGet structure
 * \li  01b, 2013-01-24, S.Fausser - explicitly pack the tRthCall* structures
 * \li  01a, 2011-09-20, M.Schunda - created
 *
 */

#ifndef RTHVIRTPCIDEV_H
#define RTHVIRTPCIDEV_H

/***************************************************************************************************
 *                                            INCLUDES
 */

#include "rthInterface.h"
#include "timeSyncInterface.h"

/***************************************************************************************************
 *                                            DEFINES
 */


/***************************************************************************************************
 *                                           DATA TYPES
 */

/**
 * \brief Sizes of individual registers in the I/O space
 */
enum eRthDevIoSize
{
    eRthDevIoSize_Status                = sizeof(uint32_t),
    eRthDevIoSize_Command               = sizeof(uint32_t),

    eRthDevIoSize_IntStatus             = sizeof(uint32_t),
    eRthDevIoSize_IntEnable             = sizeof(uint32_t),

    eRthDevIoSize_CallTriggerPhyAddr    = sizeof(uint64_t),

    eRthDevIoSize_EventPending          = sizeof(uint32_t)
};

enum eIntMask
{
    eIntMask_Event      = 1,
};

typedef union
{
    uint32_t        mData;
    struct
    {
        unsigned    tDummy : 1;
    };
} tRthDevStatusField;

enum eRthDrvCommandFlags
{
    eRthDrvCommandFlags_TriggerInterrupt    = 0x1,
    eRthDrvCommandFlags_WatchdogInc         = 0x2,
};

typedef union
{
    uint32_t        mData;
    struct
    {
        /* These bits won't be taken over in the device register */
        unsigned    mTriggerInterrupt : 1;      /** Trigger an interrupt for the PCI device */
        unsigned    mWatchdogInc : 1;           /** Increment watchdog count; @sa eRthCtrl_osCtrlWdCountInc */
    };
} tRthDevCommandField;


/**
 * \brief Positions of registers in the I/O space
 */
enum eRthDevIoOffset
{
    eRthDevIoOffset_Status      = 0x000,                                                // ro
    eRthDevIoOffset_Command     = eRthDevIoOffset_Status    + eRthDevIoSize_Status,     // rw

    eRthDevIoOffset_IntStatus   = eRthDevIoOffset_Command   + eRthDevIoSize_Command,    // rw
    eRthDevIoOffset_IntEnable   = eRthDevIoOffset_IntStatus + eRthDevIoSize_IntStatus,  // rw

    eRthDevIoOffset_CallPhyAddr = eRthDevIoOffset_IntEnable + eRthDevIoSize_IntEnable,  // rw
    eRthDevIoOffset_CallPhyAddrLow
                                = eRthDevIoOffset_CallPhyAddr,
    eRthDevIoOffset_CallPhyAddrHigh
                                = eRthDevIoOffset_CallPhyAddrLow + sizeof(uint32_t),    // rw

    eRthDevIoOffset_EventPending
                                = eRthDevIoOffset_CallPhyAddr + eRthDevIoSize_CallTriggerPhyAddr,      // r

    eRthDevIoOffset_Max         = 0x007f,
};


/**
 * \brief RTH call head.
 */
typedef struct {
    uint32_t        mCallSize;
    uint32_t        mCallNr;
    uint64_t        mReturn;
} __attribute__ ((packed)) tRthCall;

/**
 * \brief RTH call with 1 uint32_t
 */
typedef struct {
    tRthCall        mHead;
    uint32_t        mParam0;
} __attribute__ ((packed)) tRthCall1Param;

/**
 * \brief RTH call with 3 parameter
 */
typedef struct {
    tRthCall        mHead;
    uint32_t        mParam0;
    uint32_t        mParam1;
    uint32_t        mParam2;
} __attribute__ ((packed)) tRthCall3Param;


/**
 * \brief Structure of eRthCtrl_VersionRthGet
 */
typedef struct {
    tRthCall        mHead;
    tVersionInfo    mVersion;                      /// IN / OUT
} __attribute__ ((packed)) tRthCall_VersionGet;

/**
 * \brief Structure of eRthCtrl_shmPartGetByIndex
 */
typedef struct {
    tRthCall        mHead;
    uint32_t        mShmIdx;                          /// in
    uint64_t        mShmSize;                         /// out
    char            mShmName[MAX_SHM_PART_NAME_SIZE]; /// out
} __attribute__ ((packed)) tRthCall_shmPartGetByIndex;

/**
 * \brief Structure of eRthCtrl_shmPartGetByName
 */
typedef struct {
    tRthCall        mHead;
    char            mShmName[MAX_SHM_PART_NAME_SIZE]; /// in
    uint32_t        mShmIdx;                          /// out
    uint64_t        mShmSize;                         /// out
} __attribute__ ((packed)) tRthCall_shmPartGetByName;

/**
 * \brief Structure of eRthCtrl_shmLockAcquire
 */
typedef struct {
    tRthCall        mHead;
    uint32_t        mShmIdx;
} __attribute__ ((packed)) tRthCall_shmLockAcquire;

/**
 * \brief Structure of eRthCtrl_shmLockRelease
 */
typedef struct {
    tRthCall        mHead;
    uint32_t        mShmIdx;
} __attribute__ ((packed)) tRthCall_shmLockRelease;

/**
 * \brief Structure of eRthCtrl_shmTracePartGet
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];        /// in
    char            mShmName[MAX_SHM_PART_NAME_SIZE]; /// out
} __attribute__ ((packed)) tRthCall_shmTracePartGet;

/**
 * \brief Structure of eRthCtrl_osCtrlNameGet
 */
typedef struct {
    tRthCall        mHead;
    uint32_t        mOsId;                         /// in
    char            mOsName[MAX_OS_NAME_SIZE];     /// out
} __attribute__ ((packed)) tRthCall_osCtrlNameGet;

/**
 * \brief Structure of eRthCtrl_osCtrlStateGet
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];      /// in
    uint32_t        mOsState;                       /// out
} __attribute__ ((packed)) tRthCall_osCtrlStateGet;

/**
 * \brief Structure of eRthCtrl_osCtrlIdGet
 */
typedef struct {
    tRthCall        mHead;
    uint32_t        mOsId;                          /// out
} __attribute__ ((packed)) tRthCall_osCtrlIdGet;

/**
 * \brief Structure of eRthCtrl_osCtrlShutDown
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];      /// IN
} __attribute__ ((packed)) tRthCall_osCtrlShutDown;

/**
 * \brief Structure of eRthCtrl_osCtrlHalt
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];      /// IN
} __attribute__ ((packed)) tRthCall_osCtrlHalt;

/**
 * \brief Structure of eRthCtrl_osCtrlBoot
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];      /// IN
    uint32_t        mRuntime;                       /// IN
} __attribute__ ((packed)) tRthCall_osCtrlBoot;

/**
 * \brief Structure of eRthCtrl_osCtrlReboot
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];      /// IN
    uint32_t        mRuntime;                       /// IN
} __attribute__ ((packed)) tRthCall_osCtrlReboot;

/**
 * \brief Structure of eRthCtrl_osCtrlReset
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];      /// IN
    uint32_t        mRuntime;                       /// IN
} __attribute__ ((packed)) tRthCall_osCtrlReset;

/**
 * \brief Structure of eRthCtrl_osBootlineSet
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];       /// IN
    uint32_t        mRuntime;                        /// IN
    char            mBootline[MAX_OS_BOOTLINE_SIZE]; /// IN
} __attribute__ ((packed)) tRthCall_osBootlineSet;

/**
 * \brief Structure of eRthCtrl_osBootlineGet
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];       /// IN
    uint32_t        mRuntime;                        /// IN
    char            mBootline[MAX_OS_BOOTLINE_SIZE]; /// OUT
} __attribute__ ((packed)) tRthCall_osBootlineGet;

/**
 * \brief Structure of eRthCtrl_timeSyncGetTime and eRthCtrl_timeSyncSetTime
 */
typedef struct {
    tRthCall        mHead;
    tTimeDesc       mTimeDesc;                      /// IN / OUT
} __attribute__ ((packed)) tRthCall_TimeDesc;

/**
 * \brief Structure of eRthCtrl_eventCreate
 */
typedef struct {
    tRthCall        mHead;
    char            mEventName[MAX_OS_NAME_SIZE];   /// IN
    uint32_t        mMode;                          /// IN
    uint32_t        mEventKey;                      /// OUT
} __attribute__ ((packed)) tRthCall_EventCreate;

/**
 * \brief Structure of eRthCtrl_eventStateSet and eRthCtrl_eventStateGet
 */
typedef struct {
    tRthCall        mHead;
    uint32_t        mEventKey;                      /// OUT
    uint32_t        mEventState;                    /// IN / OUT
} __attribute__ ((packed)) tRthCall_EventState;

/**
 * \brief Structure of eRthCtrl_wdCountGet
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];      /// IN
    uint64_t        mCount;                         /// OUT
} __attribute__ ((packed)) tRthCall_wdCountGet;

/**
 * \brief Structure of eRthCtrl_wdBootTimeoutSet
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];      /// IN
    uint32_t        mRuntime;                       /// IN
    uint32_t        mTimeout;                       /// IN
    uint32_t        mNextRuntime;                   /// IN
} __attribute__ ((packed)) tRthCall_wdBootTimeoutSet;

/**
 * \brief Structure of eRthCtrl_osRuntimeGet
 */
typedef struct {
    tRthCall        mHead;
    char            mOsName[MAX_OS_NAME_SIZE];      /// IN
    uint32_t        mActiveRuntime;                 /// OUT
    uint32_t        mMaxRuntime;                    /// OUT
} __attribute__ ((packed)) tRthCall_osRuntimeGet;

#endif /* RTHVIRTPCIDEV_H */
