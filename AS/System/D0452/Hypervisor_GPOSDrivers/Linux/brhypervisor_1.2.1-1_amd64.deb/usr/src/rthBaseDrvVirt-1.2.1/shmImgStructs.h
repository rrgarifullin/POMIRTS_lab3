/**
 * \file    shmImgStructs.h
 *
 * \brief   common structures and definitions used by Hypervisor and SHM API for image access
 *
 * \copyright (c) 2009-2011 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 *
 * \par Modification History:
 *
 * \li  01b, 2011-03-14, S.Fausser - added typedef tShmFile
 * \li  01a, 2009-09-08, S.Fausser - created
 *
 */

#ifndef SHMIMGSTRUCTS_H
#define SHMIMGSTRUCTS_H

/***************************************************************************************************
 *                                            INCLUDES
 */


/***************************************************************************************************
 *                                            DEFINES
 */

#define SHM_IMG_PREFIX      "Ohng2sho"
#define SHM_FILE_MAGIC      0x4D7DE294UL

/***************************************************************************************************
 *                                           DATA TYPES
 */

typedef struct sShmImage
{
    uint32_t    mImageSize;     /**< size of the image */
    uint32_t    mStructSize;    /**< size of the structure */
} tShmImage;

typedef struct sShmFile
{
    uint32_t    mMagicValue;    /**< magic value */
    uint32_t    mImageSize;     /**< size of the image */
    uint32_t    mStructSize;    /**< size of the structure */
} tShmFile;

/***************************************************************************************************
 *                                     FUNCTION DECLARATIONS
 */

#endif /* SHMIMGSTRUCTS_H */
