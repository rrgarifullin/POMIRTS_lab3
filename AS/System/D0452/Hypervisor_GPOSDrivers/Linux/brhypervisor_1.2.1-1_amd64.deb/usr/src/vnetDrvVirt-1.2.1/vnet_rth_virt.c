/**
 * \file    vnet_rth_virt.c
 *
 * \brief   RTS Virtual Network driver for Linux
 *
 * This multi instance shared memory network driver is used to communicate between multiple instances
 * of this network driver using the shared memory.
 *
 * \copyright (c) 2009-2015 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  01m, 2018-01-22, Y.Zaporozhets - added TX optimization (don't read status from PCI device,
 *                                       new hypervisors provide it directly in memory)
 * \li  01l, 2016-04-12, S.Fausser - 1. send KILL signal to RX kernel thread on module unload
 *                                   2. replaced mutex (mutex_unlock not allowed in interrupt context)
 *                                   by semaphore (up allowed in interrupt context)
 * \li  01k, 2016-03-30, S.Fausser - rewritten with RX thread
 * \li  01j, 2015-09-10, S.Fausser - added interface name parameter
 * \li  01i, 2013-07-24, S.Fausser - reworked the RX path: The interrupt handler of the RX IPI inserts a work
 *                                   in the work queue. The work then receives the packets and unmasks / re-enables
 *                                   the IPIs in case we did not receive too many RX packets.
 *                                   In case of flooding RX packets, the IPIs are kept masked and, eventually,
 *                                   a RX kernel timer will expire. This RX kernel timer will then insert
 *                                   the same work in the work queue.
 * \li  01h, 2013-01-23, S.Fausser - 1. Ensure to allocate memory for RX / TX buffer in first 4GB
 *                                   2. fixed some warnings on 64 Bit GNU/Linux
 * \li  01g, 2013-01-15, S.Fausser - fixed spelling error
 * \li  01f, 2012-10-15, T.Kuehn - fixed vnet_probe(): Use APIC IRQ from 'struct pci_dev' instead of
 *                                 PIC IRQ from config space.
 * \li  01e, 2012-05-21, S.Fausser - added support for kernel 3.0, 3.1, 3.2 and 3.3 (tested on 3.3.6)
 * \li  01c, 2009-12-07, S. Gast - added support for kernel >= 2.6.30
 * \li  01b, 2009-11-02, S. Fausser - polling mode added,
 *                                    added timer to wake up the transmit queue
 * \li  01a, 2009-08-24, Fausser - written, based on vnetDrvLinux for privileged Linux OS
 *
 */

/***************************************************************************************************
 *                                            INCLUDES
 */

#include <linux/kernel.h>
#include <linux/version.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,32)
#error Kernel version 2.6.32 or newer is required by this driver
#endif

#include <linux/module.h>
#include <linux/signal.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
#include <linux/sched/signal.h>
#endif
#include <linux/kthread.h>
#include <linux/slab.h>
#include <linux/pci.h>
#include <linux/irq.h>
#include <linux/interrupt.h>
#include <linux/ioport.h>
#include <asm/io.h>

#include <linux/ip.h>
#include <linux/ethtool.h>

/* Contains all network device driver and shared memory structures */
#include "vnet_rth_virt.h"

/***************************************************************************************************
 *                                            DEFINES
 */

#define DRV_MODULE_NAME         "vnetDrvVirt"
#define DRIVER_NAME             DRV_MODULE_NAME
#define PCI_VENDORID_RTH_VNET   0xFFFC
#define PCI_DEVICEID_RTH_VNET   0x564F

MODULE_AUTHOR ("Real-Time Systems GmbH");
MODULE_DESCRIPTION ("RTH virtual network driver");
MODULE_LICENSE ("GPL");

#define VNET_TX_TIMEOUT         (HZ)

enum {
    eVnetReg_revision = 0x40,
    eVnetReg_reset = 0x44,
    eVnetReg_init_send = 0x48,
    eVnetReg_irr = 0x4C,
    eVnetReg_rx_count = 0x50,
    eVnetReg_inc_rx = 0x54,
    eVnetReg_mac_addr_low = 0x58,
    eVnetReg_mac_addr_high = 0x5C,
    eVnetReg_device_flags = 0x60,
    eVnetReg_max_pkt_siz_tx = 0x64,
    eVnetReg_max_pkt_siz_rx = 0x68,
    eVnetReg_mask = 0x6C,
    eVnetReg_tx_buf_addr = 0x70,
    eVnetReg_tx_buf_size = 0x74,
    eVnetReg_rx_buf_addr = 0x78,
    eVnetReg_rx_buf_size = 0x7C,
    eVnetReg_feature_revision = 0x8c
};

/* Feature level (can be read from feature_revision register) */
enum {
    eFeature_tx_status_mem = 1
};

/***************************************************************************************************
 *                                  INTERFACE FUNCTION DECLARATIONS
 */

static int vnet_probe (
    struct pci_dev *dev,
    const struct pci_device_id *id);
static int vnet_start_xmit (
    struct sk_buff *skb,
    struct net_device *dev);
static void vnet_tx_timeout (
    struct net_device *dev);
static int vnet_change_mtu (
    struct net_device *dev,
    int new_mtu);
static int vnet_ioctl (
    struct net_device *dev,
    struct ifreq *ifr,
    int cmd);
static void vnet_set_rx_mode (
    struct net_device *dev);
static int vnet_set_mac_addr (
    struct net_device *dev,
    void *p);
static int vnet_open (
    struct net_device *dev);
static int vnet_close (
    struct net_device *dev);
static struct net_device_stats *vnet_get_stats (
    struct net_device *dev);
static u32 vnet_get_msglevel (
    struct net_device *dev);
static void vnet_set_msglevel (
    struct net_device *dev,
    u32 value);
static void __exit vnet_remove (
    struct pci_dev *dev);

/***************************************************************************************************
 *                                            PRIVATE VARIABLES
 */

/* Module parameters */
static int rx_timer_interval = RX_TIMER_INTERVAL;
static int wakeup_timer_interval = 1; /* milliseconds */
static int interrupt_mode = 1;
static char *interface_name = "vnet";
static struct task_struct *vnet_do_rx_thread = NULL;

module_param (rx_timer_interval, int, 0);
MODULE_PARM_DESC (rx_timer_interval, "rx timer polling interval in milliseconds (default 0)");

module_param (interrupt_mode, int, 0);
MODULE_PARM_DESC (interrupt_mode, "interrupt mode. 0 = off, any other value = on (default on)");

module_param(interface_name, charp, 0);
MODULE_PARM_DESC(interface_name, "interface name (default vnet)");

static unsigned long txAddr = 0, rxAddr = 0;

static int driverEnabled = 0;

static struct pci_device_id vnet_ids[] = {
    {PCI_DEVICE (PCI_VENDORID_RTH_VNET, PCI_DEVICEID_RTH_VNET)},
    {}
};

static struct pci_driver pci_driver = {
    .name = "pci_vnet",
    .id_table = vnet_ids,
    .probe = vnet_probe,
    .remove = vnet_remove,
};

MODULE_DEVICE_TABLE (pci, vnet_ids);

/***************************************************************************************************
 *                                  PRIVATE FUNCTION DECLARATIONS
 */

static unsigned long vnet_rx (unsigned long addr, unsigned long maxPackets);

static irqreturn_t vnetIntHandler (int irq, void *pArg);
static void vnet_wake (unsigned long addr);
static void vnet_rx_timer (unsigned long addr);

/***************************************************************************************************
 *                                  IMPLEMENTATION
 */

static int vnet_start_xmit (
    struct sk_buff *skb,
    struct net_device *dev)
{
    int i;
    s32 error;
    struct vnet *tp = netdev_priv (dev);
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,7,0)
    struct netdev_queue *txq = netdev_get_tx_queue(dev, 0);
#endif
    int err;

    spin_lock (&tp->tx_lock);

#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif
    if ((tp->msg_enable & NETIF_MSG_PKTDATA)) {
        INFO_MSG("%s: Sending following frame, len = %i\n", __func__, skb->len);
        for (i = 0; i < skb->len; i = i + 1)
            printk("0x%X ", skb->data[i]);
        printk("\n");
    }

    // Copy packet len to TX buffer
    memcpy ((char *) txAddr, (char *) &skb->len, 4);

    // Copy packet to TX buffer
    memcpy (((char *) txAddr) + 4, skb->data, skb->len);

    // Initiate sending process
    err = pci_write_config_dword (tp->pdev, eVnetReg_init_send, 1);
    if (err) {
        ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_init_send);
        spin_unlock (&tp->tx_lock);
        /* leave hard_start_xmit function with condition 'BUSY' */
        return NETDEV_TX_BUSY;
    }

    if (tp->feature_tx_status_mem) {
        /* We already have sending status in memory */
        error = *((u32 *)txAddr);
    } else {
        /* Read sending status from PCI device */
        err = pci_read_config_dword (tp->pdev, eVnetReg_init_send, &error);
        if (err) {
            ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_init_send);
            spin_unlock (&tp->tx_lock);
            /* leave hard_start_xmit function with condition 'BUSY' */
            return NETDEV_TX_BUSY;
        }
    }

    if (error < 0)
    {
#if 0
        if ((tp->msg_enable & NETIF_MSG_TX_ERR))
        {
            if(error == -1)
                ERR_MSG("%s: vnet_ether_send_buf ring full\n", __func__);
            else
                ERR_MSG("%s: vnet_ether_send_buf timeout (%i)\n", __func__, error);
        }
#endif

        /* Stop transmit */
        netif_stop_queue(dev);

        spin_unlock (&tp->tx_lock);

        /* Switch wakeup timer on */
        mod_timer((struct timer_list *) & tp->wakeup_timer, jiffies + tp->wakeup_timer_jiffies);

        /* leave hard_start_xmit function with condition 'BUSY' */
        return NETDEV_TX_BUSY;
    }

    /* Update transmit statistics */
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,7,0)
    if (txq->trans_start != jiffies)
        txq->trans_start = jiffies;
#else
    netif_trans_update(dev);
#endif
    tp->net_stats.tx_bytes += skb->len;
    tp->net_stats.tx_packets++;
    /* Important: Freeing up the skb that has been allocated by the operating system before...
       But now we don't need the buffer anymore (because it already has been transfered!) */
    kfree_skb (skb);
    spin_unlock (&tp->tx_lock);

    return NETDEV_TX_OK;
}

static void vnet_tx_timeout (
    struct net_device *dev)
{
    struct vnet *tp = netdev_priv (dev);
#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif
    if ((tp->msg_enable & NETIF_MSG_TX_ERR))
        ERR_MSG("%s: TX timeout occurred\n", __func__);

    /* Update transmit statistics: error occurred */
    tp->net_stats.tx_errors++;

    /* wake up transmit queue */
    netif_wake_queue (dev);
}

static int vnet_change_mtu (
    struct net_device *dev,
    int new_mtu)
{
#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif
    struct vnet *tp = netdev_priv (dev);
    if (new_mtu > tp->package_size_max)
        return -1;
    dev->mtu = new_mtu;
    return 0;
}

static int vnet_ioctl (
    struct net_device *dev,
    struct ifreq *ifr,
    int cmd)
{
#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif
    return 0;
}

static void vnet_set_rx_mode (
    struct net_device *dev)
{
    struct vnet *tp = netdev_priv (dev);
    uint32_t flags;
    int err;

    // Get device flags
    err = pci_read_config_dword (tp->pdev, eVnetReg_device_flags, &flags);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_device_flags);
        ERR_MSG("%s: Unable to get device flags\n", __func__);
        return;
    }

#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s:: Entering\n", __func__);
#endif
    if (dev->flags & IFF_PROMISC)
    {
        INFO_MSG("%s: enable promisc\n", __func__);
        flags |= VNET_PROMISCUOUS_FLAG;
    }
    else
    {
        INFO_MSG("%s: disable promisc\n", __func__);
        flags &= ~VNET_PROMISCUOUS_FLAG;
    }

    if ((dev->flags & IFF_MULTICAST) | (dev->flags & IFF_ALLMULTI))
    {
        INFO_MSG("%s: enable multicast\n", __func__);
        flags |= VNET_MULTICAST_FLAG;
    }
    else
    {
        INFO_MSG("%s: disable multicast\n", __func__);
        flags &= ~VNET_MULTICAST_FLAG;
    }

    // Set device flags
    err = pci_write_config_dword (tp->pdev, eVnetReg_device_flags, flags);
    if (err) {
        ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_device_flags);
        ERR_MSG("%s: Unable to set device flags\n", __func__);
        return;
    }
}

static int vnet_set_mac_addr (
    struct net_device *dev,
    void *p)
{
    struct sockaddr *addr = p;
    struct vnet *tp = netdev_priv (dev);
    int err;
    u32 macAddrLow = 0, macAddrHigh = 0;

#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif

    if (!is_valid_ether_addr (addr->sa_data))
        return -EINVAL;

    memcpy (dev->dev_addr, addr->sa_data, dev->addr_len);

    memcpy (&macAddrLow, &dev->dev_addr[0], 4);
    memcpy (&macAddrHigh, &dev->dev_addr[4], 2);

    // Set mac addr
    err = pci_write_config_dword (tp->pdev, eVnetReg_mac_addr_low, macAddrLow);
    if (err) {
        ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_mac_addr_low);
        ERR_MSG("%s: Unable to set vnet MAC address\n", __func__);
        return -1;
    }

    err = pci_write_config_dword (tp->pdev, eVnetReg_mac_addr_high, macAddrHigh);
    if (err) {
        ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_mac_addr_high);
        ERR_MSG("%s: Unable to set vnet MAC address\n", __func__);
        return -1;
    }

    return 0;
}

static int vnet_open (struct net_device *dev)
{
#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif
    netif_start_queue (dev);
    return 0;
}

static int vnet_close (
    struct net_device *dev)
{
#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif
    netif_stop_queue (dev);
    return 0;
}

static struct net_device_stats *vnet_get_stats (
    struct net_device *dev)
{
    struct vnet *tp = netdev_priv (dev);
    struct net_device_stats *stats = &tp->net_stats;
#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif
    return stats;
}

/**
 * \brief
 */
static int run_vnet_rx(void *pArg)
{
    struct vnet *tp = (struct vnet *) pArg;
    int err;

    // Allow the SIGKILL signal
    allow_signal(SIGKILL);

    while (!kthread_should_stop()) {
        if(down_interruptible(&tp->sem))
            break;

        local_bh_disable();

        vnet_rx((unsigned long) tp, VNET_RECV_PACKETS_MAX);

        /* Ack interrupt */
        err = pci_write_config_dword(tp->pdev, eVnetReg_irr, 1);
        if (err)
            ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", DRV_MODULE_NAME, eVnetReg_irr);

        /* Retrieve packets that were received between last receive ('vnet_rx') and
           acknowledging the interrupt ('pci_write_config_dword') */
        vnet_rx((unsigned long) tp, 1024);

        local_bh_enable();
    }

    return 0;
}

static irqreturn_t vnetIntHandler (int irq, void *pArg)
{
    struct vnet *tp = (struct vnet *) pArg;
    u32 irr;

    if (irq == tp->irq)
    {
        // Test interrupt
        memcpy ((char *) &irr, (char *) rxAddr, 4);

        if (!irr) {
#if 0
        /* No interrupt occurred but isr called => not our interrupt (shared interrupt) */
        if ((tp->msg_enable & NETIF_MSG_RX_ERR))
            INFO_MSG("%s: IRR Register is zero, leaving ISR\n", __func__);
#endif
            return IRQ_NONE;
        }

        // Acknowledge interrupt (first level, i.e. the steady triggering of this irq level is disabled)
        memset ((char *) rxAddr, 0, 4);

        // Trigger RX task
        up(&tp->sem);

        return IRQ_HANDLED;
    }
    else
    {
        /* invalid interrupt received */
        return IRQ_NONE;
    }
}

/**
 * \brief Wake up transmit queue.
 */
static void vnet_wake (unsigned long addr)
{
    struct vnet *tp = (struct vnet *) addr;

    /* wake up transmit queue */
    netif_wake_queue (tp->dev);
}

/**
 * \brief
 */
static void vnet_rx_timer (unsigned long addr)
{
    struct vnet *tp = (struct vnet *) addr;

    /* receive up to VNET_RECV_PACKETS_MAX packets */
    vnet_rx(addr, VNET_RECV_PACKETS_MAX);

    if(tp->rx_timer_power)
        mod_timer ((struct timer_list *) &tp->rx_timer, jiffies + tp->rx_timer_jiffies);
}

/**
 * \brief Receive packets.
 */
static unsigned long vnet_rx (unsigned long addr, unsigned long maxPackets)
{
    struct vnet *tp = (struct vnet *) addr;
    struct sk_buff *skb;
    int e, err;
    u32 nReceivedPackets = 0, len;
    s32 nrEl = 0, ret;

    // Read current number of RX elements
    err = pci_read_config_dword(tp->pdev, eVnetReg_rx_count, &nrEl);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_rx_count);
        goto vnetRxErr;
    }

    while (nrEl > 0) {
        // Increment RX element
        err = pci_write_config_dword (tp->pdev, eVnetReg_inc_rx, 1);
        if (err) {
            ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_inc_rx);
            goto vnetRxErr;
        }

        // Read RX packet
        memcpy (&len, ((char *) rxAddr) + 4, 4);
        if (len > 1536) {
            if ((tp->msg_enable & NETIF_MSG_RX_ERR))
                INFO_MSG("%s: Invalid packet len received (%i)\n", __func__, len);
            goto vnetRxNextPacket;
        }

        // Allocate skb structure and fill in with the RX buffer
        skb = dev_alloc_skb (len + 16);
        if (!skb)
        {
            if ((tp->msg_enable & NETIF_MSG_RX_ERR))
                ERR_MSG("%s: low on mem - packet dropped\n", __func__);
            tp->net_stats.rx_dropped++;
            goto vnetRxNextPacket;
        }

        skb_reserve (skb, 16);

        memcpy(skb_put (skb, len), ((char *) rxAddr) + 8, len);

        if ((tp->msg_enable & NETIF_MSG_PKTDATA)) {
            INFO_MSG("%s: Received following frame, len = %i\n", __func__, skb->len);
            for (e = 0; e < skb->len; e = e + 1)
                printk("0x%X ", skb->data[e]);
            printk("\n");
        }

        /* Write metadata, and then pass to the receive level */
        skb->dev = tp->dev;
        skb->protocol = eth_type_trans (skb, tp->dev);
        skb->ip_summed = CHECKSUM_UNNECESSARY;  /*checksum is not necessary */
        tp->net_stats.rx_packets++;
        tp->net_stats.rx_bytes += len;
        ret = netif_rx (skb);
        if (ret == NET_RX_DROP)
            INFO_MSG("%s: Packet dropped\n", __func__);
        if ((tp->msg_enable & NETIF_MSG_PKTDATA)) {
            INFO_MSG("%s: Return code of netif_rx = %i\n", __func__, ret);
            if (ret == NET_RX_DROP)
                INFO_MSG("%s: Packet was dropped\n", __func__);
        }

vnetRxNextPacket:

        nReceivedPackets++;

        if (nReceivedPackets > maxPackets)
            break; /* while */

        // Read current number of RX elements
        err = pci_read_config_dword(tp->pdev, eVnetReg_rx_count, &nrEl);
        if (err) {
            ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_rx_count);
            goto vnetRxErr;
        }
    }

vnetRxErr:
    return nReceivedPackets;
}

/**
 * \brief
 */
static u32 vnet_get_msglevel (struct net_device *dev)
{
    struct vnet *tp = netdev_priv (dev);
#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif
    return tp->msg_enable;
}

/**
 * \brief
 */
static void vnet_set_msglevel (struct net_device *dev, u32 value)
{
    struct vnet *tp = netdev_priv (dev);
#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering (value=%d)\n", __func__, value);
#endif
    tp->msg_enable = value;
}

/*structure for ethtool entry functions*/
static struct ethtool_ops vnet_ethtool_ops = {
    .get_msglevel = vnet_get_msglevel,
    .set_msglevel = vnet_set_msglevel,
};

static struct vnet *dev_structs[100];
static int nrDevStructs = 0;

static struct vnet *vnet_pop_device_structure (void)
{
    if (nrDevStructs > 0) {
        nrDevStructs--;
        return dev_structs[nrDevStructs];
    }
    else
        return NULL;
}

/**
 * \brief
 */
static void vnet_push_device_structure (struct vnet *tp)
{
    dev_structs[nrDevStructs] = tp;
    nrDevStructs++;
}

/**
 * \brief
 */
static int vnet_probe (struct pci_dev *dev, const struct pci_device_id *id)
{
    u32 revision, feature;
    u32 txAddrPhys, rxAddrPhys;
#ifdef VNET_ALLOC_RINGS
    struct page *rxAddrPage = NULL, *txAddrPage = NULL;
#else
    u32 maxTxSize, maxRxSize;
#endif
    int err;
    char interfaceStr[18];

    struct net_device *netdev;
    struct vnet *tp;
    u8 mac_addr0[6];
    u32 macAddrLow;
    u32 macAddrHigh;

#ifdef VNET_ENTRY_MESSAGES
    u8 pci_bus = dev->bus->number, pci_dev = PCI_SLOT (dev->devfn), pci_func = PCI_FUNC (dev->devfn);
#endif
#ifdef RTHINTERFACE_MESSAGES
    uint32_t uRet;
#endif

    static const struct net_device_ops netdev_ops = {
        .ndo_open            = vnet_open,
        .ndo_stop            = vnet_close,
        .ndo_get_stats       = vnet_get_stats,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,2,0)
        .ndo_set_rx_mode = vnet_set_rx_mode,
#else
        .ndo_set_multicast_list = vnet_set_rx_mode,
#endif
        .ndo_set_mac_address = vnet_set_mac_addr,
        .ndo_do_ioctl        = vnet_ioctl,
        .ndo_tx_timeout      = vnet_tx_timeout,
        .ndo_change_mtu      = vnet_change_mtu,
        .ndo_start_xmit      = vnet_start_xmit,
    };

#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif

    // Enable PCI device
    err = pci_enable_device (dev);
    if (err) {
        ERR_MSG("%s: Cannot enable PCI device\n", __func__);
        goto err_out;
    }

#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: PCI bus (%i), dev (%i), func (%i)\n", __func__, pci_bus, pci_dev, pci_func);
#endif

    // Read revision and feature
    err = pci_read_config_dword(dev, eVnetReg_revision, &revision);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_revision);
        goto err_out;
    }
    err = pci_read_config_dword(dev, eVnetReg_feature_revision, &feature);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_feature_revision);
        goto err_out;
    }

    // Check revision and feature
    if (revision != 2) {
        ERR_MSG("%s: Unsupported revision (%i)\n", __func__, revision);
        goto err_out;
    }

    INFO_MSG("driver version %s\n", DRIVER_VERSION);
    INFO_MSG("%s: protocol revision %i.%d\n", __func__, revision, feature);

    // Reset device
    err = pci_write_config_dword (dev, eVnetReg_reset, 1);
    if (err) {
        ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_reset);
        goto err_out;
    }

#ifdef VNET_ALLOC_RINGS
    // Allocate TX buffer
    txAddrPage = alloc_pages(GFP_DMA32, 0);
    if (txAddrPage == NULL) {
        ERR_MSG("%s: Unable to allocate a page for TX buffer\n", __func__);
        goto err_out;
    }
    txAddr = (unsigned long) page_address (txAddrPage);
    txAddrPhys = virt_to_phys ((volatile void *) txAddr);

    // Write TX addr
    err = pci_write_config_dword (dev, eVnetReg_tx_buf_addr, txAddrPhys);
    if (err) {
        ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_tx_buf_addr);
        goto err_out;
    }

    // Write TX buffer size
    err = pci_write_config_dword (dev, eVnetReg_tx_buf_size, PAGE_SIZE);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_max_pkt_siz_tx);
        goto err_out;
    }

    // Allocate RX buffer
    rxAddrPage = alloc_pages (GFP_DMA32, 0);
    if (rxAddrPage == NULL) {
        ERR_MSG("%s: Unable to allocate a page for RX buffer\n", __func__);
        goto err_out;
    }
    rxAddr = (unsigned long) page_address (rxAddrPage);
    rxAddrPhys = virt_to_phys ((volatile void *) rxAddr);

    // Write RX addr
    err = pci_write_config_dword (dev, eVnetReg_rx_buf_addr, rxAddrPhys);
    if (err) {
        ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_rx_buf_addr);
        goto err_out;
    }

    // Write RX buffer size
    err = pci_write_config_dword (dev, eVnetReg_rx_buf_size, PAGE_SIZE);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_max_pkt_siz_rx);
        goto err_out;
    }
#else
    // Read max TX buffer size
    err = pci_read_config_dword (dev, eVnetReg_tx_buf_size, &maxTxSize);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_max_pkt_siz_tx);
        goto err_out;
    }

    // Read TX addr
    err = pci_read_config_dword (dev, eVnetReg_tx_buf_addr, &txAddrPhys);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_tx_buf_addr);
        goto err_out;
    }
    // Map TX buffer
    txAddr = (unsigned long) ioremap_cache (txAddrPhys, maxTxSize);

    // Read max RX buffer size
    err = pci_read_config_dword (dev, eVnetReg_rx_buf_size, &maxRxSize);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_max_pkt_siz_rx);
        goto err_out;
    }

    // Read RX addr
    err = pci_read_config_dword (dev, eVnetReg_rx_buf_addr, &rxAddrPhys);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_rx_buf_addr);
        goto err_out;
    }

    // Map RX buffer
    rxAddr = (unsigned long) ioremap_cache (rxAddrPhys, maxRxSize);
#endif

    /* Output module parameters (for confirmation) */
    if ((VNET_DEF_MSG & NETIF_MSG_DRV)) {
        INFO_MSG("%s: physical addr TX buf = 0x%X\n", __func__, (int) txAddrPhys);
        INFO_MSG("%s: virtual addr TX buf = 0x%X\n",  __func__, (int) txAddr);
        INFO_MSG("%s: physical addr RX buf = 0x%X\n", __func__, (int) rxAddrPhys);
        INFO_MSG("%s: virtual addr RX buf = 0x%X\n",  __func__, (int) rxAddr);
    }

    /* check device instance */
    tp = NULL;

    /* Allocate a Ethernet device */
    netdev = alloc_etherdev (sizeof (*tp));
    if (!netdev) {
        ERR_MSG("%s: Etherdev alloc failed, aborting\n", __func__);
        err = -ENOMEM;
        goto err_out;
    }

    SET_NETDEV_DEV (netdev, &dev->dev);
    tp = netdev_priv (netdev);
    tp->dev = netdev;
    tp->pdev = dev;

    /* Set optimization features */
    tp->feature_tx_status_mem = feature >= eFeature_tx_status_mem;

    vnet_push_device_structure (tp);
    if ((VNET_DEF_MSG & NETIF_MSG_DRV))
        INFO_MSG("%s: tp = 0x%lX, netdev = 0x%lX\n", __func__, (unsigned long) tp, (unsigned long) netdev);

    /* turn off promisc and multicast */
    err = pci_write_config_dword(dev, eVnetReg_device_flags, 0);
    if (err) {
        ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_device_flags);
        goto err_out_free_dev;
    }

    /* Set network device name (e.g. "vnet0") */
    snprintf(interfaceStr, 18, "%s%%d", interface_name);
    strcpy(netdev->name, interfaceStr);

    netdev->netdev_ops = &netdev_ops;
    netdev->watchdog_timeo = VNET_TX_TIMEOUT;
    netdev->ethtool_ops = &vnet_ethtool_ops;

    if (vnet_debug > 0)
        tp->msg_enable = vnet_debug;
    else
        tp->msg_enable = VNET_DEF_MSG;

    err = register_netdev (netdev);
    if (err) {
        ERR_MSG("%s: Cannot register net device, " "aborting\n", __func__);
        goto err_out_free_dev;
    }

    // Get maximum packet size
    err = pci_read_config_dword (dev, eVnetReg_max_pkt_siz_tx, &tp->package_size_max);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_max_pkt_siz_tx);
        goto err_out_unregister_dev;
    }

    // Get mac addr
    err = pci_read_config_dword (dev, eVnetReg_mac_addr_low, &macAddrLow);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_mac_addr_low);
        goto err_out_unregister_dev;
    }

    err = pci_read_config_dword (dev, eVnetReg_mac_addr_high, &macAddrHigh);
    if (err) {
        ERR_MSG("%s: Cannot read from PCI config space (reg %i)\n", __func__, eVnetReg_mac_addr_high);
        goto err_out_unregister_dev;
    }

    memcpy (&mac_addr0[0], &macAddrLow, 4);
    memcpy (&mac_addr0[4], &macAddrHigh, 2);

    /*Set MAC Address in network device driver structure */
    memcpy (netdev->dev_addr, mac_addr0, netdev->addr_len);

    /* Set up spinlocks */
    spin_lock_init (&tp->tx_lock);

    /* Set up wake up timer */
    tp->wakeup_timer_interval = wakeup_timer_interval;
    tp->wakeup_timer_jiffies = msecs_to_jiffies(tp->wakeup_timer_interval);
    init_timer((struct timer_list *) & tp->wakeup_timer);
    tp->wakeup_timer.function = vnet_wake;
    tp->wakeup_timer.data = (unsigned long) tp;
    tp->wakeup_timer.expires = 0;

    tp->rx_timer_interval = rx_timer_interval;
    tp->rx_timer_jiffies = msecs_to_jiffies(tp->rx_timer_interval);

    if (!interrupt_mode) {
        INFO_MSG("%s: Switching to polling mode\n", __func__);
        tp->polling = true;

        /* Set the receive timer */
        init_timer((struct timer_list *) & tp->rx_timer);
        tp->rx_timer.function = vnet_rx_timer;
        tp->rx_timer.data = (unsigned long) tp;

        /* Switch timer on */
        tp->rx_timer.expires = jiffies + tp->rx_timer_jiffies;
        tp->rx_timer_power = 1;
        add_timer((struct timer_list *) & tp->rx_timer);
    } else {
        INFO_MSG("%s: Switching to interrupt mode\n", __func__);
        tp->polling = false;

        /* Install interrupt handler */
        tp->irq = dev->irq;

        err = request_irq(tp->irq, vnetIntHandler, IRQF_SHARED, DRV_MODULE_NAME, tp);
        if (err) {
            ERR_MSG("%s: Cannot install interrupt handler for irq (%i). Ret (%i)\n", __func__, tp->irq, err);
            goto err_out_unregister_dev;
        }

        INFO_MSG("%s: Interrupt handler installed for irq (%i)\n", __func__, tp->irq);

        // Initialize semaphore
        sema_init(&tp->sem, 0);

        vnet_do_rx_thread = kthread_run(run_vnet_rx, tp, "vnetdorx");

        if (vnet_do_rx_thread == NULL) {
            ERR_MSG("%s: Unable to create kernel thread\n", __func__);
            goto err_out_unregister_dev;
        }

        /* Enable interrupt (unmask interrupt) */
        err = pci_write_config_dword(dev, eVnetReg_mask, 0);
        if (err) {
            ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_mask);
            goto err_out_unregister_dev;
        }
    }

    if ((VNET_DEF_MSG & NETIF_MSG_DRV))
        INFO_MSG( "%s init done\n", __func__);

    driverEnabled = 1;

    return 0;

  err_out_unregister_dev:
    unregister_netdev (netdev);
  err_out_free_dev:
    free_netdev (netdev);
  err_out:
    return err;

}

static void __exit vnet_remove (
    struct pci_dev *dev)
{
    struct vnet *tp;
    struct net_device *netdev = NULL;
    int err;

#ifdef VNET_ENTRY_MESSAGES
    INFO_MSG("%s: Entering\n", __func__);
#endif

    if ((VNET_DEF_MSG & NETIF_MSG_DRV))
        INFO_MSG("%s: Entering\n", __func__);

    if (!driverEnabled)
        return;

#ifdef VNET_CLEANUP_DEBUG
    INFO_MSG("%s: Try to get device structure...\n", __func__);
#endif
    tp = vnet_pop_device_structure ();
    if (tp == NULL) {
        if ((VNET_DEF_MSG & NETIF_MSG_DRV))
            ERR_MSG("%s: Internal error: cannot get pointer to network device structure because network device is not registered (after checking that the device is registered)\n",
                    __func__);
    }

    if ((VNET_DEF_MSG & NETIF_MSG_DRV))
        INFO_MSG("%s: Trying to free driver, tp = 0x%lX\n", __func__, (unsigned long) tp);

    /* Remove transmit queue wake up timer */
    del_timer_sync((struct timer_list *) & tp->wakeup_timer);

    if (!tp->polling) {
        /* Disable interrupt (mask interrupt) */
        err = pci_write_config_dword(dev, eVnetReg_mask, 1);
        if (err) {
            ERR_MSG("%s: Cannot write to PCI config space (reg %i)\n", __func__, eVnetReg_mask);
        }

        /* Free irq */
        free_irq(tp->irq, tp);
        force_sig(SIGKILL, vnet_do_rx_thread);
        kthread_stop(vnet_do_rx_thread);
    } else {
        /* Switch timer off */
        tp->rx_timer_power = 0;
        del_timer_sync((struct timer_list *) & tp->rx_timer);
    }

    // Disable PCI device
    pci_disable_device (dev);

    netdev = tp->dev;
#ifdef VNET_CLEANUP_DEBUG
    INFO_MSG("%s: Try to unregister netdev...\n", __func__);
#endif
    unregister_netdev (netdev);
#ifdef VNET_CLEANUP_DEBUG
    INFO_MSG("%s: Try to free netdev...\n", __func__);
#endif
    free_netdev (netdev);

    tp = NULL;

#ifdef VNET_ALLOC_RINGS
#ifdef VNET_CLEANUP_DEBUG
    INFO_MSG("%s: Try to release ring memory...\n", __func__);
#endif
    free_pages (rxAddr, 0);
    free_pages (txAddr, 0);
#endif

    if ((VNET_DEF_MSG & NETIF_MSG_DRV))
        INFO_MSG("%s: driver unregistered\n", __func__);

    driverEnabled = 0;
}

static int __init vnet_init (void)
{
    return pci_register_driver (&pci_driver);
}

static void __exit vnet_cleanup (void)
{
    pci_unregister_driver (&pci_driver);
}

module_init (vnet_init);
module_exit (vnet_cleanup);
