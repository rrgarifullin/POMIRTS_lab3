/**
 * \file    timeSyncInterface.h
 *
 * \brief   Common declarations for Linux Driver and Linux User timesync API
 *
 * This file can be used by both kernel-mode and user-mode programs.
 *
 * \copyright (c) 2012-2016 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  01c, 2016-09-16, yuriz - added definition of tTimeFlags
 * \li  01b, 2012-05-30, S.Fausser - added timeSync typedefs, i.e. tTimeSyncSet/GetMaster, tTimeSyncSet/GetSyncInterval etc.
 * \li  01a, 2012-02-15, F.Harmuth - created
 *
 */

#ifndef TIMESYNCIF_H
#define TIMESYNCIF_H

/***************************************************************************************************
 *                                            INCLUDES
 */

/***************************************************************************************************
 *                                           DEFINITIONS
 */

/***************************************************************************************************
 *                                           DATA TYPES
 */

#ifdef __KERNEL__
typedef u8  uint8;
typedef u16 uint16;
typedef u32 uint32;
typedef s8  int8;
typedef s16 int16;
typedef s32 int32;

/**
 * \brief Time synchronization states.
 * \note  This is required for timeSyncInterface (must correspond to libRth.h)
 */
typedef enum eTimeSyncStatus
{
    eTimeSyncState_error                = 0,    /**< Error - cannot retrieve status */
    eTimeSyncState_stopped              = 1,    /**< Time synchronization not configured */
    eTimeSyncState_master               = 2,    /**< We are master and providing time to other OSes */
    eTimeSyncState_slave_sync           = 3,    /**< We are slave and got a new time during last 4 intervals */
    eTimeSyncState_slave_no_sync        = 4     /**< We are slave and didn't get a new time recently */
} tTimeSyncStatus;

#else /* not kernel */
#include <inttypes.h>
typedef uint8_t  uint8;
typedef uint16_t uint16;
typedef uint32_t uint32;
typedef int8_t   int8;
typedef int16_t  int16;
typedef int32_t  int32;
#endif

enum eTimeZoneUsage
{
    /* Bias is valid, TZ (daylight info) not present */
    eTimeZoneUsage_SetUtcWithBias   = 0,
    /* Bias and TZ info valid, DST rules may or may not be present */
    eTimeZoneUsage_SetTimeZone      = 1,
    /* Bias and TZ doesn't matter; timeUTC may be actually NOT UTC (see eTimeFormat below) --
       in this case the receiving side MUST know how to calculate UTC time from the received
       "local time"  */
    eTimeZoneUsage_DoNotSetTimeZone = 2
};

enum eTimeFormat
{
    eTimeFormat_SetTimeUTC          = 0,        /**< timeUTC contains UTC time (default) */
    eTimeFormat_SetTimeAsLocalTime  = 1         /**< timeUTC contains local time */
};

typedef union
{
    uint32_t mData;
    struct {
        uint8  mTimeZoneUsage;        /**< see eTimeZoneUsage enum */
        uint8  mTimeFormat;           /**< see eTimeFormat enum */
        uint16 mReserved;
    } s;
} tTimeFlags;

typedef struct
{
    uint16    month;                  /**< month (January = 0) */
    uint16    dayOfWeek;              /**< day of week (Sunday = 0) */
    uint16    nOccurrence;            /**< occurrence of dayOfWeek in month (1-4), 5 means last occurrence in month */
    uint16    hour;                   /**< hour of daylight time change */
} __attribute__((packed)) tTimeInfo;

typedef struct
{
    uint32    daylightSaving;         /**< 1 if daylight saving is active now */
    int32     standardTimeBias;       /**< additional bias for standard time */
    int32     daylightTimeBias;       /**< additional bias for daylight time */
    tTimeInfo   standardTime;         /**< when does standard time kick in
                                          (valid if standardTime.nOccurrence) != 0) */
    tTimeInfo   daylightTime;         /**< when does daylight saving kick in
                                          (valid if daylightTime.nOccurrence) != 0) */
    char        standardTimeName[64];   /**< name of standard timezone (optional) */
    char        daylightTimeName[64];   /**< name of daylight saving timezone (optional) */
} __attribute__((packed)) tTimeZoneInfo;

typedef struct
{
    uint32 timeUTC;           /**< UTC time */
    uint32 timeMilliseconds;  /**< ms offset from UTC */
    int32  bias;              /**< bias from UTC */
    tTimeFlags flags;           /**< flags to specify how to handle the information */
    tTimeZoneInfo timeZone;     /**< time zone information */
} __attribute__((packed)) tTimeDesc;


/**
 * parameter package of rthTimeSyncSetMaster function
 */
typedef struct
{
    unsigned osId;
} tTimeSyncSetMaster;

/**
 * parameter package of rthTimeSyncGetMaster function
 */
typedef struct
{
    unsigned osId;
} tTimeSyncGetMaster;

/**
 * parameter package of rthTimeSyncSetSyncInterval function
 */
typedef struct
{
    unsigned long interval;
} tTimeSyncSetSyncInterval;

/**
 * parameter package of rthTimeSyncGetSyncInterval function
 */
typedef struct
{
    unsigned long interval;
} tTimeSyncGetSyncInterval;

/**
 * parameter package of rthTimeSyncGetSyncState function
 */
typedef struct
{
    tTimeSyncStatus state;
} tTimeSyncGetSyncState;

/**
 * parameter package of tTimeSyncGetTimezone function
 */
typedef struct
{
    tTimeDesc timeDesc;
} tTimeSyncGetTimezone;

/**
 * parameter package of tTimeSyncSetTimezone function
 */
typedef struct
{
    tTimeDesc timeDesc;
} tTimeSyncSetTimezone;

/***************************************************************************************************
 *                                     FUNCTION DECLARATIONS
 */


#endif                          /* TIMESYNCIF_H */
