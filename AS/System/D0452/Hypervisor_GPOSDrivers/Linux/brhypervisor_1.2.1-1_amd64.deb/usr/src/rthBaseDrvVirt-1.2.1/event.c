/**
 * \file    event.c
 *
 * \brief   Event API implementation
 *
 * \copyright (c) 2012-2013 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  03a, 2017-11-09, Y.Zaporozhets - new implementation of event subsystem
 * \li  02e, 2017-09-25, Y.Zaporozhets - removed support of kernels older than 2.6.32
 * \li  02d, 2017-08-22, Y.Zaporozhets - removed duplicated code, use RTHCALL macros instead
 * \li  02c, 2013-01-24, S.Fausser - 1. Ensure that the physical address pointing to the rthCtrl structure addressable within 32 bit
 *                                      (replaced kmalloc w/ GFP_KERNEL by __get_free_pages w/ GFP_DMA32)
 *                                   2. Use enums for register offsets instead of hard-coded values
 * \li  02b, 2012-12-28, C.Gmeiner - issue #1053 - remove event from driver eventlist after close
 * \li  02a, 2012-05-29, S.Fausser - rewritten based on F.Harmuth event.c
 *                       (removed F. Harmuth event-lists. Reason: Calling vmalloc in ISR may be deadly
 *                                    and is time-consuming.
 *                        Added memory barriers, mostly wmb() after outl.
 *                        Without these the return value might be read before the outl is performed
 *                        due to compiler 'optimizations')
 * \li  01a, 2012-02-17, F.Harmuth - created
 *
 */


/***************************************************************************************************
 *                                            INCLUDES
 */

#include "common.h"

#include <linux/eventfd.h>
#include <linux/file.h>
#include <linux/fdtable.h>

/***************************************************************************************************
 *                                            DEFINES
 */

/* The key returned and used by the hypervisor must be less than this value */
#define MAX_EV_KEYS             1024

/* Maximum number of processes that may receive notifications using eventfd */
#define MAX_EV_CLIENTS          32

/***************************************************************************************************
 *                                           DATA TYPES
 */
struct rth_event_client {
    struct list_head    list;           /* List */
    int                 fd;             /* File descriptor */
    struct file         *filp;          /* Event file descriptor and context */
    struct task_struct  *tsk;           /* Task that opened or created the event */
};

struct rth_event {
    spinlock_t          lock;           /* Lock to protect the entry */
    atomic_t            count;          /* Count */
    struct list_head    clients;        /* Linked list of clients to signal the event */
};

/***************************************************************************************************
 *                                        LOCAL VARIABLES
 */

/* Events array */
static struct rth_event lRthEvents[MAX_EV_KEYS];

/* All the event add and remove functions are protected by this spinlock */
static DEFINE_SPINLOCK(event_lock);

extern long baseDrv_ioaddr;


/***************************************************************************************************
 *                                      FORWARD DECLARATIONS
 */

/***************************************************************************************************
 *                                         IMPLEMENTATION
 */

/**
 * \brief Perform elementary sanity check of supplied event fd.
 * \return 0 if valid, negative value if not valid
 */
static int lEventFdValid (const int fd)
{
    struct fdtable *fdt;
    int res = 0;

    spin_lock(&current->files->file_lock);
    fdt = files_fdtable(current->files);
    if (fd >= fdt->max_fds) {
        ERR_MSG("supplied eventfd %d invalid\n", fd);
        res = -1;
    }
    spin_unlock(&current->files->file_lock);
    return res;
}

/**
 * For a given key, check whether the element with a given task in the list.
 * \return element address, or NULL if not found
 */
static struct rth_event_client *lTaskIsInList (const tEventKey key, const struct task_struct *tsk)
{
    struct list_head *ptr;

    if (list_empty(&lRthEvents[key].clients))
        return NULL;

    /* Traverse through the list */
    list_for_each(ptr, &lRthEvents[key].clients) {
        struct rth_event_client *client = list_entry(ptr, struct rth_event_client, list);
        if (client->tsk == tsk)
            return client;
    }
    return NULL;
}

/**
 * For a given key, check whether the fd for current task is already in the list.
 * \return element address, or NULL if not found
 */
static struct rth_event_client *lEvFdIsInList (const tEventKey key, const int fd)
{
    struct list_head *ptr;
    struct rth_event_client *entry;

    if (key >= MAX_EV_KEYS)
        return NULL;

    /* Return NULL if the list is empty */
    if (list_empty(&lRthEvents[key].clients))
        return NULL;

    /* Traverse through the list */
    list_for_each(ptr, &lRthEvents[key].clients) {
        entry = list_entry(ptr, struct rth_event_client, list);
        pr_debug("entry fd %d, owner %p\n", entry->fd, entry->tsk);
        if (entry->fd == fd && entry->tsk == current)
            return entry;
    }
    return NULL;
}

/**
 * \brief Set the state of the event using RTH call.
 */
static int lStateSet (uint32_t eventKey, uint32_t eventState)
{
    int ret;

    tRthCall_EventState *rthCall;

    RTHCALL_PREPARE(rthCall, eRthCtrl_eventStateSet);
    rthCall->mEventKey = eventKey;
    rthCall->mEventState = eventState;

    RTHCALL_DO(rthCall);
    ret = rthCall->mHead.mReturn & 0xFFFFFFFF;
    RTHCALL_FINI(rthCall);

    return ret;
}

/**
 * \brief Inform all processes waiting for the given key that the event was set.
 */
static void eventDeliver(tEventKey key)
{
    unsigned long flags;
    struct list_head *ptr;

    /* Return immediately if the event key is too big */
    if (key >= MAX_EV_KEYS) {
        ERR_MSG("event key %d exceeds maximum allowed %d\n", key, MAX_EV_KEYS-1);
        return;
    }

    atomic_set(&lRthEvents[key].count, 1);

    spin_lock_irqsave(&event_lock, flags);

    /* Traverse through the list */
    list_for_each(ptr, &lRthEvents[key].clients) {
        struct eventfd_ctx *fdctx;
        struct rth_event_client *client = list_entry(ptr, struct rth_event_client, list);
        if (client == NULL) {
            ERR_MSG("null entry for event %d\n", key);
            continue;
        }
        /*
         * Get the address of eventfd context descriptor.
         * Internally, the address of context descriptor is stored by the Linux kernel in
         * the "private" field of struct file.
         * So please do not use "private" for any other purposes.
         */
        fdctx = eventfd_ctx_fileget(client->filp);
        if (fdctx == NULL) {
            ERR_MSG("%s: error getting event ctx fileget\n", __func__);
            continue;
        }

        /*
         * Increase the "count" field in eventfd descriptor and release the context
         * After this, any task doing poll/select/read on the eventfd will wake up.
         */
        eventfd_signal(fdctx, 1);
        eventfd_ctx_put(fdctx);
        atomic_set(&lRthEvents[key].count, 0);
    }

    spin_unlock_irqrestore(&event_lock, flags);
}


/*
 * \brief Create or open the event.
 */
static int lEventCreateOrOpen(tEventCreate *par, const bool create)
{
    tRthCall_EventCreate *rthCall;
    tEventKey key;
    int ret, count = 0, len;
    struct rth_event_client *client;
    bool was_really_created = false;
    bool was_really_opened = false;

    if (par == NULL)
        return -1;
    if (par->pEventName == NULL)
        return -1;

    DBG_MSG("%s event %s\n", create ? "creating" : "opening", par->pEventName);

    /* Take the trailing zero into account */
    len = par->lenName + 1;
    if (len >= MAX_EVENT_NAME_SIZE)
        return -1;

    if (create) {
        /* Initial state must be either 0 or 1 */
        if(par->initialState != 0 && par->initialState != 1)
            return -1;
    }

    RTHCALL_PREPARE(rthCall, eRthCtrl_eventCreate);

    rthCall->mMode = par->mode;
    if (strncpy_from_user(rthCall->mEventName, par->pEventName, len) < 0) {
        ret = -1;
        goto out;
    }

    RTHCALL_DO(rthCall);
    ret = rthCall->mHead.mReturn & 0xFFFFFFFF;
    DBG_MSG("... ret = %d\n", ret);
    switch (ret) {
        case 1:
            if (create) {
                count = par->initialState;
                was_really_created = true;
            }
            break;
        case 2:
            if (!create) {
                was_really_opened = true;
            }
            break;
        case 3:
            /* Special case, "event doesn't exist" */
            if (!create) {
                ret = -ret;
                goto out;
            }
            /* Fall through */
        default:
            /* Some error occurred */
            ret = -ret;
            goto out;
    }

    key = rthCall->mEventKey;

    /* If the client is not yet in the list, create a new event descriptor */
    client = lEvFdIsInList(key, par->efd);
    if (client == NULL) {
        struct file *filp;

        if (lEventFdValid(par->efd) < 0) {
            ret = -7;
            goto out;
        }

        client = kmalloc(sizeof(*client), GFP_KERNEL);
        if (client == NULL) {
            ERR_MSG("cannot allocate memory for event client object\n");
            ret = -6;
            goto out;
        }

        filp = eventfd_fget(par->efd);
        if (IS_ERR(filp)) {
            ret = -5;
            goto out;
        }

        client->fd = par->efd;
        client->filp = filp;
        client->tsk = current;
        spin_lock(&lRthEvents[key].lock);
        list_add(&client->list, &lRthEvents[key].clients);
        spin_unlock(&lRthEvents[key].lock);
        pr_debug("new descriptor for event client created (fd: %d, tsk: %p)\n",
                    client->fd, client->tsk);
        par->eventFdExists = false;
    } else {
        /* User-space may close eventfd for this key because it is already registered */
        par->eventFdExists = true;
    }

    par->eventKey = key;

    if (was_really_created) {
        DBG_MSG("event '%s' created, key 0x%04X\n", rthCall->mEventName, par->eventKey);
        lStateSet(key, count);
    } else if (was_really_opened) {
        DBG_MSG("event '%s' opened (it existed), key 0x%04X\n", rthCall->mEventName, par->eventKey);
        ret = 0;
    }

out:
    RTHCALL_FINI(rthCall);

    return ret;
}


/**
 * \brief Close the event and remove the corresponding entry from the list.
 */
static int lEventClose(const unsigned long arg)
{
    tRthCall1Param *rthCall;
    tEventClose *par = (tEventClose *) arg;
    int ret = 0;
    tEventKey key;
    struct rth_event_client *client;

    if (arg == 0)
        return -1;

    key = par->eventKey;
    if (key >= MAX_EV_KEYS)
        return -1;

    /* Instruct hypervisor to destroy the event regardless of whether we have it in the list */
    RTHCALL_PREPARE(rthCall, eRthCtrl_eventDestroy);
    rthCall->mParam0 = key;
    RTHCALL_DO(rthCall);
    ret = rthCall->mHead.mReturn & 0xFFFFFFFF;
    RTHCALL_FINI(rthCall);

    switch (ret) {
        case 1:
        case 2:
            ret = 0;        /* success */
            client = lTaskIsInList(key, current);
            if (client != NULL) {
                DBG_MSG("removing client %p\n", client->tsk);
                par->efd = client->fd;
                spin_lock(&lRthEvents[key].lock);
                list_del(&client->list);
                spin_unlock(&lRthEvents[key].lock);
                kfree(client);
            }
            break;
        case 3:
            ret = -1;       /* invalid eventKey */
            break;
    }

    return ret;
}

/**
 * \brief Set the event state.
 */
static int lEventStateSet(const unsigned long arg)
{
    tEventStateSet *par = (tEventStateSet *) arg;
    tEventKey key;
    int state;

    if(par == NULL)
        return -1;

    key = par->eventKey;
    state = par->eventState;

    if (key <= 0 || (state != 0 && state != 1))
        return -1;

    return lStateSet(key, state);
}



/**
 * \brief Get the event state (and additional information).
 */
static int lEventStateGet(const unsigned long arg)
{
    tEventStateGet *par = (tEventStateGet *) arg;
    int key;
    struct rth_event_client *client;

    if (par == NULL)
        return -1;

    /* Sanity check for key */
    key = par->eventKey;
    if (key >= MAX_EV_KEYS) {
        ERR_MSG("%s: wrong key %d supplied\n", __func__, key);
        return -1;
    }

    /* If the event count is non-zero, return immediately with success */
    if (atomic_read(&lRthEvents[key].count)) {
        atomic_set(&lRthEvents[key].count, 0);
        return 0;
    }

    client = lTaskIsInList(key, current);
    if (client == NULL) {
        ERR_MSG("%s: no clients for key %d in list\n", __func__, key);
        return -5;
    }

    par->efd = client->fd;
    return 1;   /* No immediate event, must poll() */
}

/***************************************************************************************************
 *                                   INTERFACE FUNCTIONS
 */

/**
 * \brief Interrupt service routine
 */
irqreturn_t event_isr (int irq, void *dev)
{
    tEventKey eventKey;
    int count = 10;
    uint32_t irq_state = inl(baseDrv_ioaddr + eRthDevIoOffset_IntStatus);

    if (irq_state == 0)
        return IRQ_NONE;

    do {
        /* Get the key for pending event */
        eventKey = inl(baseDrv_ioaddr + eRthDevIoOffset_EventPending);

        if (eventKey) {
            /* Reset the state */
            if (lStateSet(eventKey, 0)) {
                ERR_MSG("error resetting event state (key=%d)\n", eventKey);
                continue;
            }

            /* Deliver the event to those who are waiting for it */
            //DBG_MSG("delivering %d", eventKey);
            eventDeliver(eventKey);
        }
    } while (eventKey && count--);

    /* Acknowledge the interrupt */
    outl(irq_state, baseDrv_ioaddr + eRthDevIoOffset_IntStatus);
    //DBG_MSG("irq handled\n");
    return IRQ_HANDLED;
}

/**
 * \brief Event system ioctl handler
 */
int rthIoctlEvent (const unsigned cmd, const unsigned long arg, bool *processed)
{
    *processed = true;
    switch (cmd)
    {
        case eRthIoctl_eventCreate:
            return lEventCreateOrOpen((tEventCreate *)arg, true);

        case eRthIoctl_eventOpen:
            return lEventCreateOrOpen((tEventCreate *)arg, false);

        case eRthIoctl_eventClose:
            return lEventClose(arg);

        case eRthIoctl_eventStateSet:
            return lEventStateSet(arg);

        case eRthIoctl_eventStateGet:
            return lEventStateGet(arg);

        default:
            *processed = false;
    }

    return -1;
}

/**
 * Initialization
 */
void initEventSystem (void)
{
    int i;
    for (i = 0; i < MAX_EV_KEYS; i++) {
        INIT_LIST_HEAD(&lRthEvents[i].clients);
        atomic_set(&lRthEvents[i].count, 0);
    }
}

/**
 * Cleanup
 */
void cleanupEventSystem (void)
{
    int i;
    struct list_head *ptr, *next;

    for (i = 0; i < MAX_EV_KEYS; i++) {
        list_for_each_safe(ptr, next, &lRthEvents[i].clients) {
            list_del(ptr);
            kfree(ptr);
        }
    }
}
