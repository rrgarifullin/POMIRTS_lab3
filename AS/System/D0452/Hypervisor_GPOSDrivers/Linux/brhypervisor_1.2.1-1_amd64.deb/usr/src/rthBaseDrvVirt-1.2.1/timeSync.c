/**
 * \file    timeSync.c
 *
 * \brief   RTH Time synchronisation using the rthCtrl module
 *
 * Minimalist implemention: Linux-Kernel does not support timezones
 * The Linux distribution must set the local time to UTC (e.g. by removing /etc/localtime)
 * Further daylight saving time / summer time is not supported
 *
 * \copyright (c) 2012-2016 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  01j, 2017-08-22, Y.Zaporozhets - removed duplicated code, use RTHCALL macros instead
 * \li  01i, 2016-09-19, Y.Zaporozhets - add support for timesync flags, particularly
 *                                       eTimeZoneUsage_DoNotSetTimeZone
 * \li  01h, 2015-09-11, S.Fausser - removed error message when auto start key is not available
 * \li  01g, 2015-02-16, C.Gmeiner - only update time if required
 * \li  01f, 2015-02-16, C.Gmeiner - run master at least with 100ms
 * \li  01e, 2013-08-06, S.Fausser - added lTimeSyncSetTimezone() (required by rthTimeSyncUpdateTimezoneLocalMaster call, libRth / API)
 * \li  01d, 2013-04-30, S.Fausser - added lTimeSyncGetTimezone() (required by rthTimeSyncUpdateTimezone call, libRth / API)
 * \li  01c, 2013-01-24, S.Fausser - 1. Ensure that the physical address pointing to the rthCtrl structure addressable within 32 bit
 *                                      (replaced GFP_KERNEL by GFP_DMA32)
 *                                   2. Use enums for register offsets instead of hard-coded values
 * \li  01b, 2012-06-19, S.Fausser - only stop timeSync task if it has been started
 * \li  01a, 2012-05-14, S.Fausser - written, based on time sync lib for T-Kernel
 *
 */

/***************************************************************************************************
 *                                            INCLUDES
 */

#include "common.h"

#include "timeSyncInterface.h"
#include "shmImgStructs.h"

/***************************************************************************************************
 *                                            DEFINES
 */

/***************************************************************************************************
 *                                           DATA TYPES
 */

/***************************************************************************************************
 *                                        LOCAL VARIABLES
 */

extern long baseDrv_ioaddr;

static uint32_t lStartedTimeSyncTask = 0;
static tTimeSyncStatus lTsStatus = eTimeSyncState_stopped;
static struct task_struct *lTimeSyncTaskTs = NULL;
static tTimeDesc  lTimeDesc;
static int lTimeDescValid = 0;
static tTimeDesc  lTimeDescMaster;
static int lTimeDescMasterValid = 0;

/***************************************************************************************************
 *                                      FORWARD DECLARATIONS
 */

/***************************************************************************************************
 *                                         IMPLEMENTATION
 */

static int rthTimeSyncGetSyncInterval (uint32_t *pInterval)
{
    int ret;

    ret = doRthCall_Param1(eRthCtrl_timeSyncGetSyncInterval, pInterval);

    return 0 - ret;
}

static unsigned long timeSyncIsMaster (void)
{
    int ret;
    uint32_t osIdMaster, osIdOwn;

    ret = doRthCall_Param1(eRthCtrl_timeSyncGetMaster, &osIdMaster);
    if(ret) {
        /* Unable to get OS ID of clock sync master */
        ERR_MSG("### Unable to get OS ID of clock sync master (%i)\n", ret);
        return 0;
    }

    ret = rthCall_osIdGet(&osIdOwn);
    if(ret) {
        /* Unable to get OS id of running OS */
        ERR_MSG("### Unable to get OS id of running OS\n");
        return 0;
    }
    return (osIdMaster == osIdOwn);
}

static unsigned long timeSetRthTimeToLocalTime (void)
{
    tTimeDesc       timeDesc;
    uint32_t        ret;
    struct timeval  tv;
    tRthCall_TimeDesc *rthCall;

    /* Copy over time descriptor for Master or clear out timedesc */
    if(lTimeDescMasterValid)
        timeDesc = lTimeDescMaster;
    else
    {
        memset(&timeDesc, 0, sizeof(timeDesc));

        /* Set to UTC / GMT (should be already done by memset, re-done for better readability) */
        timeDesc.flags.s.mTimeZoneUsage = eTimeZoneUsage_SetUtcWithBias;
        timeDesc.bias = 0;
        timeDesc.timeZone.daylightSaving = 0;
    }

    /* Get system time */
    do_gettimeofday(&tv);

    /* Linux Kernel time: seconds and microseconds from 0:00:00 (GMT), January 1, 1970 */

    /* Values to RTH:
     * timeUTC: 32 bit value, seconds from UTC (Jan 1, 1970, 00:00)
     * timeMilliseconds: 32 bit value, millisecond offset from UTC */
    timeDesc.timeUTC = tv.tv_sec;
    /* Attention: We need to cast tv.tv_usec to 32 bit (unsigned long)
     * to avoid a 64 bit division which is not supported in 32 bit Linux Kernel*/
    timeDesc.timeMilliseconds = (unsigned long) tv.tv_usec / 1000UL;

    DBG_MSG("Set time: %us %ums, bias %umin\n", timeDesc.timeUTC, timeDesc.timeMilliseconds, timeDesc.bias);

    RTHCALL_PREPARE(rthCall, eRthCtrl_timeSyncSetTime);
    rthCall->mTimeDesc = timeDesc;

    RTHCALL_DO(rthCall);

    ret = rthCall->mHead.mReturn & 0xFFFFFFFF;
    RTHCALL_FINI(rthCall);

    if(ret) {
        /* Failed to set time in rth ctrl module */
        ERR_MSG("### Failed to set time in rth ctrl module (%i)\n", ret);
        return 2;
    }

    return 0;
}

static unsigned long timeSetLocalTimeToRthTime (uint32_t interval)
{
    uint32_t        ret;
    static int      failedGets = 0;
    tTimeDesc       timeDesc;
    struct timespec tvMaster;
    struct timeval  tvLocal;
    int64_t         timeMaster,timeLocal;
    int             err;
    uint32_t        biasMinutes;
    tRthCall_TimeDesc *rthCall;

    RTHCALL_PREPARE(rthCall, eRthCtrl_timeSyncGetTime);
    RTHCALL_DO(rthCall);

    ret = rthCall->mHead.mReturn & 0xFFFFFFFF;

    timeDesc = rthCall->mTimeDesc;

    RTHCALL_FINI(rthCall);

    if(ret)
    {
        /* no new time info is no error! */
        if(ret != 4)
        {
            /* Failed to get time */
        }
        else
        {
            failedGets++;
        }

        if(failedGets < 3)
            return 2;

        return 1;
    }

    failedGets = 0;

    lTimeDesc = timeDesc;
    lTimeDescValid = 1;

    biasMinutes = ~((uint32_t)timeDesc.bias) + 1;

    DBG_MSG("Got time from RTH: %us %ums, bias %umin, flags %d\n",
             timeDesc.timeUTC, timeDesc.timeMilliseconds, biasMinutes, timeDesc.flags.mData);

    if (timeDesc.flags.s.mTimeZoneUsage == eTimeZoneUsage_DoNotSetTimeZone &&
        timeDesc.flags.s.mTimeFormat == eTimeFormat_SetTimeAsLocalTime)
    {
        /* This is the only case when the time received from RTH is actually
         * NOT the UTC time, but rather "local time".
         * But we DO need UTC time here, to set it in kernel. To compute it,
         * we rely on information sent to us by the user-space program when we were
         * timesync master.
         * If such information is not available, we do nothing.
         */
        if (lTimeDescMasterValid)
        {
            /* Bias is negative east of Greenwhich, positive otherwise */
            int correction = lTimeDescMaster.bias * 60UL;
            /* Is timezone information in master descriptor valid? */
            if (lTimeDescMaster.flags.s.mTimeZoneUsage == eTimeZoneUsage_SetTimeZone)
                /* Does DST take place right now? */
                if (lTimeDescMaster.timeZone.daylightSaving)
                    /* Daylight time bias is always negative */
                    correction += lTimeDescMaster.timeZone.daylightTimeBias * 60UL;

            timeDesc.timeUTC += correction;
#ifdef DEBUG
            pr_debug("master: flags=%d, bias=%d, daylight_active=%d, daylightBias=%d\n",
                lTimeDescMaster.flags.mData,
                lTimeDescMaster.bias, lTimeDescMaster.timeZone.daylightSaving,
                lTimeDescMaster.timeZone.daylightTimeBias);
            pr_debug("applied %d seconds correction to RTH `localtime' to obtain UTC\n",
                correction);
#endif
        }
        else
        {
            pr_warn("timeSync: master didn't give us UTC time and we don't know"
                    " system's TZ info - ignoring\n");
            return 0;
        }
    }

    /* Values from RTH:
     * timeUTC: 32 bit value, seconds from UTC (Jan 1, 1970, 00:00)
     * timeMilliseconds: 32 bit value, millisecond offset from UTC */

    tvMaster.tv_sec = timeDesc.timeUTC;
    tvMaster.tv_nsec = timeDesc.timeMilliseconds * 1000000UL;
    timeMaster = timeDesc.timeUTC;
    timeMaster *= 1000;
    timeMaster +=timeDesc.timeMilliseconds;

    do_gettimeofday(&tvLocal);

    timeLocal = tvLocal.tv_sec;
    timeLocal *= 1000;
    timeLocal += (tvLocal.tv_usec / 1000);

    if(abs(timeLocal - timeMaster) < interval )
    {
        return 0;
    }

    /* Further value from RTH:
     * bias: bias in minutes */

#if 0
    tv.tv_sec += (biasMinutes * 60UL);
#endif

    if(timeDesc.flags.s.mTimeZoneUsage == eTimeZoneUsage_SetTimeZone) {
        DBG_MSG("### timeSetLocalTimeToRthTime: timeZoneInfoValid, standard bias (%i), daylight bias (%i)\n",
                timeDesc.timeZone.standardTimeBias, timeDesc.timeZone.daylightTimeBias);
    }

    /*DBG_MSG("Setting system time: %lu seconds %lu nanoseconds\n", tv.tv_sec, tv.tv_usec);*/

    err = do_settimeofday(&tvMaster);

    if(err) {
        /* Failed to set local system time */
        ERR_MSG("%s: Unable to set system time\n", __func__);
        return 1;
    }

    return 0;
}

static int timeSyncGetAutoStart (uint32_t *pAutoStart)
{
    int ret;

    ret = doRthCall_Param1(eRthCtrl_timeSyncGetAutoStart, pAutoStart);
    if(ret)
        return -1;

    return 0;
}

static int timeSyncTask(void *pArg)
{
    uint32_t interval;
    uint32_t ret;

    DBG_MSG("timeSyncTask: Started\n");
    pr_info("timeSyncTask: Starting RTH time synchronization\n");
    lTimeDescValid = 0;

    while(!kthread_should_stop())
    {
        DBG_MSG("timeSyncTask: Loop start\n");

        if(rthTimeSyncGetSyncInterval(&interval) != 0)
        {
            ERR_MSG("%s: rthTimeSyncGetSyncInterval() failed\n", __func__);
            return -1;
        }

        if(timeSyncIsMaster())
        {
            uint32_t masterInterval = interval;
            DBG_MSG("We are master\n");

            /* we are clock master */
            timeSetRthTimeToLocalTime();
            lTsStatus = eTimeSyncState_master;
            if(masterInterval > 100)
                masterInterval = 100;

            schedule_timeout_interruptible(msecs_to_jiffies(masterInterval));
        }
        else
        {
            DBG_MSG("We are slave\n");

            ret = timeSetLocalTimeToRthTime(interval);
            /* we are clock slave */
            if(ret == 1)
            {
                DBG_MSG("timeSyncTask: Set to slave not-sync\n");
                lTsStatus = eTimeSyncState_slave_no_sync;
            }
            else if(ret == 2)
            {
                DBG_MSG("timeSyncTask: Error getting rth time\n");
            }
            else
            {
                /* ret == 0 */
                DBG_MSG("timeSyncTask: Set to slave sync\n");
                lTsStatus = eTimeSyncState_slave_sync;
            }

            interval /= 2;
            schedule_timeout_interruptible(msecs_to_jiffies(interval));
        }
    }

    lTsStatus = eTimeSyncState_stopped;

    DBG_MSG("timeSyncTask: Stopped\n");

    return 0;
}

static int startRthTimeSyncTask (void)
{
    lStartedTimeSyncTask = 1;

    DBG_MSG("startRthTimeSyncTask: Called\n");

    lTimeSyncTaskTs = kthread_run(timeSyncTask, NULL, "rthBaseDrvT2");

    if(IS_ERR(lTimeSyncTaskTs))
    {
        ERR_MSG("%s: Unable to create kernel thread\n", __func__);
        return -1;
    }

    DBG_MSG("%s: Kernel thread created and started\n", __func__);

    return 0;
}

void stopTimeSync (void)
{
    int timeout = 1000;

    if(lTimeSyncTaskTs == NULL)
        return;

    /* Stop task */

    kthread_stop(lTimeSyncTaskTs);

    while(lTsStatus != eTimeSyncState_stopped && lTsStatus != eTimeSyncState_error)
    {
        /* sleep for one millisecond */
        schedule_timeout_interruptible(msecs_to_jiffies(1));

        timeout--;
        if(timeout <= 0)
          break;
    }

    if(timeout <= 0)
        ERR_MSG("### stopTimeSync: timeout\n");

    lStartedTimeSyncTask = 0;
}

int startTimeSync (uint32_t forceStart)
{
    uint32_t autoStart = 0;

    /* check if API is available */
    if(timeSyncGetAutoStart(&autoStart))
        return -1;

    if(timeSyncIsMaster() || autoStart || forceStart)
    {
        startRthTimeSyncTask();
        return 0;
    }

    return -1;
}

/* User API functions; see libRth.h */

static int lTimeSyncSetMaster (
    const unsigned long arg)
{
    tTimeSyncSetMaster *pack = NULL;
    uint32_t ret;

    DBG_MSG("rthTimeSyncSetMaster\n");
    /* check parameter */
    if( 0 == arg )
        return -1;

    pack = (tTimeSyncSetMaster *)arg;

    ret = doRthCall_Param1(eRthCtrl_timeSyncSetMaster, &pack->osId);

    return 0 - ret;
}

static int lTimeSyncGetMaster (
    const unsigned long arg)
{
    tTimeSyncGetMaster *pack = NULL;
    uint32_t ret;

    DBG_MSG("rthTimeSyncGetMaster\n");
    /* check parameter */
    if( 0 == arg )
        return -1;

    pack = (tTimeSyncGetMaster *)arg;

    ret = doRthCall_Param1(eRthCtrl_timeSyncGetMaster, &pack->osId);

    return 0 - ret;
}

static int lTimeSyncSetSyncInterval (
    const unsigned long arg)
{
    tTimeSyncSetSyncInterval *pack = NULL;
    uint32_t ret;
    uint32_t interval;

    DBG_MSG("rthTimeSyncSetSyncInterval\n");
    /* check parameter */
    if( 0 == arg )
        return -1;

    pack = (tTimeSyncSetSyncInterval *)arg;

    interval = pack->interval;

    ret = doRthCall_Param1(eRthCtrl_timeSyncSetSyncInterval, &interval);

    return 0 - ret;
}

static int lTimeSyncGetSyncInterval (
    const unsigned long arg)
{
    tTimeSyncGetSyncInterval *pack = NULL;
    int ret;
    uint32_t interval;

    DBG_MSG("rthTimeSyncGetSyncInterval\n");
    /* check parameter */
    if( 0 == arg )
        return -1;

    pack = (tTimeSyncGetSyncInterval *)arg;

    ret = doRthCall_Param1(eRthCtrl_timeSyncGetSyncInterval, &interval);

    pack->interval = interval;

    return 0 - ret;
}

static int lTimeSyncStart (void)
{
    DBG_MSG("rthTimeSyncStart\n");

    if(!lStartedTimeSyncTask)
        return startTimeSync(0);

    return 0;
}

static int lTimeSyncStop (void)
{
    DBG_MSG("rthTimeSyncStop\n");

    if(timeSyncIsMaster())
        return -2;

    stopTimeSync();

    return 0;
}

static int lTimeSyncGetSyncState (
    const unsigned long arg)
{
    tTimeSyncGetSyncState *pack = NULL;

    DBG_MSG("rthTimeSyncGetSyncState\n");
    /* check parameter */
    if( 0 == arg )
        return -1;

    pack = (tTimeSyncGetSyncState *)arg;

    pack->state = lTsStatus;

    return 0;
}

static int lTimeSyncGetTimezone (
    const unsigned long arg)
{
    tTimeSyncGetTimezone *pack = NULL;

    DBG_MSG("rthTimeSyncGetTimezone\n");

    /* check parameter */
    if (0 == arg)
        return -1;

    pack = (tTimeSyncGetTimezone *)arg;

    if(lTimeDescValid)
    {
        pack->timeDesc = lTimeDesc;

        return 0;
    }

    return -1;
}

static int lTimeSyncSetTimezone (
    const unsigned long arg)
{
    tTimeSyncSetTimezone *pack = NULL;

    DBG_MSG("rthTimeSyncSetTimezone\n");
    /* check parameter */
    if( 0 == arg )
        return -1;

    pack = (tTimeSyncSetTimezone *)arg;

    lTimeDescMaster = pack->timeDesc;
    lTimeDescMasterValid = 1;

    return 0;
}

int timeSync(const unsigned cmd, const unsigned long arg, bool *processed)
{
    *processed = true;

    switch (cmd) {
        case eRthIoctl_timeSyncSetMaster:
            return lTimeSyncSetMaster(arg);

        case eRthIoctl_timeSyncGetMaster:
            return lTimeSyncGetMaster(arg);

        case eRthIoctl_timeSyncSetSyncInterval:
            return lTimeSyncSetSyncInterval(arg);

        case eRthIoctl_timeSyncGetSyncInterval:
            return lTimeSyncGetSyncInterval(arg);

        case eRthIoctl_timeSyncStart:
            return lTimeSyncStart();

        case eRthIoctl_timeSyncStop:
            return lTimeSyncStop();

        case eRthIoctl_timeSyncGetSyncState:
            return lTimeSyncGetSyncState(arg);

        case eRthIoctl_timeSyncGetTimezone:
            return lTimeSyncGetTimezone(arg);

        case eRthIoctl_timeSyncSetTimezone:
            return lTimeSyncSetTimezone(arg);

        default:
            *processed = false;
            break;
    }

    return -1;
}
