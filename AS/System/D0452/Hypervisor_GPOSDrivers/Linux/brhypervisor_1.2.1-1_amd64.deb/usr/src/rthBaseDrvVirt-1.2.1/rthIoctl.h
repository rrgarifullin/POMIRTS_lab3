/**
 * \file    rthIoctl.h
 *
 * \brief   IOCTL numbers for RTH base driver
 *
 * \copyright (c) 2009-2017 Real-Time Systems GmbH, Ravensburg, Germany
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * \par Modification History:
 *
 * \li  02i, 2017-08-23, Y.Zaporozhets - added osWdKick, osWdBootTimeoutSet, osBootlineGet and osRuntimeGet
 * \li  02h, 2014-03-21, M.Schunda - added eRthIoctl_sysShutdown and eRthIoctl_sysReboot
 * \li  02g, 2013-08-04, S.Fausser - added eRthIoctl_timeSyncSetTimezone
 * \li  02f, 2013-04-30, S.Fausser - added eRthIoctl_timeSyncGetTimezone
 * \li  02e, 2012-05-14, S.Fausser - added timeSync function calls
 * \li  02d, 2012-05-03, S.Fausser - added osctrl and event function calls
 * \li  02c, 2010-01-18, S.Fausser - Linux Kernel >= 2.6.31 bug: changed enum eRthIoctl_shmOpen from value 2 to value 11
 * \li  02b, 2009-11-04, S.Fausser - added eRthIoctl_shmCleanup
 * \li  02a, 2009-06-08, S.Fausser - rewritten for new rthCtrl module as introduced
 *                       in release 2.1, Revision 8080
 *
 */

#ifndef _RTH_IOCTL_H
#define _RTH_IOCTL_H

/***************************************************************************************************
 *                                            INCLUDES
 */

/***************************************************************************************************
 *                                            DEFINES
 */

/* RTH device name */
#define DEVICE_NAME     "/dev/rthBaseDrv"

/***************************************************************************************************
 *                                           DATA TYPES
 */

/**
 * Ioctl function numbers.
 */
enum eRthIoctl
{
    eRthIoctl_noFunction = 0,
    eRthIoctl_shmSizeGet = 1,
    eRthIoctl_shmOpen = 11,
    eRthIoctl_shmClose = 3,
    eRthIoctl_shmRead,
    eRthIoctl_shmWrite,
    eRthIoctl_shmMmap,
    eRthIoctl_shmLockAcquire,
    eRthIoctl_shmLockRelease,
    eRthIoctl_shmTracePartitionNameGet,
    eRthIoctl_shmCleanup,
    eRthIoctl_osMaxIdGet = 12,
    eRthIoctl_osNameGet = 13,
    eRthIoctl_osIdGet,
    eRthIoctl_osStateGet,
    eRthIoctl_osShutDown,
    eRthIoctl_osHalt,
    eRthIoctl_osBoot,
    eRthIoctl_osReboot,
    eRthIoctl_osReset,
    eRthIoctl_osGetOwnId,
    eRthIoctl_osBootlineSet,
    eRthIoctl_osLoadImage,
    eRthIoctl_osWdCountGet,
    eRthIoctl_osCtrlCommandGet,
    eRthIoctl_osCtrlStateSet,
    eRthIoctl_eventCreate,
    eRthIoctl_eventOpen,
    eRthIoctl_eventClose,
    eRthIoctl_eventStateSet,
    eRthIoctl_eventStateGet,
    eRthIoctl_timeSyncSetMaster,
    eRthIoctl_timeSyncGetMaster,
    eRthIoctl_timeSyncSetSyncInterval,
    eRthIoctl_timeSyncGetSyncInterval,
    eRthIoctl_timeSyncStart,
    eRthIoctl_timeSyncStop,
    eRthIoctl_timeSyncGetSyncState,
    eRthIoctl_timeSyncGetTimezone,
    eRthIoctl_timeSyncSetTimezone,
    eRthIoctl_sysShutdown,
    eRthIoctl_sysReboot,
    eRthIoctl_versionGet,
    eRthIoctl_osWdKick,
    eRthIoctl_osWdBootTimeoutSet,
    eRthIoctl_osBootlineGet,
    eRthIoctl_osRuntimeGet
};

/***************************************************************************************************
 *                                     FUNCTION DECLARATIONS
 */

#endif                          /* _RTH_IOCTL_H */
