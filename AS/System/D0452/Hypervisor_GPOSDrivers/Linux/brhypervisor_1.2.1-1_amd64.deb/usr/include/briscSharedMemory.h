/* Functions to handle intersystem communications in a B&R environment.
 * The term 'system' is used as synonym for a operating system.
 */

/* Shared memory API
 * The shared memory partition for usage by a user is preconfigured.
 */

#ifndef _BRISC_SHARED_MEMORY_H_
#define _BRISC_SHARED_MEMORY_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef struct BRISC_SHM* BRISC_SHM_H;

/* Opens the only shared memory partition for a user.
 * The shared memory partition cannot be opened twice on the same system.
 * Returns: handle of the opened shared memory partition or NULL in case of error.
 */
BRISC_SHM_H briscShmOpen();

/* Determine the size of the opened shared memory partition with the given handle 'hShm'.
 * Returns: size in bytes of the shared memory partition or -1 in case of error.
 */
int briscShmGetSize(BRISC_SHM_H hShm);

/* Determine the address of the opened shared memory partition with the given handle 'hShm'.
 * When accessing shared memory, the application is itself responsible for making sure
 * it does not access memory outside of the allocated shared memory partition.
 * Returns: the pointer to the shared memory partition or NULL in case of error.
 */
volatile void* briscShmGetAddress(BRISC_SHM_H hShm);

/* Closes the shared memory partition with the given handle 'hShm'.
 */
void briscShmClose(BRISC_SHM_H hShm);

#ifdef __cplusplus
}
#endif

#endif
